package Utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigurationReader {
    public static Properties properties ;
    static {
        String path = "Config.properties";
        try {
            FileInputStream file  = new FileInputStream(path);
            properties = new Properties();
            properties.load(file);
        } catch (IOException ex) {
            System.err.println("Error reading configuration file: " + ex.getMessage());
        }
    }
    public static String getProperty(String key){
        return properties.getProperty(key);
    }
}

