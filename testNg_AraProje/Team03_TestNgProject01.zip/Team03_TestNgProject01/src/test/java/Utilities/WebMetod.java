package Utilities;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.time.Duration;

public class WebMetod {public class WebElementTools {
    private WebDriver _driver;
    public WebElementTools(WebDriver Driver) {
        _driver = Driver;
    }

    private WebDriverWait waits() {
        return new WebDriverWait(_driver, Duration.ofSeconds(3));
    }

    @BeforeClass
    public void setup() {
        _driver.manage().window().maximize();
        _driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }

    @AfterClass
    public void cleanup() throws InterruptedException {
        Thread.sleep(10000);
        //_driver.quit();
    }

    /* methods */

    public void openUrl(String url) {
        _driver.get(url);
    }
    public void clickOn(WebElement element) {
        //WebDriverWait wait = new WebDriverWait(_driver,Duration.ofSeconds(3));
        waits().until(ExpectedConditions.elementToBeClickable(element)).click();
        //element.click();
    }

    public void clickOn(By by) {
        WebDriverWait wait = new WebDriverWait(_driver,Duration.ofSeconds(3));
        waits().until(ExpectedConditions.elementToBeClickable(by)).click();
    }

    /**
     * Clicks on an element using JavaScript
     *
     * @param element
     */
    public void clickOnJS(WebElement element) {
        ((JavascriptExecutor) _driver).executeScript("arguments[0].scrollIntoView(true);", element);
        ((JavascriptExecutor) _driver).executeScript("arguments[0].click();", element);
    }

    public void scrollIntoJS(WebElement element) {
        ((JavascriptExecutor) _driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }


    public void sendKeys(WebElement element, Keys key) {
        waits().until(ExpectedConditions.elementToBeClickable(element)).sendKeys(key);
    }
    public void sendKeys(By by, Keys key) {
        waits().until(ExpectedConditions.elementToBeClickable(by)).sendKeys(key);
    }
    public void sendText(WebElement element, String text) {
        waits().until(ExpectedConditions.elementToBeClickable(element)).sendKeys(text);
    }
    public void sendText(By by, String text) {
        waits().until(ExpectedConditions.elementToBeClickable(by)).sendKeys(text);
    }

    public String alertText() {
        return waits().until(ExpectedConditions.alertIsPresent()).getText();
        //return _driver.switchTo().alert().getText();
    }

    public WebElement waitFor(WebElement element) {
        return waits().until(ExpectedConditions.visibilityOf(element));
    }

    public WebElement waitFor(By by) {
        return waits().until(ExpectedConditions.visibilityOfElementLocated(by));
    }

    public boolean isVisible(WebElement element) {
        return waits().until(ExpectedConditions.visibilityOf(element)).isDisplayed();
    }

    /**
     * waits for backgrounds processes on the browser to complete
     *
     * @param timeOutInSeconds
     */
    public void waitForPageToLoad(long timeOutInSeconds) {
        ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
            }
        };
        try {
            WebDriverWait wait = new WebDriverWait(_driver, Duration.ofSeconds(timeOutInSeconds));
            wait.until(expectation);
        } catch (Throwable error) {
            error.printStackTrace();
        }
    }

}

}
