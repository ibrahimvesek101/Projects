package Utilities;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TestNgListener implements ITestListener {
    @Override
    public void onTestStart(ITestResult result) {
        System.out.println("Test started " + result.getName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        System.out.println("Test success " + result.getName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        takeScreenshot(result.getTestName() + "-" + result.getName());
        System.out.println("Test failed " + result.getName());
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        System.out.println("Test skipped " + result.getName());
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        ITestListener.super.onTestFailedButWithinSuccessPercentage(result);
    }

    @Override
    public void onTestFailedWithTimeout(ITestResult result) {
        ITestListener.super.onTestFailedWithTimeout(result);
    }

    @Override
    public void onStart(ITestContext context) {
        System.out.println("XML started " + context.getName());
    }

    @Override
    public void onFinish(ITestContext context) {
        System.out.println("XML finished " + context.getName());
    }

    private void takeScreenshot(String testName) {
        try {
            File screenshotFile = ((TakesScreenshot) Driver.getDriver()).getScreenshotAs(OutputType.FILE);
            LocalDateTime currentTime = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
            File destinationFile = new File("screenshots/" + testName +"_" + currentTime.format(formatter) + ".png");
            FileUtils.copyFile(screenshotFile, destinationFile);
            System.out.println("Screenshot taken: " + destinationFile.getAbsolutePath());
        } catch (WebDriverException | IOException e) {
            System.out.println("Failed to take screenshot: " + e.getMessage());
        }
    }

}

