package Test.Harika.US_032;

import Page.BaseClass;
import Page.minciGroceryPO;
import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class TC_001 extends BaseClass {

    @FindBy(xpath = "//button[text()='Join']")
    WebElement join;
    @FindBy(xpath = "//button[text()='Login']")
    WebElement login;
    @FindBy(linkText = "Shops")
    public WebElement shops;

    public void customerLogin() {
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
        join.click();
        login.click();
    }
    minciGroceryPO gr=new minciGroceryPO();
    @Test
    public void test01() {
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        gr.gotoGroceryHomePage();
        gr.searchInGrocery("apples");
        gr.getBtnProductAdd();
        gr.getTxtBasketTotal();


    }
}