package Test.Harika.US_030;

import Page.BakeryPO;
import Page.BaseClass;
import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class TC_005 extends BaseClass {
    /*
    1-kullanici url e gider
2-kullanici shop butonunu tılar
     */
    @FindBy(xpath = "//button[text()='Join']")
    WebElement join;
    @FindBy(xpath = "//button[text()='Login']")
    WebElement login;
    @FindBy(linkText = "Shops")
    public WebElement shops;

    public void customerLogin() {
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
        join.click();
        login.click();
    }
    BakeryPO bakery=new BakeryPO();
    @Test
    public void TC_05() {
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        bakery.shopsPage();

    }



}
