package Test.Harika.US_032;

import Page.BakeryPO;
import Page.BaseClass;
import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class TC_003 extends BaseClass {

    @FindBy(xpath = "//button[text()='Join']")
    WebElement join;
    @FindBy(xpath = "//button[text()='Login']")
    WebElement login;
    @FindBy(linkText = "Shops")
    public WebElement shops;

    public void customerLogin() {
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
        join.click();
        login.click();
    }
    BakeryPO bakery = new BakeryPO();
    @Test
    public void TC_003() {
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();
             bakery.shopsPage();
             bakery.grocery1();
             bakery.bakery1();


    }
}
