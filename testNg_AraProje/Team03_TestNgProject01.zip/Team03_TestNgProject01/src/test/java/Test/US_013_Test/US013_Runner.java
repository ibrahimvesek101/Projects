package Test.US_013_Test;

import Page.BagsPO_Ali;
import Page.LoginPO_Ali;
import Page.MakeUpPO_Ali;
import Utilities.Driver;
import org.testng.annotations.Test;

public class US013_Runner {

    LoginPO_Ali lg = new LoginPO_Ali();
    BagsPO_Ali bp = new BagsPO_Ali();
    MakeUpPO_Ali mp = new MakeUpPO_Ali();

    @Test
    public void Test01() throws InterruptedException { //Kullanici checkout a bastiginda giris yaptiysa checkout sayfasina yonlendirilmelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        mp.makeupShopClick();
        mp.chooseProduct(4);
        mp.addShoppingCart();
        mp.makeupShop();
        mp.itemsClick();
        mp.checkOutClick();
        mp.orderIsDisplayed();


    }

    @Test
    public void Test02() throws InterruptedException { //Kullanici checkout sayfasinda aldigi urunleri ve odeyecegi tutari goruntuleyebilmelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        mp.makeupShopClick();
        mp.chooseProduct(4);
        mp.addShoppingCart();
        mp.makeupShop();
        mp.itemsClick();
        mp.checkOutClick();
        mp.productSubTotal();
        mp.orderIsDisplayed();


    }


    @Test
    public void Test03() throws InterruptedException { //Kullanici Contact Number, Billing Address, Shipping Address bilgilerini update edebilmelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        mp.makeupShopClick();
        mp.chooseProduct(4);
        mp.addShoppingCart();
        mp.makeupShop();
        mp.itemsClick();
        mp.checkOutClick();

        mp.contactNumberClick();
        mp.contactNumberUpdate();
        mp.addContcatClick();

        mp.billingAddressClick();
        mp.titleBillingAddress();
        mp.adressCountry();
        mp.adressCity();
        mp.adressState();
        mp.adressZip();
        mp.street_address();
        mp.updateAddressClick();

        mp.AdresGuncelle();
        mp.updateAddressClick();

        mp.shippingAddressClick();
        mp.titleShippingAddress();
        mp.adressCountry();
        mp.adressCity();
        mp.adressState();
        mp.adressZip();
        mp.street_address();
        mp.updateAddressClick();
      //  mp.AdresGuncelle();

    }


    @Test
    public void Test04() throws InterruptedException {  //  Kullanici Delivery Schedule (teslimat programi) secebilmelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        mp.makeupShopClick();
        mp.chooseProduct(4);
        mp.addShoppingCart();
        mp.makeupShop();
        mp.itemsClick();
        mp.checkOutClick();

        mp.evening();

    }

    @Test
    public void Test05() throws InterruptedException {  //  Kullanici indirim kuponu kullanabilmeli ve tutar uzerinden indirim uygulayabilmelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        mp.makeupShopClick();
        mp.chooseProduct(4);
        mp.addShoppingCart();
        mp.makeupShop();
        mp.itemsClick();
        mp.checkOutClick();

        mp.checkAvailabilityClick();
        mp.couponClick();
        mp.codeSendKeys();
        mp.applyClick();
        mp.discountTotalIsDisplayed();

    }

    @Test
    public void Test06() throws InterruptedException {  //  Payment Method (odeme yontemi) secebilmelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        mp.makeupShopClick();
        mp.chooseProduct(4);
        mp.addShoppingCart();
        mp.makeupShop();
        mp.itemsClick();
        mp.checkOutClick();

        mp.checkAvailabilityClick();
        mp.couponClick();
        mp.codeSendKeys();
        mp.applyClick();
        mp.choosePaymentMethodClick();

    }

    @Test
    public void Test07() throws InterruptedException {  //  Checked Avalibilty - Place Order ile odeme sonlandirmalidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        mp.makeupShopClick();
        mp.chooseProduct(4);
        mp.addShoppingCart();
        mp.makeupShop();
        mp.itemsClick();
        mp.checkOutClick();

        mp.contactNumberClick();
        mp.contactNumberUpdate();
        mp.addContcatClick();

        mp.checkAvailabilityClick();
        mp.couponClick();
        mp.codeSendKeys();
        mp.applyClick();
        mp.choosePaymentMethodClick();
        mp.placeOrderClick();
//        mp.sendKeysOwnerName();
//        mp.sendKeysCardNumber();
//        mp.sendKeysExpirationDate();
//        mp.sendKeysCVC();
//        mp.payButtonClick();

    }

    @Test
    public void Test08() throws InterruptedException { //Place Order ile siparis sureci izlenebilmelidir(5 asamali)
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        mp.makeupShopClick();
        mp.chooseProduct(4);
        mp.addShoppingCart();
        mp.makeupShop();
        mp.itemsClick();
        mp.checkOutClick();

        mp.contactNumberClick();
        mp.contactNumberUpdate();
        mp.addContcatClick();

        mp.checkAvailabilityClick();
        mp.couponClick();
        mp.codeSendKeys();
        mp.applyClick();
        mp.choosePaymentMethodClick();
        mp.placeOrderClick();
        mp.orderProcessIsDisplayed();


    }

    @Test
    public void Test09() throws InterruptedException { //Kullanici urun siparis ekraninda siparis ettigi urun ve tutari goruntuleyebilmelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        mp.makeupShopClick();
        mp.chooseProduct(4);
        mp.addShoppingCart();
        mp.makeupShop();
        mp.itemsClick();
        mp.checkOutClick();

        mp.contactNumberClick();
        mp.contactNumberUpdate();
        mp.addContcatClick();

        mp.checkAvailabilityClick();
        mp.couponClick();
        mp.codeSendKeys();
        mp.applyClick();
        mp.choosePaymentMethodClick();
        mp.placeOrderClick();
        mp.orderProcessIsDisplayed();
        mp.cartInfoIsDisplayed();
        mp.myAccountClick();
        mp.myOrdersClick();
        mp.cartInfoIsDisplayed();


    }
}
