package Test.Cihat.US024;

import Page.BaseClass;
import Page.BooksPO_Cihat;
import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

import static Utilities.Driver.getDriver;

public class TC001_BRunner2 extends BaseClass {

 //Kullanıcı Top Authors başlığını doğrulamalı
 //Kullanıcı ana ekranda 7 yazar gördüğünü doğrulamalı
 //Kullanıcı SVG (Scalable Vector Graphics) Slider ile yazarlar da swipe yapabilmeli
 //Kullanıcı See All linkinin çalıştığını dorulamalı ve bütün yazarları görebilmeli
 //Kullanıcı Search input kısmında yazar arayabilmeli ve doğrulamalı
 //Kullanıcı ilgli yazarın description kısmında Read More and Less butonunun çalıştığını doğrulamalıdır
 //Kullanıcı scroll down yaparak Author Books başlığını ve yazarın kitaplarını doğrulamalıdır


    BooksPO_Cihat bp= new BooksPO_Cihat();

    @Test
    public void bookPagePOP() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();
        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOf(Driver.getDriver().findElement(By.xpath("(//button[@aria-expanded='false'])[1]")))).click();
        Driver.getDriver().findElement(By.xpath("//span[contains(text(),'Books')]")).click();
        Thread.sleep(2000);

        JavascriptExecutor js = (JavascriptExecutor) getDriver();
        js.executeScript("window.scrollTo(0,document.body.scrollHeight)");


        bp.firstPage();
        bp.btnBooksPage();
        bp.topAuthorsbtn();
        bp.slider();
        bp.sliderNext();
        bp.seeAll();
        bp.sendKeyword("Kelly White");
        bp.kellyWhiteButton();
        bp.readMore();
        bp.less();
        bp.authorBooks();







    }
}
