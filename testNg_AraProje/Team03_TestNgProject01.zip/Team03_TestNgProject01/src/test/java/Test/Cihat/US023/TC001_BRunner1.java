package Test.Cihat.US023;

import Page.BaseClass;
import Page.BooksPO_Cihat;
import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class TC001_BRunner1 extends BaseClass {

    //Kullanıcı sayfaya scroll down yaparak sonuna gidip gelebilmeli ve doğrulamalı
    //Kullanıcı ürünün üzerine tıklayarak ürün detayına gidebilmeli
    //Kullanıcı ürünün başlığını doğrulamalı
    //Kullanıcı ürünün önceki sayfadaki fiyatı ile detay sayfasındaki fiyatın aynı olduğunu doğrulamalı
    //Kullanıcı See more See Less buttonlarının çalıştığını doğrulamalı
    //Kullanıcı + ve - tıklayarak spariş vereceği ürün sayısı seçebilmeli
    //Kullanıcı Add to Cart buttonunu kullanarak spariş işlemleri yapabilmeli
    //Kullanıcı kalp buttonunun select ve unselect olduğunu doğrulamalı
    //Kullanıcı scroll barın çalıştığınıdoğrulamalı ve scroll yaparak Details başlığını doğrulamalı
    //Kullanıcı scroll yaparak Recent drop downın çalıştığını doğrulamalı
    //Kullanıcı scroll yaparak All Star drop downın çalıştığını doğrulamalı
    //Kullanıcı scroll yaparak Ask seller a question butonun çalıştığını doğrulamalı

    BooksPO_Cihat bp = new BooksPO_Cihat();


    @Test
    public void scrollDownTest() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();
        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOf(Driver.getDriver().findElement(By.xpath("(//button[@aria-expanded='false'])[1]")))).click();
        Driver.getDriver().findElement(By.xpath("//span[contains(text(),'Books')]")).click();
        Thread.sleep(2000);
        bp.firstPage();
        bp.btnBooksPage();
        bp.masterCardIsVisible();
        bp.imgofTopofPage();
        bp.lnkBookPage();
        bp.detailsLinkBookPage();
        bp.titleLinkBookPage();
        bp.priceLinkBookPage();
        bp.seeMorelink();
        bp.plusBtn();
        bp.minusBtn();
        bp.addToCartButton();
        bp.heartbtn();
        bp.loginButton();
        bp.loginButton1();
        bp.detailsLinkBookPage();
        bp.recentbtn();
        bp.allStartbtn();
        bp.askSellerbtn();











    }


}

