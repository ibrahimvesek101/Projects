package Test.Cihat.US021;

import Page.BaseClass;
import Page.DailyPO_Cihat;
import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

import static Utilities.Driver.getDriver;

public class TC001_DNRunner2 extends BaseClass {

    //Kullanıcı seçeceği ürünün fiyatını, indirmli fiyatını ve indirim oranı görebilmelidir
    //Kullanıcı ürün birimini görebilmelidir
    //İlglii ürün açıklaması ve title ı olmalıdır.
    //Ürünün sayfasını açabilmeli
    //Açılan sayfada ürünün başlık ve fiyatının önceki sayfadaki ile aynı olduğunu doğrulayabilmeli
    //Kullanıcı sayfada Read More ve Less buttonlarının çalıştığını doğrulamalıdır
    //Kullanıcı açılan sayfasa scroll barın çalıştığını, Categories, Sellers başlıklarını doğrulamalı
    //Kullanıcı açılan sayfada root ve vegetables buttonlarının çalışıyor olduğunu doğrulamalı
    //Kullanıcı açılan sayfada scroll yaparak Details kısmını ve yazılı olduğunu doğrulamalı
    //Kullanıcı açılan sayfada scroll yaparak Related Products başlığını doğrulamalı


    @Test
    public void testDailyNeeds() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();
        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOf(Driver.getDriver().findElement(By.xpath("(//button[@aria-expanded='false'])[1]")))).click();
        Driver.getDriver().findElement(By.xpath("//span[contains(text(),'Daily Needs')]")).click();
        Thread.sleep(2000);

        JavascriptExecutor js = (JavascriptExecutor) getDriver();
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);

        DailyPO_Cihat dn = new DailyPO_Cihat();

        dn.vegetablesLnk();
        dn.rootButton();
        dn.carrotButton();
        dn.details();
        dn.textDetails();
        dn.relatedProducts();


    }

}
