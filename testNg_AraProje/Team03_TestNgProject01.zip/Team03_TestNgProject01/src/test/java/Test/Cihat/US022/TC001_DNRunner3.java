package Test.Cihat.US022;

import Page.BaseClass;
import Page.DailyPO_Cihat;
import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class TC001_DNRunner3 extends BaseClass {

    //Kullanıcı Add To Shopping Cart seçeneğine tıklayabilmeli
    //Kullanıcı sepete ürün ekleyebilmeli
    //Kullanıcı sepetten ürün çıkartabilmeli
    //Kullanıcı sepette fiyatı görmeli
    @Test
    public void testDailyNeeds() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();
        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOf(Driver.getDriver().findElement(By.xpath("(//button[@aria-expanded='false'])[1]")))).click();
        Driver.getDriver().findElement(By.xpath("//span[contains(text(),'Daily Needs')]")).click();
        Thread.sleep(2000);

        DailyPO_Cihat dn = new DailyPO_Cihat();
        dn.dailyNeedslnk();
        dn.vegetablesLnk();
        dn.edibleLnk();
        dn.addToCartBtn();
        dn.plusProduct();
        dn.minusProduct();
        dn.shoppingBasket();
        dn.totalPrice();



    }
}