package Test.Aydn.US_020;

import Utilities.Driver;
import org.apache.commons.lang3.RandomUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;


import java.util.List;

import static Test.Aydn.MethodClass.*;


public class TC004 {



    @Test
    public void dailyNeeds2() throws InterruptedException {

        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/daily-needs");
        Driver.getDriver().manage().window().maximize();
        scrolDown(Driver.getDriver());

        altCategoryCheck(allCategoryCheck());

        if (productsNotFoundCheck()) {
            altCategoryCheck1();
        } else {
            finishByNoProduct();
        }

    }

    private void finishByNoProduct() {
        System.out.println("ProductNot found Test finished");
    }

    private void altCategoryCheck1() throws InterruptedException {
        Thread.sleep(3000);
        List<WebElement> addItemButtons = Driver.getDriver().findElements(By.xpath("//span[text()='Add']"));
        if (addItemButtons.size() == 0) {
            List<WebElement> altCatList = Driver.getDriver().findElements(By.xpath("//div[@role='button']//h3"));
            int rndNum = RandomUtils.nextInt(0, altCatList.size());
            String rndStr = altCatList.get(rndNum).getText().toLowerCase().substring(0, 4);
            altCatList.get(rndNum).click();

            waitForURLToContain(rndStr);

            altCategoryCheck1();
        }
        List<WebElement> headerEls = Driver.getDriver().findElements(By.xpath("//header[@class='p-3 md:p-6']//h3"));
        for (WebElement addItemButton : addItemButtons) {
            System.out.println("a.getText() = " + addItemButton.getText());
        }
        for (WebElement headerEl : headerEls) {
            System.out.println("headerEls.getText() = " + headerEl.getText());
        }
        int rndNum = RandomUtils.nextInt(0, addItemButtons.size());
        System.out.println("rndNum = " + rndNum);
        String rndStr = headerEls.get(rndNum).getText();
        System.out.println("rndStr = " + rndStr);
        addItemButtons.get(rndNum).click(); //rastgele bir add e tıklar
        sepetIslem(rndStr);

        
    }

    private void sepetIslem(String rndText) {
        findElementMethod(By.xpath("//button[@class='hidden product-cart lg:flex relative']")).click();

        String sepetProduct = waitForVisOfElLoc(By.xpath("//h3[@class='font-bold text-heading']")).getText();
        Assert.assertTrue(sepetProduct.equals(rndText),"Sepetteki ürünler eşleşmiyor");

    }

    private boolean productsNotFoundCheck() {
        boolean flag = false;
        try {

            waitForVisOfElLoc(By.xpath("//img[@alt='Sorry, No Product Found :(']"));

        } catch (TimeoutException e) {
            flag = true;
        }
        return flag;
    }

    private void scrolDown(WebDriver driver) {
        JavascriptExecutor jsScrollDown = (JavascriptExecutor) driver;
        jsScrollDown.executeScript("window.scrollTo(0,document.body.scrollHeight)");
    }


    private String allCategoryCheck() {
        List<WebElement> altCatNum = Driver.getDriver().findElements(By.xpath("//div[@role='button']//span"));
        List<WebElement> headLines = Driver.getDriver().findElements(By.xpath("//div[@role='button']//h3"));
        for (WebElement a : altCatNum) {
            int textOfEl = Integer.parseInt(a.getText().substring(0, a.getText().indexOf(" ")));
            Assert.assertTrue(textOfEl > 0);
        }
        int sayi = RandomUtils.nextInt(0, headLines.size());

        viewMoreCheck();
        String altNumstr = altCatNum.get(sayi).getText();
        String altNumAssert1 = altNumstr.substring(0, altNumstr.indexOf(" "));
        headLines.get(sayi).click();

        waitForURLToContain(headLines.get(sayi).getText().toLowerCase().substring(0, 4));

        return altNumAssert1;
    }

    private void viewMoreCheck() {
        Actions actions = new Actions(Driver.getDriver());

        List<WebElement> viewElList = Driver.getDriver().findElements(By.xpath("//button[contains(text(),'View More')]"));

        for (int i = 1; i < viewElList.size(); i++) {
            actions.moveToElement(viewElList.get(i-1)).perform();

            WebElement viewMorewait = waitForVisOfElLoc(
                    (By.xpath("(//button[contains(text(),'View More')])[" +i+ "]")));


            Assert.assertTrue(viewMorewait.isDisplayed(), i+". 'View More' butonu görüntülenemiyor.");
            System.out.println(i);
        }



    }

    private void altCategoryCheck(String allNumber) {
        List<WebElement> altCatList = Driver.getDriver().findElements(By.xpath("//div[@role='button']//h3"));

        int altNumInt = altCatList.size();

        String altNumAssert2 = altNumInt + "";

        Assert.assertTrue(allNumber.equals(altNumAssert2), "Alt kategori sayısı uyuşmuyor");

        int rndAltCatInt = RandomUtils.nextInt(0, altNumInt);
        System.out.println("rndAltCatInt = " + rndAltCatInt);
        String rndAltCatStr = altCatList.get(rndAltCatInt).getText().substring(0, 4).toLowerCase();
        System.out.println("rndAltCatStr = " + rndAltCatStr);
        altCatList.get(rndAltCatInt).click();

        waitForURLToContain(rndAltCatStr);

    }
}
