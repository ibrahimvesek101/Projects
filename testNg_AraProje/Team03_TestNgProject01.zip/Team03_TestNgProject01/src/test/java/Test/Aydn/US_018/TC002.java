package Test.Aydn.US_018;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.Test;


import java.util.List;

import static Test.Aydn.MethodClass.*;


public class TC002 {

    @Test
    public void TC_002() throws InterruptedException {

        login_Method();
        // wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Join')]"))).click();

        // .getDriver().findElement(By.xpath("//button[text()='Login']")).click();
        Thread.sleep(3000);
        waitForVisOfElLoc(By.xpath("(//button[@aria-expanded='false'])[1]")).click();

        waitForVisOfElLoc(By.xpath("//span[contains(text(),'Bags')]")).click();

        //wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath("//span[contains(@class, 'text-base font')]"), 4)

        String nameAssert1 = waitForVisOfElLoc(By.xpath("(//h3[@role='button'])[4]")).getText(); //4. itemin textini alıyor

        waitForElementToBeClickable(By.xpath("(//*[text()='Cart'])[4]")).click(); //             4. iteme tıklıyor
        waitForElementToBeClickable(By.xpath("//SPAN[contains(text(),'Item')]")).click(); // Sepete tıklıyor
        Thread.sleep(3000);
        String nameAssert2 = waitForVisOfElLoc(By.xpath("(//img[@class='object-contain'])[2]")).getAttribute("alt"); //sepettenki ilk ürünü locate edip alt att'sini alıyor

        Assert.assertTrue(nameAssert2.equals(nameAssert1), "Sepetteki ürünler eşleşmiyor");
        getDriver().findElement(By.xpath("//span[contains(text(),'Checkout')]")).click();
        Thread.sleep(2000);
        String urlCurrent = getDriver().getCurrentUrl();

        String urlToBe = "https://shop-pickbazar-rest.vercel.app/checkout";
        Assert.assertTrue(urlToBe.equals(urlCurrent), "Checkout sayfasına yönlendirilemediniz");

        // ********* //



        waitForVisOfElLoc(By.xpath("//button[contains(text(),'Add')]")).click();

        WebElement phoneNumberInsert = waitForVisOfElLoc(By.xpath("(//input[@placeholder='1 (702) 123-4567'])[2]"));

        Actions actions = new Actions(getDriver());

        actions.click(phoneNumberInsert);
        phoneNumberInsert.sendKeys(Keys.chord(Keys.CONTROL, "a"), Keys.DELETE);


        String newPhoneNumber = "905551797271";

        phoneNumberInsert.sendKeys(newPhoneNumber);

        findElementMethod(By.xpath("(//button[@data-variant='normal'])[2]")).click();
        //getDriver().findElement().click();

        String phoneNumberAssert = findElementMethod(By.xpath("(//input[@placeholder='1 (702) 123-4567'])[1]")).getAttribute("value");

        phoneNumberAssert = phoneNumberAssert.substring(1).replaceAll(" ", "");

        Assert.assertTrue(newPhoneNumber.equals(phoneNumberAssert), "Girilen Telefon numaraları uyuşmuyor");

        //(//p[@class='text-sm text-sub-heading'])[1]

        findElementMethod(By.xpath("(//p[@class='text-sm text-sub-heading'])[1]"));
        WebElement billingAdressDiv = findElementMethod(By.xpath("(//div[@role='radiogroup'])[1]"));

        actions.moveToElement(billingAdressDiv.findElement(By.xpath("(//span[contains(text(),'Edit')])[1]")));
        //actions.click();
        billingAdressDiv.findElement(By.xpath("//button[span[contains(text(), 'Edit')]]")).click();
        String billingAddressMessage = "Merhaba";
        Thread.sleep(3000);

        waitForVisOfElLoc(By.xpath("//textarea[@id='address.street_address']")).sendKeys(billingAddressMessage);
        findElementMethod(By.xpath("(//button[contains(text(),'Update')])[2]")).click();

        Thread.sleep(4000);
        String billingAddresSendAssert = billingAdressDiv.findElement(By.xpath("(//p[@class='text-sm text-sub-heading'])[1]")).getText();


        Assert.assertTrue(billingAddresSendAssert.contains(billingAddressMessage), "Adres bilgisi girilemedi");


        findElementMethod(By.xpath("((//div[@role='radiogroup'])[2]//button[span[contains(text(), 'Edit')]])[1]")).click();
        String shippingAdresMessage = "Merhaba22";
        Thread.sleep(3000);
        waitForVisOfElLoc(By.xpath("//textarea[@id='address.street_address']")).sendKeys(shippingAdresMessage);
        findElementMethod(By.xpath("(//button[contains(text(),'Update')])[2]")).click();
        Thread.sleep(3000);
        String shippingAddressAssert = findElementMethod(By.xpath("((//div[@role='radiogroup'])[2]//p[@class='text-sm text-sub-heading'])[1]")).getText();
        Assert.assertTrue(shippingAddressAssert.contains(shippingAdresMessage));

        Thread.sleep(4000);
        findElementMethod(By.xpath("(//div[contains(@class,'border-accent bg')])[1]")).click();

        JavascriptExecutor js = (JavascriptExecutor) getDriver();
        js.executeScript("window.scrollTo(0, 0);");

        waitForVisOfElLoc(By.xpath("//button[@data-variant='normal']")).click();
        waitForVisOfElLoc(By.xpath("//p[@role='button']")).click();
        WebElement totalAmount = (WebElement) ((JavascriptExecutor) getDriver()).executeScript(
                "return arguments[0].nextElementSibling;", findElementMethod(By.xpath("//P[text()='Total'] ")));
        String totalAmount1 = totalAmount.getText();

        String cuponCode = "BAZAR10";
        waitForVisOfElLoc(By.xpath("//input[@id='code']")).sendKeys(cuponCode + Keys.ENTER);
        waitForVisOfElLoc(By.xpath("//p[text()='Discount']")); //indirim uygulanmasını bekliyor

        Assert.assertFalse(totalAmount.getText().equals(totalAmount1), "Kupon uygulanamadı");
        findElementMethod(By.xpath("(//div[@role='radiogroup'])[4]//div[@role='radio']")).click();
        findElementMethod(By.xpath("//button[text()='Place Order']")).click();

        wait.until(ExpectedConditions.urlContains("/orders"));

        List<WebElement> siparisTakipElementleri = wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath("//span[contains(@class, 'text-base font')]"), 4));

        for (WebElement a : siparisTakipElementleri) {
            Assert.assertTrue(a.getText().contains("Order"));
        }

    }


}
