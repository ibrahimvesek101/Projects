package Test.Aydn.US_019;
import org.apache.commons.lang3.RandomUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import static Test.Aydn.MethodClass.*;


public class TC003 {


    @Test
    public void test01() {

        getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        getDriver().manage().window().maximize();
        waitForVisOfElLoc(By.xpath("(//button[@aria-expanded='false'])[1]")).click();
        findElementMethod(By.xpath("//span[contains(text(),'Daily Needs')]")).click();
        WebElement dailiyNeedsPageAssert = waitForVisOfElLoc(By.xpath("//h1[text()='You Deserve To Eat Fresh']"));
        Assert.assertEquals(dailiyNeedsPageAssert.getText(), "You Deserve To Eat Fresh");
        WebElement searchboxElement = findElementMethod(By.xpath("//input[@name='search']"));
        String previousUrl = getDriver().getCurrentUrl();
        searchboxNegativeTest(searchboxElement);
        waitForURLToContain("fruit");

        String nextUrl = getDriver().getCurrentUrl();

        Assert.assertFalse(previousUrl.equals(nextUrl),"Ürün sayfasına yönlendirilemedi");
    }

    private void searchboxNegativeTest(WebElement element) {

        try {
            element.sendKeys("fr");

            getDriver().findElement(By.xpath("//div[@class='max-h-52']"));

            Assert.fail("Elementin locate edilememesi gerekiyor");
        } catch (NoSuchElementException e) {
            Assert.assertTrue(true, "Beklenen durum gerçekleşmedi 2 kelimeyle arama yapılabiliyor");
        }

        element.clear();
        element.sendKeys("fr1");

        WebElement searchboxAcilirPencere = waitForVisOfElLoc(By.xpath("//h3[text()='No products found']"));

        Assert.assertTrue(searchboxAcilirPencere.isDisplayed(), "sayı girildiğinde no producstfound yazısı çıkmadı");
        element.clear();
        String sbValidKey = "fruits";
        element.sendKeys("fruits");

        List<WebElement> sbResEls = wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath("//div[@class='max-h-52']//span"), 6));
        int count = 0;
        for (WebElement a : sbResEls) {
            count++;
            Assert.assertTrue(a.getText().toLowerCase().contains(sbValidKey), count + ". eleman fruits ifadesi içermiyor");
        }

        int sayi = RandomUtils.nextInt(0, sbResEls.size());
        String randomProduct = sbResEls.get(sayi).getText().toLowerCase();

        System.out.println("randomProduct = " + randomProduct);
        sbResEls.get(sayi).click();
        wait.until(ExpectedConditions.urlContains("/products"));

    }
}
