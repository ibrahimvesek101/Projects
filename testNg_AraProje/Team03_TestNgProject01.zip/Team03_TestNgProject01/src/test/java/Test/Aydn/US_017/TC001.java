package Test.Aydn.US_017;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.testng.Assert;
import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.List;


import static Test.Aydn.MethodClass.*;

public class TC001 {


    List<WebElement> cartElements = getDriver().findElements(By.xpath("//SPAN[text()='Cart']"));

    @Test
    public void Test01() throws InterruptedException {

        getDriver().get("https://shop-pickbazar-rest.vercel.app/bags");
        getDriver().manage().window().maximize();
        getDriver().findElement(By.xpath("//SPAN[text()='Purse']")).click();

        waitForVisOfElLoc(By.xpath("//SPAN[text()='Cart']"));
        Thread.sleep(2000);
        clickRandomElementFromList(cartElements);

        waitForElementToBeClickable(By.xpath("//SPAN[text()='Hand bags']")).click();

        waitForNumberOfElementsToBeMoreThan(By.xpath("//SPAN[text()='Cart']"), 2);

        clickRandomElementFromList(cartElements);
        // waitForElementToBeClickable(By.xpath("(//*[text()='Cart'])[1]")).click();

        getDriver().findElement(By.xpath("//SPAN[text()='Shoulder bags']")).click();
        clickRandomElementFromList(cartElements);

        // waitForVisOfElLoc(By.xpath("(//SPAN[text()='Cart'])[1]")).click();
        waitForVisOfElLoc(By.xpath("//img[@class='product-image object-contain']")).click();
        String howManyPieces = waitForVisOfElLoc(By.xpath("//span[contains(normalize-space(.), 'pieces')]")).getText();

        int count = Integer.parseInt(howManyPieces.substring(0, howManyPieces.indexOf(' ')));

        WebElement addButton = waitForVisOfElLoc(By.xpath("(//button[span[contains(text(), 'plus')]])[3]"));
        for (int i = 0; i < count + 5; i++) {
            addButton.click();
        }

        Actions actions = new Actions(getDriver());
        actions.sendKeys(Keys.ESCAPE).perform();
        getDriver().findElement(By.xpath("//SPAN[text()='Wallet']")).click();


        clickRandomElementFromList(cartElements);

        getDriver().findElement(By.xpath("//SPAN[text()='Laptop bags']")).click();

        clickRandomElementFromList(cartElements);


        waitForElementToBeClickable(By.xpath("//SPAN[contains(text(),'Item')]")).click();

        waitForNumberOfElementsToBeMoreThan(By.xpath("//h3[contains(@class, 'font-bold text-heading')]"), 1);
        List<WebElement> elementList = getDriver().findElements(By.xpath("//h3[contains(@class, 'font-bold text-heading')]"));
        List<String> h3texts = new ArrayList<>();
        for (WebElement a : elementList) {
            String text = a.getText();
            System.out.println("text = " + text);
            h3texts.add(text);
        }


        h3texts.clear();
        elementList.clear();

        waitForNumberOfElementsToBeMoreThan(By.xpath("//SPAN[contains(@class,'auto rtl:mr-auto')]"), 2);
        Thread.sleep(3000);
        elementList = getDriver().findElements(By.xpath("//SPAN[contains(@class,'auto rtl:mr-auto')]"));
        for (WebElement a : elementList) {
            String text = a.getText();
            System.out.println("text = " + text);
            h3texts.add(text);
        }
        String priceString = elementList.get(0).getText();
        int price = Integer.parseInt(priceString.substring(1, priceString.indexOf('.')));

        h3texts.clear();

        getDriver().findElement(By.xpath("(//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 hover:!bg-gray-100'])[2]")).click();
        getDriver().findElement(By.xpath("(//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 hover:!bg-gray-100'])[4]")).click();
        getDriver().findElement(By.xpath("(//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 hover:!bg-gray-100'])[3]")).click();
        elementList = getDriver().findElements(By.xpath("//h3[contains(@class, 'font-bold text-heading')]"));

        for (WebElement a : elementList) {
            String text = a.getText();
            h3texts.add(text);
        }


        h3texts.clear();
        elementList.clear();


        elementList = getDriver().findElements(By.xpath("//SPAN[contains(@class,'font-bold text-heading ltr:ml-auto rtl:mr-auto')]"));

        for (WebElement a : elementList) {
            String text = a.getText();
            h3texts.add(text);
        }

        String priceUpdated = elementList.get(0).getText();
        int price2 = Integer.parseInt(priceUpdated.substring(1, priceUpdated.indexOf('.')));
        Assert.assertTrue(price == price2 / 2, "Anormal fiyat değişikliği");
        String amountStr = getDriver().findElement(By.xpath("(//div[@class='flex flex-1 items-center justify-center px-3 text-sm font-semibold !px-0 text-heading'])[3]")).getText();
        int lastAmount = Integer.parseInt(amountStr);
        Assert.assertTrue(lastAmount == count, "Sepete stoktan fazla ürün eklenebiliyor");
        // removeList();
        getDriver().findElement(By.xpath("//span[contains(text(),'Checkout')]")).click();

    }

}
