package Test.Aydn;

import Utilities.Driver;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import java.time.Duration;
import java.util.List;


public class MethodClass {
    public static List<WebElement> removeList;
    public static WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));

    public  static void removeList(){
        removeList.addAll(getDriver().findElements(By.xpath("//button[contains(@class,'6')]")));
        for (WebElement a:removeList) {
            a.click();
        }
    }
    public static void login_Method() {
        getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        getDriver().manage().window().maximize();
        waitForVisOfElLoc(By.xpath("(//button[@data-variant='normal'])[1]")).click();
        WebElement email = Driver.getDriver().findElement(By.xpath("//input[@id='email']"));
        email.clear();
        email.sendKeys("costumerr@demo.com");
        WebElement pw = findElementMethod(By.xpath("//input[@id='password']"));
        pw.clear();
        pw.sendKeys("demodemo");
        findElementMethod(By.xpath("(//button[@data-variant='normal'])[3]")).click();

    }

    public static WebDriver getDriver() {
        return Driver.getDriver();
    }

    public static WebElement fluentWaitForElement(By locator, int timeoutSeconds, int pollingIntervalMillis) {
        wait
                .withTimeout(Duration.ofSeconds(timeoutSeconds))
                .pollingEvery(Duration.ofMillis(pollingIntervalMillis))
                .ignoring(NoSuchElementException.class);

        return wait.until(driver -> driver.findElement(locator));
    }

    public static WebElement waitForVisOfElLoc(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public static WebElement waitForElementToBeClickable(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    public static void waitForNumberOfElementsToBeMoreThan(By locator, int count) {
        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(locator, count));
    }

    public static void clickRandomElementFromList(List<WebElement> elements) throws InterruptedException, ElementNotInteractableException {
        elements.clear();

        Thread.sleep(2000);
        try {

            elements.addAll(getDriver().findElements(By.xpath("//SPAN[text()='Cart']")));
            if (elements.size() > 0) {
                //int randomIndex = RandomUtils.nextInt(0, elements.size());
                elements.get(0).click();
                // scrollToElement(elements.get(0));
            }

        } catch (ElementNotInteractableException e) {
            System.out.println("Sepete eklenecek ürün yok");
        }

    }

    public static void scrollToElement(WebElement element) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) getDriver();
        jsExecutor.executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public static WebElement findElementMethod(By locator) {
        return getDriver().findElement(locator);
    }

    public static void waitForURLToContain(String expectedText) {

        wait.until(ExpectedConditions.urlContains(expectedText));
    }

    @AfterClass
    public void tearDownn(){
        getDriver().quit();
    }
  //  @BeforeClass
  //  public void setup(){
  //      getDriver().get("https://shop-pickbazar-rest.vercel.app/");
  //      getDriver().manage().window().maximize();
//
  //  }
}
