package Test.US_027;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC001 extends BaseClass {
    minciGroceryPO gpo = new minciGroceryPO();

    @Test(priority = 0)
    public void checkProductFirstPrice() {
        topPanel.gotoPickBazar();
        topPanel.clickCategoryMenu("grocery");
        gpo.tools.waitForPageToLoad(5);
        gpo.getDivProductCards().get(0).click();

        Assert.assertTrue(gpo.getTxtProductFirstPrice().isDisplayed(), "First price not visible");
    }

}
