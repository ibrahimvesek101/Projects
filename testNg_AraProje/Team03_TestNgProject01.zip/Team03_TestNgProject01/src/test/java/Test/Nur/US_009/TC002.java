package Test.Nur.US_009;


import Page.BaseClass;
import Page.MakeupPONur;
import org.openqa.selenium.Keys;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TC002 extends BaseClass {


    // 1-Kullanıcı URL' e gider
    // 2.Kullanıcı olarak giriş yapar
    // 3-Kullanıcı anasayfadaki dropdown menüye tıklar ve makeup'ı seçer
    // 4-Arama çubuğuna "lipstick", "Mascara", "Foundation" keywordlerini sırasıyla yazar
    // 5- "Lipstick", "Mascara", "Foundation" ürünlerinin listelendiğini doğrular.
//


    MakeupPONur makeup=new MakeupPONur();

    @Test(dataProvider = "getData")
    public void test(String datas) throws InterruptedException {

        makeup.goToHomePage();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.sendKeyword(datas+ Keys.ENTER);
        Thread.sleep(3000);
        makeup.productsisDisplayed();


    }

    //
    @DataProvider
    public Object [][] getData(){
        return new Object [][]{
                {"Lipstick"},
                {"Mascara"},
                {"Foundation"}
        };


    }
}
