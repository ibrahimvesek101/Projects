package Test.Nur.US_012;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC004 extends BaseClass {

    //1.Kullanıcı URL'e gider.
    //2.Kullanıcı olarak giriş yapar
    //2-Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
    //3.Ürün listesinden bir ürünü seçer.
    //4. Ürün miktarını mevcut stok miktarından daha yüksek bir değere kadar arttırır
    //5. Kullanıcı stok miktarından fazla ürün arttırması yapamaz
    //
    MakeupPONur makeup=new MakeupPONur();

    @Test
    public void test() throws InterruptedException {


        makeup.goToHomePage();
       makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.sendKeyword("Foundation");
        makeup.clickFirstProduct();
        makeup.clickAddShoppingCard();
        makeup.increaseMoreThanStock();



    }
}
