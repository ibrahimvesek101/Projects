package Test.Nur.US_009;

import Page.BaseClass;
import Page.MakeupPONur;
import org.openqa.selenium.Keys;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TC006 extends BaseClass {

    //1-Kullanıcı URL' e gider
    //2.Kullanıcı olarak giriş yapar
    //2-Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
    //3-Arama işlemi başlatılır
    //4- Kullanıcı arama sekmesine ürün adı olarak sırasıyla "Powder", "Eyeshadow", "Blusher" yazar
    //5-Kullanıcı gönderilen ürün adı keywordlere göre ürünleri görüntüler
    //6-Arama çubuğuna marka olarak sırasıyla "Loreal", "Mac" yazar
    //7-Kullanıcı gönderilen marka keywordlerine göre  ürünleri görüntüler



    MakeupPONur makeup=new MakeupPONur();

    @Test(dataProvider = "getData1")
    public void test01(String datas) throws InterruptedException {

         makeup.goToHomePage();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.sendKeyword(datas+ Keys.ENTER);
        Thread.sleep(3000);
        makeup.clickMenu();
        makeup.assertMakeupCategories();


    }

    @DataProvider
    public Object [][] getData1(){
        return new Object [][]{
                {"Powder"},
                {"Eyeshadow"},
                {"Blusher"}
        };


    }



    @Test(dataProvider = "getData2")
    public void test02(String datas) throws InterruptedException {

        makeup.goToHomePage();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.sendKeyword(datas+ Keys.ENTER);
        Thread.sleep(2000);
        makeup.clickMenu();
        makeup.assertMakeupCategories();


    }

    @DataProvider
    public Object [][] getData2(){
        return new Object [][]{
                {"Loreal"},
                {"Mac"},

        };


    }






}
