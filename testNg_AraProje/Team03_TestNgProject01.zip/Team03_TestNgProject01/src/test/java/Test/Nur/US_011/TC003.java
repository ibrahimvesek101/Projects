package Test.Nur.US_011;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC003 extends BaseClass {

    //1-Kullanıcı URL' e gider
    //2.Kullanıcı olarak giriş yapar
    //2-Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
    //4.Seçtiği ürünü sepete ekler
    //5. Kullanıcı sepete git ikonuna tıklar ve sepet sayfasına gider
    //Sepet sayfasında eklenen ürünün miktarını arttırır
    //Artan ürün miktarına uygun olarak toplam fiyatın güncellendiğini doğrular


    MakeupPONur makeup=new MakeupPONur();

    @Test
    public void test() throws InterruptedException {


        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.sendKeyword("foundation");
        makeup.clickButonCart();
        makeup.clickSepet();
        makeup.clickIncreaseButtonInBasket();
        makeup.totalAmountSepet2();



    }
}
