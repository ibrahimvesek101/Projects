package Test.Nur.US_011;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC005 extends BaseClass {

    //Kullanıcı URL'e gider.
    //2.Kullanıcı olarak giriş yapar
    //2-Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
    //Ürün listesinden bir ürünü seçer.
    //Ürün miktarını artırır.
    //Sepet ikonuna tıklar ve sepet sayfasına gider.
    //Ürün miktarını sıfıra indirmek için azaltma düğmesine ardışık olarak tıklar.
    //Ürünün sepette olmadığını doğrular.
//

    MakeupPONur makeup=new MakeupPONur();

    @Test
    public void test() throws InterruptedException {


        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.clickButonCart();
       makeup.clickButtonCartMoreThanOne();
        makeup.clickSepet();
        makeup.clickdecreaseButtonToZeroInBasket();





    }


}
