package Test.Nur.US_012;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC001 extends BaseClass {

    //1.KullanıcıURL'e  gider.
    //2.Kullanıcı olarak giriş yapar
    //3.Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
    //"3. Kullanıcı  Face, Eyes, Lips dropdowndaki
    //menulerde ve Accessories, Shaving Needs, Oral Care,
    //Facial Care, Deodorant, Bath & Oil kategorilerinin görüntülendiğini doğrular"
    //
    MakeupPONur makeup=new MakeupPONur();

    @Test
    public void test() throws InterruptedException {


        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.visibilityDropdownMakeupCategories();
        makeup.assertionCategoriesIncluding();





    }
}
