package Test.Nur.US_009;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC005 extends BaseClass {

    //1-Kullanıcı URL' e gider
    //2.Kullanıcı olarak giriş yapar
    //2-Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
    //3-Arama çubuğuna "Face Powder" yazar
    //4-Arama işlemi başlatılır
    //5-Kulanıcı makeup kategorisine ait diğer ürünleri görüntüler
    //

    MakeupPONur makeup=new MakeupPONur();



    @Test
    public void test(){


       makeup.goToHomePage();
       makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.sendKeyword("Face Powder");
        makeup.testOtherProducts();

    }
}
