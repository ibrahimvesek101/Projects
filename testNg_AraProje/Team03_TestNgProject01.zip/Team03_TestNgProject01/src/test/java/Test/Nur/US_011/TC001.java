package Test.Nur.US_011;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC001 extends BaseClass {

    //1-Kullanıcı URL' e gider
    //2.Kullanıcı olarak giriş yapar
    //2-Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
    //3-Kullanıcı ürün listesinden bir ürün seçer
    //4.Anasayfada kullanıcı cart butonunu görüntüler
    //5-Kullanıcı eklemek istediği ürün miktarını artırmak/ için artırma butonuna tıklar.
    //6. Sepet ikonunu görüntüler
    //7. Kullanıcı sepete git ikonuna tıklar ve sepet sayfasına gider
    //8. Ürün miktarının artırıldığını ve sepet toplamının güncellendiğini doğrular.
    //


    MakeupPONur makeup=new MakeupPONur();

    @Test
    public void test() throws InterruptedException {


        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.clickButonCart();
        makeup.clickButtonCartMoreThanOne();
        makeup.clickSepet();
        makeup.assertionQuantitySepet();
        makeup.assertionTotalAmountSepet1();






    }
}
