package Test.Nur.US_009;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC003 extends BaseClass {

//1-Kullanıcı URL' e gider
//2.Kullanıcı olarak giriş yapar
//2-Kullanıcı dropdown menü'ye tıklar ve makeup kaegorisini seçer
//3-Arama çubuğuna "apple" yazar
//4-Arama işlemi başlatılır
//5-Herhangi bir ürün listelenmediğini doğrular
//

    MakeupPONur makeup=new MakeupPONur();



    @Test
    public void test(){
        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.sendKeyword("apple");
        makeup.assertionNotFoundTxtMethod();

    }
}
