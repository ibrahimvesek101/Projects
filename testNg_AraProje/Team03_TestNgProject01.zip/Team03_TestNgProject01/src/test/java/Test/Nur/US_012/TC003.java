package Test.Nur.US_012;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC003 extends BaseClass {

    //1.Kullanıcı URL'e  gider.
    //2.Kullanıcı olarak giriş yapar
    //3.Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
    //3. Kullanıcı  katogori box'taki  bir kategoriye tıklar
    //4. seçmek istediği birkaç ürünü seçer ve sepete ekler
    //5. Sepet sayfasında gidince bir ürün çıkartır ve ödeme sayfasına gider
    //6. Ödeme sayfasında çıkarttığı ürünün tekrar geldiğini görür



    MakeupPONur makeup=new MakeupPONur();

    @Test
    public void test() throws InterruptedException {


        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.visibilityDropdownMakeupCategories();
        makeup.clickCategoryFace();
        makeup.clickButonCart();
        makeup.clickButonCart2();
        makeup.clickSepet();
        makeup.clickXButtonInBasket();
        makeup.clickCheckout();
        makeup.assertionItemNumberInCheckout();














    }
}
