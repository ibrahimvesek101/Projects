package Test.Nur.US_010;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC004 extends BaseClass {

    //1-Kullanıcı URL' e gider
    //2.Kullanıcı olarak giriş yapar
    //2-Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
    //3-Arama işlemi başlatılır
    //4-Kullanıcı seçmek istediği ürünü search yapar
    //5- Seçtiği ürüne tıklar
    //6.Ürün detay sayfasına yönlendirilir
    //7. Ürün bilgisi açıklamasında ürün adı dışında farklı bir isimde bilgiye ulaşır
//


    MakeupPONur makeup=new MakeupPONur();

    @Test
    public void test() throws InterruptedException {


        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.sendKeyword("foundation");
        makeup.clickFirstProduct();
        makeup.falseProductDetailsAssertion();





}
}
