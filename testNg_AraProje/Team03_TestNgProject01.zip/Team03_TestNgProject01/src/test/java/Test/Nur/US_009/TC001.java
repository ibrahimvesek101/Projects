package Test.Nur.US_009;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC001 extends BaseClass {

    //  1-Kullanıcı URL'e gider
//  2.Kullanıcı olarak giriş yapar
//  3. Kullanıcı kategori, dropdown menüyü görüntüler
//  4-Kullanıcı anasayfadaki dropdown menüye tıklar
//  5-Kullanıcı dropdown menüye tıkladığında 'makeup' kategorisini görüntüler ve makeup'ı seçer
//  6- Kullanıcı makeup ürünlerinin olduğu sayfaya gider
//  7. Dropdown menuyu kapatır

    MakeupPONur makeup=new MakeupPONur();




    @Test
    public void test() {

        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.dropDownDisplay();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.goToMakeupURL();
        makeup.clickMenu();



    }




}






