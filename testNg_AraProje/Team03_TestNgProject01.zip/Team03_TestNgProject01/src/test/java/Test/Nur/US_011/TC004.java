package Test.Nur.US_011;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC004 extends BaseClass {

    //1-Kullanıcı URL' e gider
    //2.Kullanıcı olarak giriş yapar
    //3-Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
    //4-Kullanıcı ürün listesinden bir ürün seçer
    //5.Ürünü sepete aynı üründen birden fazla ekler
    //6. Kullanıcı sepete git ikonuna tıklar ve sepet sayfasına gider
    //7. Sepet sayfasında eklenen ürünün miktarını azaltır
    //8. Azaltılan ürün miktarına uygun olarak toplam fiyatın güncellendiğini doğrular
//

    MakeupPONur makeup=new MakeupPONur();

    @Test
    public void test() throws InterruptedException {


        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.clickBtnCartList();
        makeup.clickButtonCartMoreThanOne();
        makeup.clickSepet();
        makeup.assertionIcreaseAfterDecreaseTotalAmount();






    }
}
