package Test.Nur.US_010;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC005 extends BaseClass {

    //1-Kullanıcı URL' e gider
    //2. Kullanıcı olarak giriş yapar
    //3-2-Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
    //4. Ürürn listesinden bir ürün seçer
    //5. Sepete gider
    //6. Checkout yapar
    //7. Ödeme sayfasına yönlendirilir



    MakeupPONur makeup=new MakeupPONur();

    @Test
    public void test01() throws InterruptedException {


        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.clickButonCart();
        makeup.clickSepet();
        makeup.clickCheckout();
        makeup.clickCheckAvailability();
        makeup.clickPlaceOrder();
        makeup.clickPayButon();
        makeup.assertionPaymentURL();





}

}
