package Test.Nur.US_011;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC002 extends BaseClass {

    //1.Kullanıcı URL'e gider
    //2.Kullanıcı olarak giriş yapar
    //3. Ürün listesinden bir ürünü seçer.
    //4. View sayfasında ürün miktarını artırır.
    //6. Ürün miktarını azaltmak için azaltma düğmesine tıklar.
    //7. Ürün miktarının azaldığını doğrular.
//

    MakeupPONur makeup=new MakeupPONur();

    @Test
    public void test() throws InterruptedException {


        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.clickButonCart();
        makeup.clickButtonCartMoreThanOne();
        makeup.clickSepet();
        makeup.clickDecreaseButtonInBasket();
        makeup.cartQuantityAssertion();


}

}
