package Test.Nur.US_010;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC001 extends BaseClass {

//    1-Kullanıcı URL' e gider
//    2.Kullanıcı olarak giriş yapar
//    3-Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
//    4-Arama işlemi başlatılır
//    5-Kullanıcı seçmek istediği ürünü search yapar
//    6- Seçtiği ürüne tıklar
//    7.Ürün detay sayfasına yönlendirilir
//    8.Ürün  açıklamasını görüntüler
//    9. Ürün fiyatını görüntüler
   // 10.ürüne ait resimleri görüntüler
//    10.Ürünün stok bilgisini görüntüler
//    11. Favori ikonuna tıklar ürünü favorilere ekler
    //12.  Ürün kullanıcı değerlendirmelerini görür
    //13 Favori bağlantısına tıklar veya kullanıcı hesabında favorilerim sekmesinde ürünü görür
//



    MakeupPONur makeup=new MakeupPONur();




    @Test
    public void test02() throws InterruptedException {

        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.sendKeyword("Contour");
        makeup.clickFirstProduct();
        makeup.visibleProductDetails();
        makeup.visibleProductPrice();
        makeup.isDisplayStock();
        makeup.visibleProductReview();
        makeup.isDisplayedImages();
        makeup.clickFavoriteIcon();
        makeup.clickSellerLink();
       makeup.clickAccount();
        makeup.assertionFavorites();





    }
}
