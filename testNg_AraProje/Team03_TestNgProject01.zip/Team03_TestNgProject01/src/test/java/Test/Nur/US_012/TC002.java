package Test.Nur.US_012;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC002 extends BaseClass {

//    1.KullanıcıURL'e  gider.
//    2.Kullanıcı olarak giriş yapar
//    3.Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
//    4. Kullanıcı "Face" dropdown menüsünden bir ürün seçer.
//    5. Kullanıcı ürünü sepete ekler.
//    6. Kullanıcı "Eyes" dropdown menüsünden bir ürün seçer.
//    7. Kullanıcı ürünü sepete ekler.
//    8. Kullanıcı "Lips" dropdown menüsünden bir ürün seçer.
//    9. Kullanıcı ürünü sepete ekler.
//    10. Kullanıcı "Accessories" alt kategorisine gider.
//    11. Kullanıcı bir ürün seçer.
//    12. Kullanıcı ürünü sepete ekler.
//    13. Kullanıcı "Shaving Needs" alt kategorisine gider.
//    14. Kullanıcı bir ürün seçer.
//    15. Kullanıcı ürünü sepete ekler.
//    16. Kullanıcı eklediği ürünleri görüntüler ve ödeme sayfasına gider
    //17. Siapriş detayları kısmında verilen ürün miktarı ve toplam fiyat aynı olmalıdır
//



    MakeupPONur makeup=new MakeupPONur();

    @Test
    public void test() throws InterruptedException {


        makeup.goToHomePage();
        makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.visibilityDropdownMakeupCategories();
        makeup.addingToCartDropdownCatgories();
        makeup.clickSepet();
        makeup.assertionItemInBasket();
        makeup.clickCheckout();
        makeup.clickCheckAvailability();
        makeup.clickPlaceOrder();
        makeup.clickPayButon();
        makeup.assertionPaymentURL();
        makeup.assertionTotalAmountOrderPage();









    }

}
