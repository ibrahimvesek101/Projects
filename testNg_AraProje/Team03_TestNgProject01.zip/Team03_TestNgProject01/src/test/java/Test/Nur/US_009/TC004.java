package Test.Nur.US_009;

import Page.BaseClass;
import Page.MakeupPONur;
import org.testng.annotations.Test;

public class TC004 extends BaseClass {

//1-Kullanıcı URL' e gider
//2.Kullanıcı olarak giriş yapar
//2-Kullanıcı dropdown menü'ye tıklar ve makeup kategorisini seçer
//3-Arama çubuğuna "foundation" yazar
//4-Farklı ürün kategorilerine ait ürünlerı görüntüler (Apple,purse vb)
    //


    MakeupPONur makeup=new MakeupPONur();



    @Test
    public void test(){


        makeup.goToHomePage();
       makeup.joinMethod();
        makeup.clickMenu();
        makeup.clickMakeUp();
        makeup.clickMenu();
        makeup.sendKeyword("foundation");
        makeup.testProductCategories();


    }
}
