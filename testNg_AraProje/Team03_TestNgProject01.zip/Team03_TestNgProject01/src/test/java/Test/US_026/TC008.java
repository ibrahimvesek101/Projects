package Test.US_026;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC008  extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    minciGroceryPO gpo = new minciGroceryPO();

    @Test
    public void checkMoreLessButton() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("grocery");
        gpo.tools.waitForPageToLoad(5);

        gpo.tools.clickOn(gpo.getDivProductCards().get(0));
        gpo.tools.waitFor(gpo.getPnlProductDetailContainer());

        WebElement btnMoreLess = gpo.getBtnProductDetailMoreLess();
        String productDesc = gpo.getTxtProductDetailDescription().getText();
        gpo.tools.clickOn(gpo.getBtnProductDetailMoreLess());

        Assert.assertTrue(productDesc.length()<gpo.getTxtProductDetailDescription().getText().length());



    }
}
