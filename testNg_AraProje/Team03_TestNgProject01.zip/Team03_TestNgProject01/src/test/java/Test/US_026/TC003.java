package Test.US_026;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import javax.swing.*;

public class TC003 extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    minciGroceryPO gpo = new minciGroceryPO();

    @Test(priority = 0)
    public void checkSlideBar() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("grocery");
        gpo.tools.waitForPageToLoad(5);
    }

    @Test(dependsOnMethods = {"checkThreeItemsSeen"})
    public void checkArrows()  {
        WebElement middleItem = gpo.getDivSliderItems().get(1);
        By byMiddleElement = By.xpath("(//div[@id='offer']/div[@class='swiper-wrapper']/div[contains(@class,'swiper-slide')])[2]");
        //middleItem = Driver.getDriver().findElement(byMiddleElement);
        gpo.tools.scrollIntoJS(middleItem);
        Point pos1 = middleItem.getLocation();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        gpo.getBtnSliderNext().click();
        gpo.getDivSliderItems().forEach(i -> System.out.println(i.getLocation()));
        //middleItem = Driver.getDriver().findElement(byMiddleElement);
        Point pos2 = middleItem.getLocation();
        Assert.assertTrue(pos2.x<pos1.x, "Item should slide left");
        gpo.getBtnSliderPrevious().click();
        //middleItem = Driver.getDriver().findElement(byMiddleElement);
        Point pos3 = middleItem.getLocation();
        Assert.assertTrue(pos2.x>pos3.x, "Item should slide right");
        //System.out.println(pos3 + " < " + pos2);
    }

    @Test(dependsOnMethods = {"checkThreeItemsSeen"})
    public void slideByMouse() {
        WebElement middleItem = gpo.getDivSliderItems().get(1);
        Point pos1 = middleItem.getLocation();

        gpo.actions.clickAndHold(middleItem).moveByOffset(-50, 0 ).release().build().perform();
        Point pos2 = middleItem.getLocation();
        Assert.assertTrue(pos2.x>pos1.x, "Item should slide left");

    }


    @Test(dependsOnMethods = {"checkSlideBar"})
    public void checkThreeItemsSeen() {
        int i = 0;
        for (WebElement itm : gpo.getDivSliderItems()) {
            if (itm.isDisplayed()) i++;
        }
        Assert.assertEquals(i,3, "3 Items should be seen in the slide bar");
    }

}
