package Test.US_026;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.util.List;

public class TC002 extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    minciGroceryPO gpo = new minciGroceryPO();


    @Test
    public void searchInGrocery() throws InterruptedException {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("grocery");
        gpo.tools.waitForPageToLoad(5);
        gpo.searchInGrocery("apple");
        gpo.tools.waitForPageToLoad(5);
        Thread.sleep(3000);
        List<WebElement> searchResult = Driver.getDriver().findElements(By.xpath("//article[contains(@class,'product-card')]//img[@alt]"));
        for (WebElement we: searchResult) {
            System.out.println(we.getAttribute("alt"));
        }


    }
}
