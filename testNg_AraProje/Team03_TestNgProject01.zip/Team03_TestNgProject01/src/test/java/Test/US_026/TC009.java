package Test.US_026;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import Utilities.Driver;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC009  extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    minciGroceryPO gpo = new minciGroceryPO();

    @Test(priority = 0)
    public void checkProductDetailSliderByArrows() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("grocery");
        gpo.tools.waitForPageToLoad(5);

        gpo.tools.clickOn(gpo.getDivProductCards().get(0));
        gpo.tools.waitFor(gpo.getPnlProductDetailContainer());

        Point pos1 = gpo.getProductDetailPics().get(0).getLocation();
        gpo.tools.clickOn(gpo.getBtnProductSlideNext());
        Point pos2 = gpo.getProductDetailPics().get(0).getLocation();

        Assert.assertTrue(pos1.x>pos2.x, "Product images didn't slide");
    }

    @Test(dependsOnMethods = "checkProductDetailSliderByArrows")
    public void checkProductDetailSliderByMouse() {
        /*
            tp.gotoPickBazar();
            tp.clickCategoryMenu("grocery");
            gpo.tools.waitForPageToLoad(5);


        gpo.tools.clickOn(gpo.getDivProductCards().get(0));
        gpo.tools.waitFor(gpo.getPnlProductDetailContainer());
        */
        WebElement img = gpo.getProductDetailPics().get(0);
        Point pos1 = img.getLocation();
        Actions atc = new Actions(Driver.getDriver());
        atc.clickAndHold(img).moveByOffset(-50, 0 ).release().build().perform();
        Point pos2 = img.getLocation();
        System.out.println("pos1 = " + pos1);
        System.out.println("pos2 = " + pos2);
        Assert.assertTrue(pos1.x>pos2.x, "Product images didn't slide");
    }
}
