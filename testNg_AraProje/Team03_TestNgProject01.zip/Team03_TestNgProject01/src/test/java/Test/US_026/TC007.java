package Test.US_026;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC007  extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    minciGroceryPO gpo = new minciGroceryPO();

    @Test
    public void checkProductTitle() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("grocery");
        gpo.tools.waitForPageToLoad(5);

        String productName = gpo.tools.waitFor(gpo.getDivProductCards().get(0)).findElement(By.xpath("//h3")).getText();
        gpo.tools.clickOn(gpo.getDivProductCards().get(0));

        Assert.assertTrue(gpo.getPnlProductDetailContainer().isDisplayed(), "Detail didnt open");

        Assert.assertEquals(gpo.getTxtProductDetailHeader().getText(), productName, "product name does't match");



    }
}
