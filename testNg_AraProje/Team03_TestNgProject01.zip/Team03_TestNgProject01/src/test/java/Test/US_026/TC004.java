package Test.US_026;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC004 extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    minciGroceryPO gpo = new minciGroceryPO();

    @Test
    public void check30ItemsShown() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("grocery");
        gpo.tools.waitForPageToLoad(5);
        Assert.assertEquals(gpo.getDivProductCards().size(), 30, "There should be 30 items listed");
    }
}
