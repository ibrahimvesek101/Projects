package Test.US_026;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC001 extends BaseClass {
    minciGroceryPO gpo = new minciGroceryPO();
    @Test
    public void verifyMainHeader() throws InterruptedException {
        //gpo.gotoGroceryHomePage();
        TopPanelPO tp = new TopPanelPO();
        gpo.gotoPickBazar();
        Thread.sleep(2000);
        tp.clickCategoryMenu("bakery");
        tp.clickCategoryMenu("grocery");
        gpo.tools.waitForPageToLoad(5);
        //System.out.println("gpo.isLoggedIn() = " + tp.isLoggedIn());
        String txtHeader = gpo.getMainHeaderText();
        Assert.assertEquals(txtHeader, "Groceries Delivered in 90 Minute", "The Header for Groceries page not valid");
    }

}
