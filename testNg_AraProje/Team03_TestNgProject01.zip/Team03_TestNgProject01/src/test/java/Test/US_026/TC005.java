package Test.US_026;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC005 extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    minciGroceryPO gpo = new minciGroceryPO();

    @Test
    public void checkLoadMoreButton() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("grocery");
        gpo.tools.waitForPageToLoad(5);
        int itemsCount = gpo.getDivProductCards().size();
        gpo.tools.scrollIntoJS(gpo.getBtn_LoadMore());
        gpo.tools.clickOn(gpo.getBtn_LoadMore());
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(itemsCount<=gpo.getDivProductCards().size(), "More items should be loaded");
    }
}
