package Test.US_026;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TC006  extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    minciGroceryPO gpo = new minciGroceryPO();


    @Test(priority = 0)
    public void gotoPage() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("grocery");
        tp.tools.scrollIntoJS(gpo.getDivCatagoriesPanelItems().get(0));
    }
    @Test(dataProvider = "categoryList", dependsOnMethods = {"gotoPage"})
    public void checkProductCategoryPanel(String data) {

        boolean isIn = false;
        for (WebElement we : gpo.getDivCatagoriesPanelItems()) {
            if (we.getText().toLowerCase().equals(data.toLowerCase())){
                isIn = true;
            }
        }

        //boolean isIn = gpo.getDivCatagoriesPanelItems().stream().map(WebElement::getText).anyMatch(c->c.toLowerCase().equals(data.toLowerCase()));
        Assert.assertTrue(isIn, data + " not found");
    }

    @DataProvider(parallel = false)
    public Object[][] categoryList() {
        Object[][] list = new Object[10][1];
        list[0][0] = "Fruits & Vegetables";
        list[1][0] = "Meat & Fish";
        list[2][0] = "Snacks";
        list[3][0] = "Pet Care";
        list[4][0] = "Home & Cleaning";
        list[5][0] = "Dairy";
        list[6][0] = "Cooking";
        list[7][0] = "Breakfast";
        list[8][0] = "Beverage";
        list[9][0] = "Health & Beauty";
        return list;
    }
}
