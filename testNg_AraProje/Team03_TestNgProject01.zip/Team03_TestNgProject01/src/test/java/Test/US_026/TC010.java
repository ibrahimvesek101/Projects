package Test.US_026;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC010 extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    minciGroceryPO gpo = new minciGroceryPO();

    @Test(priority = 0)
    public void checkProductDetailRelatedProductsHeader() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("grocery");
        gpo.tools.waitForPageToLoad(5);

        gpo.tools.clickOn(gpo.getDivProductCards().get(0));
        gpo.tools.waitFor(gpo.getPnlProductDetailContainer());
        gpo.tools.scrollIntoJS(gpo.getTxtProductDetailsHeader());

        Assert.assertTrue(gpo.getTxtProductDetailsHeader().isDisplayed(), "Details not shown");
        Assert.assertTrue(gpo.getTxtRelatedProductsHeader().isDisplayed(), "Related Products Header not shown");

    }
}
