package Test.US_015_Test;

import Page.BagsPO_Ali;
import Page.LoginPO_Ali;
import Page.MakeUpPO_Ali;

import Utilities.Driver;
import org.testng.annotations.Test;

public class US015_Runner {
    LoginPO_Ali lg = new LoginPO_Ali();
    BagsPO_Ali bp = new BagsPO_Ali();

    @Test
    public void Test01() throws InterruptedException { //Kullanici urunu favorilere ekleyebilmelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        bp.bagsShopClick();
        bp.chooseProductBag(12);
        bp.favoriteClick();
//assert yapılacak
    }

    @Test
    public void Test02() throws InterruptedException {  //Kullanici urun kategorilerini goruntuleyebilmelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();


        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        bp.bagsShopClick();
        bp.chooseProductBag(7);
        bp.categoriesClick();
        bp.categoriesIsdisplayed();

    }

    @Test
    public void Test03() throws InterruptedException { //Kullanici urun stogundan fazla ekleme yapamamalidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        bp.bagsShopClick();
        bp.chooseProductBag(7);
        bp.addToCartButtonClick();
        bp.pieceAvailable();

    }


    @Test
    public void Test04() throws InterruptedException {//Kullanici Related Products bolumunde urun ile iliskili baska resimler gormelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        bp.bagsShopClick();
        bp.chooseProductBagScroll(7);
        bp.pruductPictures();

    }

    @Test
    public void Test05() throws InterruptedException { //kullanici eger urunlerde indirim varsa ilk fiyat ve indirimli fiyat ve indirim oranını görmelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        bp.bagsShopClick();
        bp.chooseProductBag(3);
        bp.firstPrice();
        bp.lastPrice();
        bp.discountRate();

    }

    @Test
    public void Test06() throws InterruptedException { //Kullanici urun linkine tiklayarak urun sayfasina gidebilmelidir
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        bp.bagsShopClick();
        bp.chooseProductBagScroll(3);

    }
}
