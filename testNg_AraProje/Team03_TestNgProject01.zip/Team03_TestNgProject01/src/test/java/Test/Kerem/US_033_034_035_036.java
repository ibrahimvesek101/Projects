package Test.Kerem;

import Page.Clothes.CheckOutPO;
import Page.Clothes.HomePagePO;
import Page.Clothes.KeyWordPO;
import Page.Clothes.My_Base;
import Utilities.Driver;
import org.testng.Assert;


public class US_033_034_035_036 {


    HomePagePO hp = new HomePagePO();
    KeyWordPO kp = new KeyWordPO();
    CheckOutPO co = new CheckOutPO();
    My_Base z = new My_Base();

    HomePagePO l = new HomePagePO();
    ;


    @org.testng.annotations.Test

    public void US_033_TC_001() throws InterruptedException {

        l.l();
        hp.giris();
        hp.departmantSec();
        z.z();
        Assert.assertTrue(Driver.getDriver().getCurrentUrl().contains("clothing"));
        kp.searchFor("ar");
        z.z();
        kp.KeywordurunGezme("ar");

        //test passed

    }

    @org.testng.annotations.Test

    public void US_034_TC_001() throws InterruptedException {

        l.l();
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.tumFonksiyonlariDene();

        //test passed
    }

    @org.testng.annotations.Test

    public void US_035_TC_001() throws InterruptedException {

        l.l();
        hp.giris();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.adetArtıEksiFiyatKontrolEt();

        //test passed
    }

    @org.testng.annotations.Test

    public void US_035_TC_002() throws InterruptedException {

        l.l();
        Thread.sleep(3000);
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.searchFor("ar");
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.stoktanFazlaSec();

        //test passed
    }


    @org.testng.annotations.Test

    public void US_036_TC_001() throws InterruptedException {

        l.l();
        hp.departmantSec();
        z.z();
        kp.searchFor("ar");
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.checkoutıkla();
        z.z();
        kp.loginmesajı();

        //test passed
    }


    @org.testng.annotations.Test


    public void US_036_TC_002() throws InterruptedException {
        l.l();
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.checkoutıkla();
        z.z();
        co.checkoutOk();

        //test passed
    }

    @org.testng.annotations.Test
    public void US_036_TC_003() throws InterruptedException {
        l.l();
        z.z();
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.checkoutıkla();
        z.z();
        co.AdresGuncelle();


    }

    @org.testng.annotations.Test

    public void US_036_TC_004() throws InterruptedException {
        l.l();
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.checkoutıkla();
        z.z();
        co.urunisimDogrula();

        //test passed


    }

    @org.testng.annotations.Test

    public void US_036_TC_005() throws InterruptedException {
        l.l();
        z.z();
        ;
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.checkoutıkla();
        z.z();
        co.delivery();

        //test passed

    }


    @org.testng.annotations.Test

    public void US_036_TC_006() throws InterruptedException {
        l.l();
        z.z();
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.checkoutıkla();
        z.z();
        co.kupon();

        // test passed
    }

    @org.testng.annotations.Test

    public void US_036_TC_007() throws InterruptedException {
        l.l();
        z.z();
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.checkoutıkla();
        z.z();
        co.placeorder();
    }

    @org.testng.annotations.Test

    public void US_036_TC_008() throws InterruptedException {
        l.l();
        z.z();
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.checkoutıkla();
        z.z();
        co.placeorder();

    }


    @org.testng.annotations.Test

    public void US_036_TC_009() throws InterruptedException {
        l.l();
        z.z();
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.checkoutıkla();
        z.z();
        co.checkKonrtol();

    }

    @org.testng.annotations.Test

    public void US_036_TC_010() throws InterruptedException {
        l.l();
        z.z();
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.checkoutıkla();
        co.orderstatuskontrolet();


    }


    @org.testng.annotations.Test

    public void US_036_TC_011() throws InterruptedException {
        l.l();
        z.z();
        hp.giris();
        z.z();
        hp.departmantSec();
        z.z();
        kp.chooseProduct(0);
        z.z();
        kp.sepeteEkle();
        z.z();
        kp.SepeteGıtt(Driver.getDriver());
        z.z();
        kp.checkoutıkla();
        z.z();
        co.sonkontrol();

        //test --

    }


}