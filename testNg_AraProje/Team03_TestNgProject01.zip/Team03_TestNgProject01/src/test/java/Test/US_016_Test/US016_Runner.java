package Test.US_016_Test;

import Page.BagsPO_Ali;
import Page.LoginPO_Ali;
import Page.MakeUpPO_Ali;
import Utilities.Driver;
import org.testng.annotations.Test;

public class US016_Runner {

    LoginPO_Ali lg = new LoginPO_Ali();
    BagsPO_Ali bp = new BagsPO_Ali();
    MakeUpPO_Ali mp = new MakeUpPO_Ali();
    @Test
    public void Test01() throws InterruptedException { //Sayfada iken secilen urun miktarinin degistirilmesi
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        bp.bagsShopClick();
        bp.cartClick();
        bp.plusClick();
      //  bp.minusClick();

    }
    @Test
    public void Test02() throws InterruptedException { //Sayfada ve sepete gittiğinde secilen urun miktari degistirilmek
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        lg.joinClick();
        lg.email();
        lg.password();
        lg.loginClick();
        bp.shopClick();
        bp.bagsShopClick();
        bp.cartClick();
        mp.itemsClick();
        bp.clickGoToCart();
       // bp.minusClickGoToCart();

    }
}
