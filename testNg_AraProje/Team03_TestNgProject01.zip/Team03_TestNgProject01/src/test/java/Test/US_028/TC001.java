package Test.US_028;

import Page.BaseClass;
import Page.TopPanelPO;
import Page.minciGroceryPO;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC001 extends BaseClass {
    minciGroceryPO gpo = new minciGroceryPO();

    @Test(priority = 0)
    public void addProductToBasket() {
        topPanel.gotoPickBazar();
        topPanel.clickCategoryMenu("grocery");
        gpo.tools.waitForPageToLoad(5);
        gpo.tools.scrollIntoJS(gpo.getBtnProductAdd());

        double itemCount = Double.parseDouble(gpo.getTxtBasketItemCount().getText().split(" ")[0]);
        double basketTotal = Double.parseDouble(gpo.getTxtBasketTotal().getText().substring(1));

        gpo.tools.clickOnJS(gpo.getBtnProductAdd());

        double itemCount2 = Double.parseDouble(gpo.getTxtBasketItemCount().getText().split(" ")[0]);
        double basketTotal2 = Double.parseDouble(gpo.getTxtBasketTotal().getText().substring(1));

        Assert.assertTrue(((itemCount<itemCount2) && (basketTotal<basketTotal2)), "basket total and item count have been increased");
    }
}
