package Test.US_014_Test;

import Page.BagsPO_Ali;
import Utilities.Driver;
import org.testng.annotations.Test;

public class US014_Runner {
    //kullanıcı, bags urun kategorisini sectigide urun arayabilmelidir
    //Search areadan urunleri keyword ile aradiginda listelenen urunlerde aranan keyword bulunmalidir

    @Test
    public void Test01() throws InterruptedException {
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        Driver.getDriver().manage().window().maximize();

        BagsPO_Ali bpo = new BagsPO_Ali();

        bpo.searchButtonClick();
        bpo.bagsClick();
        bpo.searchBox("armani");
        bpo.searchButtonClick();
        bpo.productListContains("armani");

    }

}
