package Test.Akif_Runner.US_07;

import Page.LoginPO;
import Page.akifPO.US_07.ProfileUpdate;
import Utilities.Driver;
import org.testng.annotations.Test;

public class US_07 {
    @Test
    public void shop() {
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        LoginPO login=new LoginPO();
        login.customerLogin();
        ProfileUpdate profileUpdate=new ProfileUpdate();
        profileUpdate.profileUpdate();
        profileUpdate.passwordUpdate();
        Driver.teardown();
    }
}
