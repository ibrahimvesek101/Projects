package Test.Akif_Runner.US_06;

import Page.akifPO.US06.HomePageJoin;
import Page.akifPO.US06.joginClassPage;
import Utilities.Driver;
import org.testng.annotations.Test;



public class testCaseDisplay {


    @Test
    public  void display(){


        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        joginClassPage lcp=new joginClassPage();
        lcp.loginPrivate();
        HomePageJoin hm=new HomePageJoin();
        hm.isDisplayed();
        Driver.teardown();

    }







}
