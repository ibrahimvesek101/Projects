package Test.Akif_Runner.US_05;

import Page.akifPO.US05.wisiblePO;
import Utilities.Driver;
import org.testng.annotations.Test;

public class US05_Wisible {
    @Test
    public void tc01() {
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        wisiblePO pc=new wisiblePO();
        pc.shopWisible();
        pc.assertadressandPhone();

    }


    }
