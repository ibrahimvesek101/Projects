package Test.Akif_Runner.US_05;

import Page.LoginPO;

import Page.akifPO.US05.Shopping;
import Utilities.Driver;
import org.testng.annotations.Test;

public class US05_Shop {
    @Test
    public void shop(){
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        LoginPO login=new LoginPO();
        login.customerLogin();
        Shopping sp=new Shopping();
        sp.clothingshop();
        sp.clothingshop();
        Driver.teardown();


    }

    }


