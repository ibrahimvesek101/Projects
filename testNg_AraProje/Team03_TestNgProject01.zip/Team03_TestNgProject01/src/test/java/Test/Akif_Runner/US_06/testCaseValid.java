package Test.Akif_Runner.US_06;

import Page.akifPO.US06.HomePageJoin;
import Page.akifPO.US06.joginClassPage;
import Utilities.Driver;
import org.testng.annotations.Test;

public class testCaseValid {


   @Test
   public  void valid(){//geçerli email ve şifre ile giriş


      Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");

      joginClassPage lp=new joginClassPage();
      lp.loginPrivate();
      HomePageJoin join=new HomePageJoin();
      join.validEmail();
      Driver.teardown();

   }



}
