package Test.Emine;

import Page.Emine.US01.TC_01;
import Page.Emine.US01.TC_03;
import Utilities.Driver;
import org.testng.annotations.Test;


public class US001_HomaPage {


    @Test
    public void testcase03() {

        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
            TC_01 bs = new TC_01();
            bs.sellerRegister();
            TC_03 shops = new TC_03();// Satici  Shop Create eder.
            shops.setShops();


        }
    }

