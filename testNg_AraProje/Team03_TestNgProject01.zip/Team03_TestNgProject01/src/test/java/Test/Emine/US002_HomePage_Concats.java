package Test.Emine;


import Page.Emine.US002_Concats.ConcatsPage;
import Utilities.Driver;
import org.testng.ITestContext;
import org.testng.annotations.Test;



public class US002_HomePage_Concats  {

    // CONCAT Sayfasinda iletisimbilgilerinin gorunurlugu kontrol edildi
    @Test
    public  void case01() {

        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        ConcatsPage concats = new ConcatsPage();  //ConcatsPage sayfasindan obje uretildi.
        concats.contactPage();//contactPage methodu cagrildi.
        concats.contactPageIletisimBilgileri();
        Driver.teardown();

    }

    //- Kullanıcı  "Qestions, Comments, Or Concerns?"  bölümünü aktif kullanabilir.
    @Test
    public void case07() throws InterruptedException {

        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        ConcatsPage concats = new ConcatsPage();
        concats.contactPage();
        concats.concatsBoxContol();
        Driver.teardown();
    }

    //Kullanıcı geçersiz email girdiğinde uyarıyı görebilir. PASSED
    @Test
    public void case08() throws InterruptedException {

        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        ConcatsPage concats = new ConcatsPage();
        concats.contactPage();
        concats.hataliEmail();
        Driver.teardown();
    }

    //Kullanıcı gerekli alanı boş bıraktığında uyarıyı görebilir.
    @Test
    public void case09() throws InterruptedException {

        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        ConcatsPage concats = new ConcatsPage();
        concats.contactPage();
        concats.bosBox();
        Driver.teardown();
    }




}
