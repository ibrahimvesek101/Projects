package Test.Emine;


import Page.Emine.US003_Faq.FaqPage;
import Page.LoginPO;
import Utilities.Driver;
import org.testng.annotations.Test;


/*
   1-Kullanıcı URL ye gider.
2-Kullanıcı FAQ sayfasında 4 soru ve 4 cevap olduğunu görür.
3-Kullanıcı + sembolüne bastığında -sembolüne dönüştüğünü ve sorunun cevabını  görür.

    */
public class US003_HomePage_Faq  {

    @Test
    public void case1() throws InterruptedException {

        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
        LoginPO login  =new LoginPO();
        login.customerLogin();
        FaqPage faQestions=new FaqPage();
        faQestions.fagPage();//faqPage methodu cagrildi
        faQestions.setAnswerOne();//setAnswerOne methodu cagrildi




    }

}
