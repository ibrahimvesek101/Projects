package Test.US_025;

import Page.BaseClass;
import Page.BooksPO;
import Page.TopPanelPO;
import Utilities.Driver;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;

public class TC006 extends BaseClass {

    TopPanelPO tp = new TopPanelPO();
    BooksPO bp = new BooksPO();

    @Test(priority = 0)
    public void clickSeeAll() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("books");
        bp.tools.waitForPageToLoad(5);
        bp.tools.clickOnJS(bp.getTopManufacturersSliderHeaderSeeAll());
        WebElement man_header = Driver.getDriver().findElement(By.xpath("//h1[.='Manufacturers/Publishers']"));
        Assert.assertTrue(man_header.isDisplayed(), "Manufacturers/Publishers header not visible");

    }

    @Test(dependsOnMethods = "clickSeeAll")
    public void checkManufacturerSearchResult() {
        String searchStr = "Too cool";
        bp.tools.sendKeys(bp.getTbManufacturersSearch(), searchStr);
        bp.tools.clickOnJS(bp.getBtnManufacturersSearch());
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        bp.tools.waitForPageToLoad(10);

        WebElement mwe = bp.tools.waitFor(By.xpath("//div[@title]"));
       // WebElement mwe = bp.tools.waitFor(Driver.getDriver().findElements(By.xpath("//div[@title]")).get(0));
        //= ; //bp.getManufacturersSearchResult().get(0);
        String      mname = mwe.getText();

        Assert.assertTrue(mname.contains(searchStr));
    }
    @Test(dependsOnMethods = "checkManufacturerSearchResult")
    public void openManufacturerPage() {
        bp = new BooksPO();
        Actions acts = new Actions(Driver.getDriver());
        //bp.getManufacturersSearchResult().forEach(m-> System.out.println(m.getText()));
        bp.tools.clickOn(bp.getManufacturersSearchResult().get(0));
        bp.tools.waitForPageToLoad(10);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        //bp = new BooksPO();
        //bp.tools.sendText(bp.getTbManufacturersSearch(),"a");
        bp.tools.waitFor(By.xpath("//input[@id='search' and @type='text']")).clear();
        bp.tools.sendText(bp.tools.waitFor(By.xpath("//input[@id='search' and @type='text']")),"a" + Keys.ENTER);
        //bp.tools.clickOnJS(bp.tools.waitFor(By.xpath("//button/span[@class='sr-only' and .='Search']")));
        //acts.moveToElement(bp.tools.waitFor(By.xpath("//button/span[@class='sr-only' and .='Search']"))).click();
        //bp.tools.clickOnJS(bp.getManufacturersSearchResult().get(0)); // click first result item
        //System.out.println("bp.getBtnManufacturersSearch().toString() = " + bp.getBtnManufacturersSearch().toString());
        //((JavascriptExecutor) Driver.getDriver()).executeScript("arguments[0].setAttribute('aria-valuenow', '1950');", bp.getPriceSliderMax());

        acts.clickAndHold(bp.getPriceSliderMax()).moveByOffset(120, 0).release().build().perform();
        bp.tools.waitForPageToLoad(10);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Point posSliderMax = bp.getPriceSliderMax().getLocation();

        bp.tools.clickOn(bp.getSortByList().get(2)); //.click(); // Sort - high to low
        bp.tools.waitForPageToLoad(10);

        int resultCount = bp.getProductSearchResultList().size();
        bp.tools.clickOnJS(bp.getTagsList().get(0));
        /*bp.getTagsList().forEach(t->{
            bp.tools.clickOnJS(t);

        });*/
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        Assert.assertNotEquals(resultCount,bp.getProductSearchResultList().size(), "Result count should be diffirent");

    }

    @Test(dependsOnMethods = {"openManufacturerPage"})
    public void clearAllFilters() {
        bp.getManufacturersFilterClearAll().click();
        boolean allClean = false;

        allClean = bp.getSortByList().get(0).isSelected();
        allClean = bp.getTbManufacturersSearch().getText().isEmpty();
        allClean = bp.tools.waitFor(By.xpath("//label[.='Max']/following-sibling::span")).getText().equals("1000");

        for (WebElement we:bp.getTagsList()) {
            if (we.isSelected()){
                allClean = false;break;
            }
        }

        Assert.assertTrue(allClean, "Some filters are still selected");
    }

    @Test(dependsOnMethods = {"clearAllFilters"})
    public void checkNoResult() {
        bp.tools.waitFor(By.xpath("//input[@id='search' and @type='text']")).clear();
        bp.tools.sendText(bp.tools.waitFor(By.xpath("//input[@id='search' and @type='text']")),"a3a2s1d3a2d" + Keys.ENTER);

        Assert.assertNotEquals(bp.getNotFoundMessage().isDisplayed(), "Not Found message shold be presented");
    }
}
