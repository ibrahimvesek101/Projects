package Test.US_025;

import Page.BaseClass;
import Page.BooksPO;
import Page.TopPanelPO;
import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC003 extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    BooksPO bp = new BooksPO();

    @Test(priority = 0)
    public void checkManufacturersCount() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("books");
        bp.tools.waitForPageToLoad(5);
        bp.tools.scrollIntoJS(bp.getTopManufacturersList().get(0));
        int shonwElementCount = 0;
        for(WebElement we: bp.getTopManufacturersList()) {
            if (we.isDisplayed()) shonwElementCount++;
        }
        Assert.assertEquals(shonwElementCount,4, "4 manufacturers not visible");

    }
}
