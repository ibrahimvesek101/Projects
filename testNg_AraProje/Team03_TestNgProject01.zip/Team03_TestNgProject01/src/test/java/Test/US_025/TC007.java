package Test.US_025;

import Page.BaseClass;
import Page.BooksPO;
import Page.TopPanelPO;
import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

//https://shop-pickbazar-rest.vercel.app/manufacturers/too-cool-publication
public class TC007 extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    BooksPO bp = new BooksPO();

    @Test(priority = 0)
    public void gotoManufacturer() {
        bp.tools.openUrl("https://shop-pickbazar-rest.vercel.app/manufacturers/too-cool-publication");
        bp.tools.waitForPageToLoad(5);
    }

    @Test(dependsOnMethods = {"gotoManufacturer"})
    public void checkSortLowToHigh() {
        List<WebElement> list1 = bp.getProductSearchResultPriceList();
        bp.tools.clickOnJS(bp.getSortByList().get(1));
        bp.tools.waitForPageToLoad(10);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        //bp = new BooksPO();
        List<WebElement> list2 = bp.getProductSearchResultPriceList(); //Driver.getDriver().findElements(By.xpath("//article[contains(@class,'product-card')]//span[starts-with(.,'$')]"));

        List<Double> ld = list2.stream().map(w->Double.parseDouble(w.getText().substring(1))).collect(Collectors.toList());
        boolean isSorted = true;
        for (int i = 0; i < ld.size()-1; i++) {
            if (ld.get(i)>ld.get(i+1)) {
                isSorted = false;
                break;
            }
        }
        Assert.assertTrue(isSorted, "result not sorted LowToHigh");

    }

    @Test(dependsOnMethods = {"gotoManufacturer"})
    public void checkSortHighToLow() {
        List<WebElement> list1 = bp.getProductSearchResultPriceList();
        bp.tools.clickOnJS(bp.getSortByList().get(2));
        bp.tools.waitForPageToLoad(10);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        //bp = new BooksPO();
        List<WebElement> list2 = bp.getProductSearchResultPriceList(); //Driver.getDriver().findElements(By.xpath("//article[contains(@class,'product-card')]//span[starts-with(.,'$')]"));

        List<Double> ld = list2.stream().map(w->Double.parseDouble(w.getText().substring(1))).collect(Collectors.toList());
        boolean isSorted = true;
        for (int i = 0; i < ld.size()-1; i++) {
            if (ld.get(i)<ld.get(i+1)) {
                isSorted = false;
                break;
            }
        }
        Assert.assertTrue(isSorted, "result not sorted HighToLow");

    }

    @Test(dependsOnMethods = {"gotoManufacturer"})
    public void checkTags() {
        List<WebElement> list1 = bp.getProductSearchResultList();
        for(WebElement we: bp.getCategoryList()) {
            bp.tools.clickOnJS(we);
            //bp.tools.sendKeys(we, Keys.SPACE);
            bp.tools.waitForPageToLoad(10);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

        bp.tools.waitForPageToLoad(10);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        bp = new BooksPO();
        List<WebElement> list2 = Driver.getDriver().findElements(By.xpath("//article[contains(@class,'product-card')]"));//bp.getProductSearchResultList();
        Assert.assertEquals(list2.size(), list1.size());

    }



}
