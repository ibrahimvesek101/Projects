package Test.US_025;

import Page.BaseClass;
import Page.BooksPO;
import Page.TopPanelPO;
import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC005 extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    BooksPO bp = new BooksPO();

    @Test(priority = 0)
    public void clickSeeAll() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("books");
        bp.tools.waitForPageToLoad(5);
        bp.tools.clickOnJS(bp.getTopManufacturersSliderHeaderSeeAll());
        WebElement man_header = Driver.getDriver().findElement(By.xpath("//h1[.='Manufacturers/Publishers']"));
        Assert.assertTrue(man_header.isDisplayed(), "Manufacturers/Publishers header not visible");

    }

    @Test(dependsOnMethods = "clickSeeAll")
    public void checkManufacturerSearchResult() {
        String searchStr = "Too cool";
        bp.tools.sendKeys(bp.getTbManufacturersSearch(), searchStr);
        bp.tools.clickOnJS(bp.getBtnManufacturersSearch());
        bp.tools.waitForPageToLoad(10);

        Assert.assertTrue(bp.getManufacturersSearchResult().get(0).getText().contains(searchStr));
    }
}
