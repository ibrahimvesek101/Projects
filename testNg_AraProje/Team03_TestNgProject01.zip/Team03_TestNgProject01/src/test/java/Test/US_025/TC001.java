package Test.US_025;

import Page.BaseClass;
import Page.BooksPO;
import Page.TopPanelPO;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC001 extends BaseClass {
    TopPanelPO  tp = new TopPanelPO();
    BooksPO     bp = new BooksPO();

    @Test
    public void checkTopManufacturers() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("books");
        bp.tools.waitForPageToLoad(5);

        bp.tools.scrollIntoJS(bp.getTopManufacturersSliderHeader());
        Assert.assertEquals(bp.getTopManufacturersSliderHeader().getText(), "Top Manufacturers", "Top Manufacturers not seen");
    }
}
