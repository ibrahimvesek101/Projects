package Test.US_025;

import Page.BaseClass;
import Page.BooksPO;
import Page.TopPanelPO;
import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC002 extends BaseClass {
    TopPanelPO tp = new TopPanelPO();
    BooksPO bp = new BooksPO();

    @Test(priority = 0)
    public void gotoBooks() {
        tp.gotoPickBazar();
        tp.clickCategoryMenu("books");
        bp.tools.waitForPageToLoad(5);
        //bp.tools.scrollIntoJS(bp.getTopManufacturersSliderHeader());
        bp.tools.scrollIntoJS(Driver.getDriver().findElement(By.xpath("//h3[.='Top Authors']")));
    }

    @Test(dependsOnMethods = {"gotoBooks"})
    public void slideTopManufacturersByArrows() {
        Point pos1 = bp.getTopManufacturersList().get(1).getLocation();
        bp.tools.clickOnJS(bp.getTopManufacturersNext());
        Point pos2 = bp.getTopManufacturersList().get(1).getLocation();
        System.out.println(pos1);
        System.out.println(pos2);
        Assert.assertTrue(pos1.x>=pos2.x, "Item images didn't slide");
    }

    @Test(dependsOnMethods = {"gotoBooks"})
    public void slideTopManufacturersByMouse() {
        Point pos1 = bp.getTopManufacturersList().get(1).getLocation();
        //bp.tools.clickOnJS(bp.getTopManufacturersNext());
        bp.actions.clickAndHold(bp.getTopManufacturersList().get(1)).moveByOffset(50,0).release().build().perform();
        Point pos2 = bp.getTopManufacturersList().get(1).getLocation();
        System.out.println(pos1);
        System.out.println(pos2);
        Assert.assertTrue(pos1.x>pos2.x, "Item images didn't slide");
    }


}
