package Page;

import Utilities.Driver;
import Utilities.WebElementTools;
import com.github.javafaker.Faker;
import org.apache.poi.ss.formula.functions.T;
import org.bouncycastle.jcajce.provider.symmetric.Serpent;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

public class MakeUpPO_Ali {
    WebElementTools tools = new WebElementTools(Driver.getDriver());
    JavascriptExecutor jse = (JavascriptExecutor) Driver.getDriver();

    public MakeUpPO_Ali() {
        PageFactory.initElements(Driver.getDriver(), this);
    }


    @FindBy(xpath = "//a[@href='/shops']")
    WebElement shop;


    @FindBy(xpath = "//a[@href='/shops/bags-shop']")
    WebElement bagsShop;
    // @FindBy(xpath = "//div[@data-component-type='s-search-result']")
    @FindBy(xpath = "//article[@class='product-card cart-type-helium h-full overflow-hidden rounded border border-border-200 bg-light transition-shadow duration-200 hover:shadow-sm']")
    List<WebElement> productList;
    @FindBy(xpath = "(//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 px-5'])[4]")
    WebElement plus; // +

    @FindBy(xpath = "//article[@class='product-card cart-type-helium h-full overflow-hidden rounded border border-border-200 bg-light transition-shadow duration-200 hover:shadow-sm']")
    List<WebElement> productList1;
    @FindBy(xpath = "//div[@class='mb-3 w-full lg:mb-0 lg:max-w-[400px]']")
    WebElement addShoppingCart;
    @FindBy(xpath = "*//span[text()=\"Makeup Shop\"]")
    WebElement makeupShop;
    @FindBy(xpath = "//a[@href='/shops/makeup-shop']")
    WebElement makeupShop1;
    @FindBy(xpath = "*//button[text()=\"Makeup Shop\"]") // urun seçılıp alışveriş sayfasına dönmek için basılan yer
    WebElement makeUp_Shop;
    @FindBy(xpath = "//button[@class='product-cart fixed top-1/2 z-40 -mt-12 hidden flex-col items-center justify-center rounded bg-accent p-3 pt-3.5 text-sm font-semibold text-light shadow-900 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 ltr:right-0 ltr:rounded-tr-none ltr:rounded-br-none rtl:left-0 rtl:rounded-tl-none rtl:rounded-bl-none lg:flex']")
    WebElement items;
    @FindBy(xpath = "*//span[text()=\"Checkout\"]")
    WebElement checkOut;

    @FindBy(xpath = "*//button[text()=\"Check Availability\"]")
    WebElement checkOutButton;
    @FindBy(xpath = "//div[@class='flex justify-between py-2']")
    WebElement order;
    @FindBy(xpath = "(//span[@class='text-sm text-body'])[3]")
    WebElement productSubTotal;

    public void productSubTotal() throws InterruptedException {
        Thread.sleep(1000);
        Assert.assertTrue(productSubTotal.isDisplayed());
    }

    public void orderIsDisplayed() throws InterruptedException {
        Thread.sleep(1000);
        Assert.assertTrue(order.isDisplayed());
    }

    public void chooseProduct(int index) throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(productList.get(index));
        // productList.get(index).click();
    }

    public void chooseProduct1(int index) {
        productList1.get(index).click();
    }

    public void addShoppingCart() {
        tools.clickOn(addShoppingCart);
    }

    public void makeupShop() throws InterruptedException {
        Thread.sleep(1000);
        tools.clickOn(makeUp_Shop);
        //Driver.getDriver().navigate().refresh();
    }

    public void itemsClick() {
        tools.clickOn(items);
    }

    public void checkOutClick() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(checkOut);

    }

    public void checkOutButtonClick() throws InterruptedException {
        Thread.sleep(1000);
        checkOutButton.click();
    }


    public void shopClick() {
        tools.clickOn(shop);
    }

    public void makeupShopClick() throws InterruptedException {
        tools.clickOn(makeupShop);
        Driver.getDriver().manage().window().maximize();

    }


    public void bagsShopClick() {
        tools.clickOn(bagsShop);
    }
    // Kullanici Contact Number, Billing Address, Shipping Address bilgilerini update edebilmelidir


    @FindBy(xpath = "(*//button[text()=\"Add\"])[1]")  //ContactNumber.click
    WebElement ContactNumber;
    @FindBy(xpath = "(//input[@type='tel'])[2]") // telefon numarası update sendkeys telnumber
    WebElement contactNumberUpdate;
    @FindBy(xpath = "*//button[text()=\"Contact\"]") // tel no gönderdikten sonra click yapılacak
    WebElement addContact;


    public void contactNumberClick() throws InterruptedException {
        Thread.sleep(1000);
        tools.clickOn(ContactNumber);
    }

    public void contactNumberUpdate() throws InterruptedException {
        Thread.sleep(2000);
        contactNumberUpdate.sendKeys("125642");
    }

    public void addContcatClick() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(addContact);
    }

    // Kullanici Contact Number, Billing Address, Shipping Address bilgilerini update edebilmelidir
    @FindBy(xpath = "(*//button[text()=\"Add\"])[2]")
    WebElement ShippingAddress;

    @FindBy(id = "title")
    WebElement title;

    @FindBy(id = "address.country")
    WebElement adressCountry;

    @FindBy(id = "address.city")
    WebElement adressCity;
    @FindBy(id = "address.state")
    WebElement adressState;
    @FindBy(id = "address.zip")
    WebElement adressZip;
    @FindBy(id = "address.street_address")
    WebElement Street_address;
    @FindBy(xpath = "(*//button[text()=\"Update\"])[2]")
    WebElement updateAddress;
    @FindBy(xpath = "(*//button[text()=\"Add\"])[1]") // billing address.click
    WebElement BillingAddress;
    @FindBy(xpath = "(//button[@class='flex h-5 w-5 items-center justify-center rounded-full bg-accent text-light'])[1]")
    WebElement adresKalemi;

    public void adresKalemiClick() throws InterruptedException {
        Thread.sleep(2000);
        adresKalemi.click();
    }

    @FindBy(xpath = "(//button[@class='flex h-5 w-5 items-center justify-center rounded-full bg-red-600 text-light'])[1]")
    WebElement delete;
    @FindBy(xpath = "(//button[@data-variant='custom'])[2]")
    WebElement deleteLast;

    public void deleteClick() throws InterruptedException {
        Thread.sleep(5000);
        delete.click(); // küçük çarpı işareti
        Thread.sleep(2000);
        deleteLast.click(); // soraki çıkan delete butonu

    }

    @FindBy(id = "headlessui-radiogroup-option-:rn:")
    List<WebElement> sonadresAdressList;

    @FindBy(id = "headlessui-radiogroup-option-:rg:")
    WebElement firstAddress;

    public void firstAddressGetText() {
        String adress = firstAddress.getText();
        System.out.println("adress = " + adress);
    }

    public void shippingAddressClick() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(ShippingAddress);
    }

    public void titleBillingAddress() {
        title.sendKeys("Billing Address");
    }

    public void titleShippingAddress() {
        title.sendKeys("Shipping Address");
    }

    public void adressCountry() throws InterruptedException {
        Thread.sleep(1000);
        adressCountry.sendKeys("Turkey");
    }

    public void adressCity() throws InterruptedException {
        Thread.sleep(1000);
        adressCity.sendKeys("Ankara");
    }

    public void adressState() throws InterruptedException {
        Thread.sleep(1000);
        adressState.sendKeys("Eryaman");
    }

    public void adressZip() throws InterruptedException {
        Thread.sleep(1000);
        adressZip.sendKeys("34100");
    }

    public void street_address() throws InterruptedException {
        Thread.sleep(1000);
        Street_address.sendKeys("5.cd.");
    }

    public void updateAddressClick() throws InterruptedException {
        Thread.sleep(3000);
        tools.clickOn(updateAddress);
    }

    public void AdresGuncelle() throws InterruptedException {

        JavascriptExecutor jse = (JavascriptExecutor) Driver.getDriver();
        adresKalemi.click();
        String ilkAdres = title.getAttribute("value");
        Faker faker = new Faker();
        String name = String.valueOf(faker.name());
        title.clear();
        title.sendKeys(name);
        jse.executeScript("arguments[0].click();", updateAddress);
        Thread.sleep(3000);
        jse.executeScript("arguments[0].click();", adresKalemi);
        String sonAdres = title.getAttribute("value");
        Assert.assertFalse(sonAdres == ilkAdres);
    }

    public void billingAddressClick() throws InterruptedException {
        Thread.sleep(1000);
        tools.clickOn(BillingAddress);
    }


    // Kullanici Delivery Schedule (teslimat programi) secebilmelidir

    @FindBy(id = "headlessui-radiogroup-:rc:")
    List<WebElement> DeliverySchedule;
    @FindBy(xpath = "*//span[text()=\"Evening\"]")
    WebElement evening;
    @FindBy(xpath = "*//button[text()=\"Check Availability\"]")
    WebElement checkAvailability;
    @FindBy(xpath = "*//p[text()=\"Do you have coupon?\"]")
    WebElement coupon;

    @FindBy(xpath = "*//a[text()=\"Offers\"]")
    WebElement offers;
    @FindBy(id = "code")
    WebElement code;
    @FindBy(xpath = "*//button[text()=\"Apply\"]")
    WebElement apply;
    @FindBy(xpath = "*//span[text()=\"Cash On Delivery\"]")
    WebElement choosePaymentMethod;

    @FindBy(xpath = "//span[@class='text-base font-semibold text-heading']")
    WebElement total;
    @FindBy(xpath = "//span[@class='flex items-center gap-1 text-sm text-body']")
       WebElement discountTotal;
    @FindBy(xpath = "*//button[text()='Place Order']")
    WebElement placeOrder;
    @FindBy(xpath = "//div[@class=' flex w-full flex-col py-7 md:flex-row md:items-start']")
    WebElement orderProcess;
    @FindBy(xpath = "//tbody[@class='rc-table-tbody']")
    WebElement cartInfo;

    @FindBy(id = "owner_name")
    WebElement sendKeysOwnerName;

    public void sendKeysOwnerName() throws InterruptedException {
        Thread.sleep(5000);
        sendKeysOwnerName.sendKeys("ali");
    }

    @FindBy(xpath = "//input[@class='InputElement is-complete Input']")
    WebElement cardNumber;

    public void sendKeysCardNumber() throws InterruptedException {
        Thread.sleep(5000);
        cardNumber.click();
        Thread.sleep(1000);
        cardNumber.sendKeys("5200828282828210");

    }

    @FindBy(xpath = "//input[@name='exp-date']")
    WebElement expirationDate;

    public void sendKeysExpirationDate() throws InterruptedException {
        Thread.sleep(5000);
        expirationDate.sendKeys("12");
        Thread.sleep(5000);
        expirationDate.sendKeys("26");
    }

    @FindBy(xpath = "(//div[@class='__PrivateStripeElement'])[3]")
    WebElement cvc;

    public void sendKeysCVC() throws InterruptedException {
        Thread.sleep(5000);
        cvc.sendKeys("632");
    }

    @FindBy(xpath = "*//button[text()='Pay']")
    WebElement payButton;

    public void payButtonClick() throws InterruptedException {
        Thread.sleep(1000);
        payButton.click();
    }

    public void cartInfoIsDisplayed() throws InterruptedException {
        Thread.sleep(3000);
        Assert.assertTrue(cartInfo.isDisplayed());
    }

    public void orderProcessIsDisplayed() throws InterruptedException {
        Thread.sleep(5000);
        Assert.assertTrue(orderProcess.isDisplayed());
    }
    @FindBy(id = "headlessui-menu-button-:rv:")
    WebElement myAccount;
    public void myAccountClick() throws InterruptedException {
        Thread.sleep(2000);
        myAccount.click();
    }
    @FindBy(xpath = "//button[text()=\"My Orders\" ]")
    WebElement myOrders;
    public void myOrdersClick() throws InterruptedException {
        Thread.sleep(5000);
        myOrders.click();
    }
@FindBy(xpath = "*//span[text()='Cash On Delivery']")
WebElement cashOndelivery;
    public void placeOrderClick() throws InterruptedException {
        Thread.sleep(2000);
        placeOrder.click();
        Assert.assertTrue(cashOndelivery.isDisplayed());
    }

    public void discountTotalIsDisplayed() throws InterruptedException {
        Thread.sleep(1000);
        String a =discountTotal.getText();
        System.out.println("a = " + a);

        Assert.assertTrue(discountTotal.isDisplayed());
    }

    public void choosePaymentMethodClick() throws InterruptedException {
        Thread.sleep(1000);
        choosePaymentMethod.click();
        Assert.assertTrue(choosePaymentMethod.isEnabled());
    }

    public void applyClick() throws InterruptedException {
        Thread.sleep(2000);
        apply.click();
    }

    public void codeSendKeys() throws InterruptedException {
        Thread.sleep(2000);
        code.sendKeys("BAZAR18");
    }

    public void offersClick() {
        offers.click();
    }

    public void couponClick() throws InterruptedException {
        Thread.sleep(2000);
        coupon.click();
    }

    public void checkAvailabilityClick() throws InterruptedException {
        Thread.sleep(1000);
        checkAvailability.click();
    }

    @FindBy(xpath = "(//div[@aria-checked='true'])[3]")
    WebElement eveningTrue;

    public void evening() throws InterruptedException {
        Thread.sleep(2000);
        evening.click();
        Thread.sleep(2000);
        Assert.assertTrue(evening.isEnabled());
    }

    public void chooseProductDeliverySch(int index) {
        DeliverySchedule.get(index).click();
    }

}
