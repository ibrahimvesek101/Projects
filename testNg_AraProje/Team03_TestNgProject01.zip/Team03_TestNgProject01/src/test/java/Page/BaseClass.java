package Page;

import Utilities.ConfigurationReader;
import Utilities.Driver;
import Utilities.TestNgListener;
import org.testng.annotations.*;

import java.time.Duration;

@Listeners(TestNgListener.class)
public class BaseClass {
    protected TopPanelPO topPanel = new TopPanelPO();

    @BeforeTest
    public void setup() {
        Driver.getDriver().manage().window().maximize();
        Driver.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }

    @AfterTest
    public void cleanup() throws InterruptedException {
        System.out.println("Driver is being closed down...");
       Thread.sleep(Integer.parseInt(ConfigurationReader.getProperty("sleepBeforeDriverClose")));
       Driver.teardown();
    }
}
