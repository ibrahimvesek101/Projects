package Page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class JoinOrSignInPO extends BasePO{
   public  JoinOrSignInPO(){
    }


   @FindBy(xpath = "//button[.='Join']")
   WebElement JoinButton;
    @FindBy(id="email")
    WebElement SigninEmail;

    @FindBy(id="password")
    WebElement SigninPassword;
    @FindBy(xpath= "//button[.=\"Login\"]")
    WebElement SigninJoinButtonClick;


    //Methods
    public void SignInJoinEmail(String email){

        SigninEmail.clear();
        tools.sendText(SigninEmail,email);
    }
    public void SignInJoinPassword(String password){

        SigninPassword.clear();
        tools.sendText(SigninPassword,password);
    }
    public void signInJoinClick(){
        tools.waitFor(SigninJoinButtonClick).click();
    }
    public void JoinButton(){
        tools.waitFor(JoinButton).click();
    }


}
