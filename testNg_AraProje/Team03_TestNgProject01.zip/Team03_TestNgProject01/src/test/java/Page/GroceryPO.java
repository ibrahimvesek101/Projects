package Page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class GroceryPO extends BasePO {

    public GroceryPO() {
        super();
    }

    /* Web Elements */
    @FindBy(xpath = "//h1[.='Groceries Delivered in 90 Minute']")
    WebElement hdr_GroceryMainHeader;
    @FindBy(xpath = "//input[@id='search']")
    WebElement tb_SearchBox;
    @FindBy(xpath = "//input[@id='search']//following-sibling::button[.='Search']")
    WebElement btnSearchMiddle; // search  button next to main search box (NOT the top one)

    @FindBy(xpath = "//div[@id='offer']/div[@class='swiper-wrapper']/div[contains(@class,'swiper-slide')]")
    List<WebElement> divSliderItems;
    @FindBy(xpath = "//div[@role='button' and .='Previous']")
    WebElement btnSliderPrevious;
    @FindBy(xpath = "//div[@role='button' and .='Next']")
    WebElement btnSliderNext;
    @FindBy(xpath = "//div[@class='px-5']/ul/li[@class='rounded-md py-1']")
    List<WebElement> divCatagoriesPanelItems;
    @FindBy(xpath = "//article[contains(@class,'product-card')]")
    List<WebElement> divProductCards;
    @FindBy(xpath = "//button[.='Load More']")
    WebElement btn_LoadMore;



}
