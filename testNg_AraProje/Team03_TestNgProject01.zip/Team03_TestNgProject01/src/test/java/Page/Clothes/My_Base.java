package Page.Clothes;

import Utilities.Driver;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;








public class My_Base  {    public My_Base(){
    PageFactory.initElements(Driver.getDriver(), this);
}


    @FindBy(id = "search")
    WebElement txtSearch;



    public void searchFor(String key){
        txtSearch.sendKeys(key + Keys.ENTER);
    }

  public void z () throws InterruptedException {

      Thread.sleep(3000);


  }



}

