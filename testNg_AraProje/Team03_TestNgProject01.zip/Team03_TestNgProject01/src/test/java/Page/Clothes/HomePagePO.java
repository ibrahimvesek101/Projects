package Page.Clothes;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class HomePagePO extends My_Base {
    Duration timeout = Duration.ofSeconds(10);
    WebDriverWait wait = new WebDriverWait(Driver.getDriver(), timeout);

    public void tt(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
        element.click();
    }


    public HomePagePO() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = "*//button[text()=\"Join\"]")
    WebElement join;
    @FindBy(xpath = "*//button[text()=\"Register\"]")
    WebElement register;
    @FindBy(id = "name")
    WebElement name;
    @FindBy(id = "email")
    WebElement email;
    @FindBy(id = "password")
    WebElement password;
    @FindBy(xpath = "*//button[text()=\"Login\"]")
    WebElement login;
    @FindBy(id = "headlessui-menu-button-:Rpp4m:")
    WebElement butondepartmansec;
    @FindBy(xpath = ("//span[text()='Clothing']"))
    WebElement Clothes;


    public void giris() throws InterruptedException {
        tt(join);
        email.clear();
        email.sendKeys("bxhdbdgchdhsdhsdh@gmail.com");
        Thread.sleep(3000);
        password.clear();
        password.sendKeys("123456");
        tt(login);

    }

    public void password() {
        password.clear();
        password.sendKeys("123456");
    }

    public void departmantSec() throws InterruptedException {
        tt(butondepartmansec);
        tt(Clothes);
    }
    public void l (){
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");

    }



}
