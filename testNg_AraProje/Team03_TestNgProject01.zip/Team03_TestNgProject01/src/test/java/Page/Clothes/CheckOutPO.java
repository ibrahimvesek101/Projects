package Page.Clothes;

import Utilities.Driver;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.github.javafaker.Faker;

import java.time.Duration;

public class CheckOutPO {
    Duration timeout = Duration.ofSeconds(10);
    WebDriverWait wait = new WebDriverWait(Driver.getDriver(), timeout);

    public void tt(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
        element.click();
    }

    JavascriptExecutor jsExecutor = (JavascriptExecutor) Driver.getDriver();

    public CheckOutPO() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = "//button[contains(@class, 'bg-accent') and contains(text(), 'Check Availability')]")
    WebElement checkAvailabilityButton;
    @FindBy(xpath = "(*//button[text()=\"Update\"])[2]")
    WebElement updateButton;
    @FindBy(xpath = "//input[@class='form-control !p-0 ltr:!pr-4 rtl:!pl-4 ltr:!pl-14 rtl:!pr-14 !flex !items-center !w-full !appearance-none !transition !duration-300 !ease-in-out !text-heading !text-sm focus:!outline-none focus:!ring-0 !border !border-border-base ltr:!border-r-0 rtl:!border-l-0 !rounded ltr:!rounded-r-none rtl:!rounded-l-none focus:!border-accent !h-12']")
    WebElement phoneInput;
    @FindBy(css = "input.form-control")
    WebElement phoneNumberInput;
    @FindBy(xpath = "(//button[@class='flex h-5 w-5 items-center justify-center rounded-full bg-accent text-light'])[1]")
    WebElement adresKalemi;
    @FindBy(id = "title")
    WebElement title;
    @FindBy(xpath = "(*//button[text()=\"Update\"])[2]")
    WebElement updateAddress;
    @FindBy(xpath = "//div[@class='flex justify-between py-2']/div[@class='flex items-center justify-between text-base']")
    WebElement urunisimson;
    @FindBy(id = " headlessui-radiogroup-option-:rl:")
    WebElement expresDelevery;
    @FindBy(xpath = "//span[@class='flex items-center gap-1 text-sm text-body']")
    WebElement discountTotal;
    @FindBy(xpath = ("//span[text()='Magnetic Designs Women Printed Fit And Flare Dress - Red/S']"))
    WebElement urunisimilk;
    @FindBy(xpath = "(//span[@class='text-sm font-semibold text-heading md:text-base'])[1]")
    WebElement urunilkfiyat;
    @FindBy(id = "headlessui-radiogroup-option-:rm:")
    WebElement morning;
    @FindBy(id = "headlessui-radiogroup-option-:ro:")
    WebElement afternoon;
    @FindBy(id = "headlessui-radiogroup-option-:rn:")
    WebElement noon;
    @FindBy(id = " headlessui-radiogroup-option-:rp:")
    WebElement evening;
    @FindBy(xpath = "(//div[@class='flex items-center']")
    WebElement urunSonFiyat;
    @FindBy(xpath = "*//p[text()=\"Do you have coupon?\"]")
    WebElement kupon;
    @FindBy(id = "code")
    WebElement code;
    @FindBy(xpath = "*//button[text()=\"Apply\"]")
    WebElement apply;
    @FindBy(xpath = "*//button[text()='Place Order']")
    WebElement placeOrder;
    @FindBy(id = "headlessui-radiogroup-option-:r14:")
    WebElement cashOndelivery;
    //div[@class='flex items-center justify-between text-base']
    @FindBy(xpath = "*//div[@class='flex items-center justify-between text-base']")
    WebElement uruson;
    @FindBy(xpath = "//svg[contains(@class, 'h-4 w-4 stroke-2') and contains(@class, 'ltr:mr-0.5 rtl:ml-0.5')]")
    WebElement AddButton;

    @FindBy(xpath = "(//div[@class='mb-5 flex items-center justify-between md:mb-8']/div[@class='flex items-center space-x-3 rtl:space-x-reverse md:space-x-4']/span)[5]")
    WebElement order;



    @FindBy(xpath = "//p[text()='Please select and fill all the fields and place your order']")
    private WebElement message;

    @FindBy(id = "headlessui-radiogroup-:r10:")
    WebElement odemeMetod;

    public void checkoutOk() {
        checkAvailabilityButton.isDisplayed();

    }

    //public void telGuncelle() throws InterruptedException {

    //    JavascriptExecutor js = (JavascriptExecutor) Driver.getDriver();
    //    js.executeScript("arguments[0].value = '';", phoneNumberInput);
    //    phoneNumberInput.sendKeys("123456789");


    public void AdresGuncelle() throws InterruptedException {


        adresKalemi.click();
        String ilkadres = title.getAttribute("value");
        Thread.sleep(4000);
        Faker faker = new Faker();
        String name = String.valueOf(faker.name());
        title.clear();
        title.sendKeys(name);
        Thread.sleep(3000);
        jsExecutor.executeScript("arguments[0].click();", updateButton);
        Thread.sleep(3000);
        jsExecutor.executeScript("arguments[0].click();", adresKalemi);
        String sonadres = title.getAttribute("value");
        Assert.assertFalse(sonadres == ilkadres);


    }

    public void urunisimDogrula() throws InterruptedException {
        String ilk = urunisimilk.getText();
        String son = urunisimson.getText();
        Assert.assertTrue(son.contains(ilk));

    }


    public void delivery() throws InterruptedException {

        jsExecutor.executeScript("window.scrollBy(0, 500)");


        noon.isDisplayed();
        //  afternoon.isSelected();
        //  evening.isSelected();
        // morning.isSelected();


    }

    public void kupon() throws InterruptedException {

        tt(checkAvailabilityButton);
        Thread.sleep(2000);
        jsExecutor.executeScript("arguments[0].click();", kupon);
        Thread.sleep(2000);
        code.sendKeys("BAZAR18");
        Thread.sleep(2000);
        jsExecutor.executeScript("arguments[0].click();", apply);
        Thread.sleep(2000);
        String a = discountTotal.getText();
        System.out.println("a = " + a);
        Assert.assertTrue(discountTotal.isDisplayed());


    }

    public void placeorder() throws InterruptedException {
        tt(checkAvailabilityButton);
        Thread.sleep(2000);
        jsExecutor.executeScript("arguments[0].click();", placeOrder);
        Thread.sleep(2000);
        jsExecutor.executeScript("arguments[0].click();", cashOndelivery);
        Assert.assertTrue(placeOrder.isEnabled());


    }

    public void checkKonrtol() throws InterruptedException {
        tt(checkAvailabilityButton);
        Thread.sleep(2000);
        jsExecutor.executeScript("arguments[0].click();", cashOndelivery);
        Thread.sleep(2000);
        uruson.isDisplayed();

    }

    public void order() throws InterruptedException {
        tt(checkAvailabilityButton);
        Thread.sleep(2000);
        jsExecutor.executeScript("arguments[0].click();", cashOndelivery);
        jsExecutor.executeScript("arguments[0].click();", placeOrder);
    }

    public void c() throws InterruptedException {
        checkAvailabilityButton.click();
        Thread.sleep(2000);
        jsExecutor.executeScript("arguments[0].click();", AddButton);


    }

    public void adres(WebDriver driver) throws InterruptedException {

        Actions actions = new Actions(driver);
        actions.click().perform();
        jsExecutor.executeScript("arguments[0].click();", adresKalemi);
        Thread.sleep(3000);

    }

    public void sonkontrol() {

        tt(checkAvailabilityButton);
        jsExecutor.executeScript("window.scrollBy(0, 500)");
        // cashOndelivery.isEnabled();
        order.isDisplayed();
        // odemeMetod.isDisplayed();
        //order.isDisplayed();



    }
public void orderstatuskontrolet(){
    tt(checkAvailabilityButton);

    jsExecutor.executeScript("window.scrollBy(0, 500)");






}
    public void placeorderss() throws InterruptedException {
        tt(checkAvailabilityButton);
        Thread.sleep(2000);
        jsExecutor.executeScript("arguments[0].click();", placeOrder);
}}