package Page.Clothes;

import Utilities.Driver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class OrderPo {
    Duration timeout = Duration.ofSeconds(10);
    WebDriverWait wait = new WebDriverWait(Driver.getDriver(), timeout);
    JavascriptExecutor jsExecutor = (JavascriptExecutor) Driver.getDriver();

    public OrderPo() {
        PageFactory.initElements(Driver.getDriver(), this);
    }


    @FindBy(xpath = "//span[@class='px-3 py-1 rounded-full text-sm text-light bg-status-processing bg-opacity-[.15] text-status-processing min-h-[2rem] items-center justify-center text-[9px] !leading-none xs:text-sm inline-flex']")
    private WebElement orderStatusElement;


    public void orderControl() {


        orderStatusElement.isDisplayed();

    }
}