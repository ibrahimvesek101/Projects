package Page.Clothes;

import Utilities.Driver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;

public class KeyWordPO extends My_Base {

    JavascriptExecutor jsExecutor = (JavascriptExecutor) Driver.getDriver();
    Duration timeout = Duration.ofSeconds(10);
    WebDriverWait wait = new WebDriverWait(Driver.getDriver(), timeout);


    public void tt(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
        element.click();
    }


    public KeyWordPO() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = "//span[text()='Add To Shopping Cart']")
    WebElement sepetEkle;
    @FindBy(xpath = "//div[@role='button' and contains(@class, 'cursor-pointer') and contains(@class, 'whitespace-nowrap') and contains(@class, 'rounded') and contains(@class, 'border-border-200') and contains(@class, 'bg-gray-50') and contains(@class, 'px-4') and contains(@class, 'py-3') and contains(@class, 'text-sm') and contains(@class, 'text-heading') and contains(@class, 'transition-colors') and contains(@class, 'border') and text()='S']")

    WebElement S;
    @FindBy(xpath = "//div[@role='button' and contains(@class, 'cursor-pointer') and contains(@class, 'whitespace-nowrap') and contains(@class, 'rounded') and contains(@class, 'border-border-200') and contains(@class, 'bg-gray-50') and contains(@class, 'px-4') and contains(@class, 'py-3') and contains(@class, 'text-sm') and contains(@class, 'text-heading') and contains(@class, 'transition-colors') and contains(@class, 'border') and text()='M']")
    WebElement M;
    @FindBy(xpath = "//div[@role='button' and contains(@class, 'cursor-pointer') and contains(@class, 'whitespace-nowrap') and contains(@class, 'rounded') and contains(@class, 'border-border-200') and contains(@class, 'bg-gray-50') and contains(@class, 'px-4') and contains(@class, 'py-3') and contains(@class, 'text-sm') and contains(@class, 'text-heading') and contains(@class, 'transition-colors') and contains(@class, 'border') and text()='L']")
    WebElement L;
    @FindBy(xpath = "//div[@role='button' and contains(@class, 'cursor-pointer') and contains(@class, 'whitespace-nowrap') and contains(@class, 'rounded') and contains(@class, 'border-border-200') and contains(@class, 'bg-gray-50') and contains(@class, 'px-4') and contains(@class, 'py-3') and contains(@class, 'text-sm') and contains(@class, 'text-heading') and contains(@class, 'transition-colors') and contains(@class, 'border') and text()='XL']")
    WebElement XL;
    @FindBy(xpath = "//button[contains(@class, 'flex') and contains(@class, 'w-full') and contains(@class, 'items-center') and contains(@class, 'justify-center') and contains(@class, 'rounded') and contains(@class, 'bg-accent') and contains(@class, 'py-4') and contains(@class, 'px-5') and contains(@class, 'text-sm') and contains(@class, 'font-light') and contains(@class, 'text-light') and contains(@class, 'transition-colors') and contains(@class, 'duration-300') and contains(@class, 'hover:bg-accent-hover') and contains(@class, 'focus:bg-accent-hover') and contains(@class, 'focus:outline-0') and contains(@class, 'lg:text-base')]/span[text()='Add To Shopping Cart']")
    WebElement addToCartButton;
    @FindBy(xpath = "(//img[contains(@class, 'object-contain')])[16]")
    WebElement productImage1;
    @FindBy(xpath = "(//img[contains(@class, 'object-contain')])[17]")
    WebElement productImage2;
    @FindBy(xpath = "(//img[contains(@class, 'object-contain')])[18]")
    WebElement productImage3;
    @FindBy(xpath = "//button[@class='mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-gray-300 transition-colors mr-1']")
    WebElement fvr;
    @FindBy(xpath = "(//span[@class='h-full w-full rounded-full border border-border-200' and @style='background-color: rgb(206, 31, 106);'])[1]")
    WebElement renk1;
    @FindBy(xpath = "(//span[@class='h-full w-full rounded-full border border-border-200' and @style='background-color: rgb(206, 31, 106);'])[2]")
    WebElement renk2;
    @FindBy(xpath = "//button[contains(@class, 'product-cart')]")
    WebElement Sepet;
    @FindBy(xpath = "//article[@class='product-card cart-type-xenon h-full transform overflow-hidden rounded border border-border-200 border-opacity-70 bg-light transition-all duration-200 hover:-translate-y-0.5 hover:border-transparent hover:shadow']")
    List<WebElement> productList;
    @FindBy(xpath = "//button[contains(@class, 'cursor-pointer') and @title='']")
    WebElement arttırbuttonElement;
    @FindBy(xpath = "//button[contains(@class, 'cursor-pointer') and not(contains(@class, 'hover:!bg-gray-100'))]")
    WebElement eksiltbuttonElement;
    @FindBy(xpath = "//button[contains(@class, 'flex') and contains(@class, 'h-12') and contains(@class, 'w-full') and contains(@class, 'justify-between') and contains(@class, 'rounded-full') and contains(@class, 'bg-accent') and contains(@class, 'p-1') and contains(@class, 'text-sm') and contains(@class, 'font-bold') and contains(@class, 'shadow-700') and contains(@class, 'transition-colors') and contains(@class, 'hover:bg-accent-hover') and contains(@class, 'focus:bg-accent-hover') and contains(@class, 'focus:outline-0') and contains(@class, 'md:h-14')]")
    WebElement checkOut;
    @FindBy(xpath = "//p[contains(@class, 'my-2.5') and contains(@class, 'font-semibold') and contains(@class, 'text-accent')]")
    WebElement ilkFiyat;
    @FindBy(xpath = "//span[contains(@class, 'font-bold') and contains(@class, 'text-heading') and contains(@class, 'ltr:ml-auto') and contains(@class, 'rtl:mr-auto')]")
    WebElement sonFiyat;

    @FindBy(xpath = "//button[contains(@class, 'hover:bg-accent-hover')]")
    WebElement eksilt;

    @FindBy(xpath = "//span[contains(@class, 'font-bold') and contains(text(), '$35.00')]")
    WebElement eksilmisFiyat;

    @FindBy(xpath = "(//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 px-5'])[4]")
    WebElement Artir;

    @FindBy(xpath = "//p[contains(@class, 'mt-4') and contains(@class, 'mb-8') and contains(@class, 'text-center') and contains(@class, 'text-sm') and contains(@class, 'text-body') and contains(@class, 'sm:mt-5') and contains(@class, 'sm:mb-10') and contains(@class, 'md:text-base')]")
    WebElement loginMessage;


    public void KeywordurunGezme(String urunAdı) {
        boolean dogrurunaranmis = true;
        for (WebElement product : productList)
            if (product.getText().contains(urunAdı)) {
                continue;
            } else {
                dogrurunaranmis = false;
            }

        Assert.assertTrue(dogrurunaranmis = true);
    }


    public void chooseProduct(int index) {
        productList.get(index).click();
    }

    public void tumFonksiyonlariDene() {

        renk2.isEnabled();
        addToCartButton.isDisplayed();
        S.isEnabled();
        M.isEnabled();
        L.isEnabled();
        XL.isEnabled();
        productImage1.isEnabled();
        productImage2.isEnabled();
        productImage3.isEnabled();
        fvr.isDisplayed();

    }

    public void sepeteEkle() throws InterruptedException {
        Thread.sleep(3000);
        jsExecutor.executeScript("arguments[0].click();", renk1);
        jsExecutor.executeScript("arguments[0].click();", S);
        Thread.sleep(3000);
        jsExecutor.executeScript("arguments[0].click();", sepetEkle);


    }


    public void SepeteGıtt(WebDriver driver) throws InterruptedException {

        Actions actions = new Actions(driver);
        actions.click().perform();
        jsExecutor.executeScript("arguments[0].click();", Sepet);
        Thread.sleep(3000);

    }

    public void adetArtıEksiFiyatKontrolEt() throws InterruptedException {

        jsExecutor.executeScript("arguments[0].click();", arttırbuttonElement);

        Thread.sleep(3000);

        double fistprice = Double.parseDouble(ilkFiyat.getText().substring(1));

        Thread.sleep(3000);

        double lastprice = Double.parseDouble(sonFiyat.getText().substring(1));


        Assert.assertTrue(fistprice * 2 == lastprice);

        Thread.sleep(3000);


    }


    public void stoktanFazlaSec() throws InterruptedException {
        jsExecutor.executeScript("arguments[0].scrollIntoView(true);", Artir);
        boolean stokDogru = true;
        int adet = 1;
        while (Artir.isEnabled()) {

            Artir.click();
            adet=adet+1;
            if (adet > 500) {
                stokDogru = false;
                break;
            }
        } Assert.assertTrue(stokDogru = true);


    }

    public void checkoutıkla() {
        tt(checkOut);

    }

    public void loginmesajı() {

        loginMessage.isDisplayed();
    }


}






