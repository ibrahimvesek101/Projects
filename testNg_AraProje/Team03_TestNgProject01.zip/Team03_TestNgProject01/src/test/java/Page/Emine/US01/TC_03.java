package Page.Emine.US01;

import Utilities.Driver;
import com.github.javafaker.Faker;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import java.time.Duration;

public class TC_03 {



    public TC_03() {
        PageFactory.initElements(Driver.getDriver(), this);
    }
    WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));

    @FindBy(xpath="//*[text()='Create Shop']")
    private WebElement shops;
    @FindBy(xpath = "//input[@id='name']")
    private WebElement shopName;
    @FindBy(xpath ="(//div/span)[4]")
    WebElement myShops;
    public  void setShops(){    //Shop  Create edilme islemleri
        shops.click();
        Faker f=new Faker();
        Actions actions = new Actions(Driver.getDriver());
        actions.click(shopName)
                .sendKeys("bilisim market").sendKeys(Keys.TAB)
                .sendKeys("bilişim dünyası burada ").sendKeys(Keys.TAB)
                .sendKeys(f.name().fullName()).sendKeys(Keys.TAB)
                .sendKeys(f.internet().emailAddress()).sendKeys(Keys.TAB)
                .sendKeys("mavi şehir").sendKeys(Keys.TAB)
                .sendKeys("123654").sendKeys(Keys.TAB)
                .sendKeys(f.address().country()).sendKeys(Keys.TAB)
                .sendKeys(f.address().cityName()).sendKeys(Keys.TAB)
                .sendKeys(f.address().fullAddress()).sendKeys(Keys.TAB)
                .sendKeys("987412336544").sendKeys(Keys.TAB)
                .sendKeys(f.address().fullAddress()).sendKeys(Keys.TAB)
                .sendKeys("bahar aprt").sendKeys(Keys.TAB)
                .sendKeys("1000000").sendKeys(Keys.TAB)
                .sendKeys(f.internet().ipV6Address()).sendKeys(Keys.TAB).sendKeys(Keys.TAB)// Website
                .sendKeys(Keys.ENTER).sendKeys(Keys.ENTER).perform();
        Assert.assertTrue(myShops.isDisplayed());// Shop un Create edildigi dogrulanir

    }}

