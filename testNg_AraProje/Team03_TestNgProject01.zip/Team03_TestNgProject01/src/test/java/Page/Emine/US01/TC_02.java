package Page.Emine.US01;


import Utilities.Driver;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import java.time.Duration;

public class TC_02 {  //Login satıcı işlemleri
    public TC_02() {
        PageFactory.initElements(Driver.getDriver(),this);}

    WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));

    @FindBy(linkText = "Become a Seller")
    WebElement becomeSeller;
    @FindBy(className = "ms-1")
    WebElement login;
    @FindBy(id = "email")
    private WebElement boxEmail;
    @FindBy(id = "password")
    private WebElement boxPassword;
    @FindBy(tagName = "button")
    WebElement login2;
    @FindBy(xpath ="(//div/span)[7]")
    WebElement myShops;

    public void loginBtn(){

        wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));

       becomeSeller.click();

        Driver.getDriver().switchTo().newWindow(WindowType.TAB);

        Driver.getDriver().get("https://admin-pickbazar-rest.vercel.app/register");

        wait.until(ExpectedConditions.elementToBeClickable(login)).click();

        Actions actions = new Actions(Driver.getDriver());
        actions.click(boxEmail).doubleClick(boxEmail).
                sendKeys(Keys.BACK_SPACE+"alis@gmail.com").perform();
        actions.click(boxPassword).doubleClick(boxPassword)
                .sendKeys(Keys.BACK_SPACE+"12567"+Keys.TAB+Keys.ENTER).perform();
        wait.until(ExpectedConditions.urlToBe("https://admin-pickbazar-rest.vercel.app/login"));
        wait.until(ExpectedConditions.visibilityOf(login2)).click();
        wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
       Assert.assertTrue(myShops.isDisplayed());// Giris islemi dogrulandi


    }
}
