package Page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;

import java.util.List;

public class BooksPO extends BasePO {
    @FindBy(xpath = "//h3[.='Top Manufacturers']")
    WebElement topManufacturersSliderHeader;
    @FindBy(xpath = "//a[@href='/manufacturers' and .='See all']")
    WebElement topManufacturersSliderHeaderSeeAll;
    @FindBy(xpath = "//div[@class='relative']/div[@id='author-card-menu']/div[@class='swiper-wrapper']/div[contains(@class,'swiper-slide')]")
    List<WebElement> topManufacturersList;
    @FindBy(xpath = "(//div[contains(@class,'author-slider-prev')])[2]")
    WebElement topManufacturersPrev;
    @FindBy(xpath = "(//div[contains(@class,'author-slider-next')])[2]")
    WebElement topManufacturersNext;
    @FindBy(xpath = "//input[@id='search' and @type='text']")
    WebElement tbManufacturersSearch;
    @FindBy(xpath = "//button/span[@class='sr-only' and .='Search']")
    WebElement btnManufacturersSearch;
    @FindBy(xpath = "//div[@title]")
    List<WebElement> ManufacturersSearchResult;

    @FindBy(xpath = "//Button[.='Clear all']")
    WebElement ManufacturersFilterClearAll;

    @FindBy(xpath = "//div[@class='rc-slider-handle rc-slider-handle-1']")
    WebElement priceSliderMin;
    @FindBy(xpath = "//div[@class='rc-slider-handle rc-slider-handle-2']") //valuenow="1000"
    WebElement priceSliderMax;
    @FindBy(xpath = "//div[@class='flex items-center']/input[@type='checkbox']")
    List<WebElement> categoryList;

    @FindBy(xpath = "//article[contains(@class,'product-card')]")
    List<WebElement> productSearchResultList;
    @FindBy(xpath = "//article[contains(@class,'product-card')]//span[starts-with(.,'$')]")
    List<WebElement> productSearchResultPriceList;

    @FindBy(xpath = "//h3[contains(.,'Sorry')]")
    WebElement notFoundMessage;

    @FindBy(xpath = "//div[contains(@id,'radiogroup-option') and @role='radio']")
    List<WebElement> sortByList;


    /*      Getters         */
    public List<WebElement> getProductSearchResultList() {
        return productSearchResultList;
    }

    public List<WebElement> getProductSearchResultPriceList() {
        return productSearchResultPriceList;
    }

    public WebElement getTopManufacturersSliderHeader() {
        return topManufacturersSliderHeader;
    }

    public WebElement getTopManufacturersSliderHeaderSeeAll() {
        return topManufacturersSliderHeaderSeeAll;
    }

    public List<WebElement> getTopManufacturersList() {
        return topManufacturersList;
    }

    public WebElement getTopManufacturersPrev() {
        return topManufacturersPrev;
    }

    public WebElement getTopManufacturersNext() {
        return topManufacturersNext;
    }

    public WebElement getTbManufacturersSearch() {
        return tbManufacturersSearch;
    }

    public WebElement getBtnManufacturersSearch() {
        return btnManufacturersSearch;
    }

    public List<WebElement> getManufacturersSearchResult() {
        return ManufacturersSearchResult;
    }

    public WebElement getManufacturersFilterClearAll() {
        return ManufacturersFilterClearAll;
    }

    public WebElement getPriceSliderMin() {
        return priceSliderMin;
    }

    public WebElement getPriceSliderMax() {
        return priceSliderMax;
    }

    public List<WebElement> getCategoryList() {
        return categoryList.subList(0,categoryList.size()/2-1);
    }

    public List<WebElement> getTagsList() {
        return categoryList.subList(categoryList.size()/2-1, categoryList.size()-1);
    }

    public WebElement getNotFoundMessage() {
        return notFoundMessage;
    }

    public List<WebElement> getSortByList() {
        return sortByList;
    }

    /*      Methods         */
    public void searchInBooks() {

    }

}
