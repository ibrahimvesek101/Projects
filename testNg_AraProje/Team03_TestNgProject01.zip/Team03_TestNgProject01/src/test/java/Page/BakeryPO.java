package Page;

import Utilities.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class BakeryPO extends BasePO{
    @FindBy(xpath = "//button[.='Join']")
    WebElement JoinButton;
    @FindBy(id="email")
    WebElement SigninEmail;

    @FindBy(id="password")
    WebElement SigninPassword;
    @FindBy(xpath= "//button[.='Login']")
    WebElement SigninJoinButtonClick;

@FindBy(xpath = "(//a[@class='flex items-center font-normal text-heading no-underline transition duration-200 hover:text-accent focus:text-accent'])[1]")
    WebElement shops;
@FindBy(xpath = "(//span[@class='mb-2 text-lg font-semibold text-heading'])[6]")
WebElement grocery;
@FindBy(xpath = "(//span[@class='mb-2 text-lg font-semibold text-heading'])[5]")
WebElement bakery;


@FindBy(xpath = "(//span[@class='whitespace-nowrap'])[1]")
WebElement grocery1;
@FindBy(xpath = "(*//span[text()='Bakery'])")
WebElement bakery1;
@FindBy(xpath = "(//button[@data-variant='normal'])[1]")
WebElement loadMore;
@FindBy(xpath = "(//img[@alt='Coffee & Tea'])[1]")
WebElement coffeeTea1;
@FindBy(xpath = "(//img[@alt='Nescafe Clasico Instant Coffee, 2 x 10.5 oz'])[1]")
WebElement nescafeClasic;
@FindBy(xpath = "(*//span[@text()='Add To Shopping Cart'])[3]")
WebElement addToCart;
@FindBy(xpath = "//h1[@class='text-lg font-semibold tracking-tight text-heading md:text-xl xl:text-2xl cursor-pointer transition-colors hover:text-accent']")
WebElement productCart;
@FindBy(xpath = "(//del[@class='text-xs text-body ltr:ml-2 rtl:mr-2 md:text-sm'])[2]")
WebElement firstPrice;
@FindBy(xpath = "(//span[@class='text-sm font-semibold text-heading md:text-base'])[4]")
WebElement lastPrice;
@FindBy(xpath = "(//div[@class='absolute top-3 rounded bg-accent px-1.5 text-xs font-semibold leading-6 text-light ltr:left-3 rtl:right-3 sm:px-2 md:top-[22px] md:px-2.5 ltr:md:left-4 rtl:md:right-4'])[2]")
WebElement indirimOrn;




//ürünler
    @FindBy(xpath = "(//img[@class='object-contain'])[2]")
    WebElement juice;
    @FindBy(xpath = "(//img[@class='object-contain'])[3]")
    WebElement coffeeTea;
    @FindBy(xpath = "(//img[@class='object-contain'])[4]")
    WebElement cookies;
    @FindBy(xpath = "(//img[@class='object-contain'])[5]")
    WebElement roundCake;
    @FindBy(xpath = "(//img[@class='object-contain'])[6]")
    WebElement pitaBread;
    @FindBy(xpath = "(//img[@class='object-contain'])[7]")
    WebElement slicedCake;
    @FindBy(xpath = "(//img[@class='object-contain'])[8]")
    WebElement muffin;
    @FindBy(xpath = "(//img[@class='object-contain'])[9]")
    WebElement danish;
    @FindBy(xpath = "(//img[@class='object-contain'])[10]")
    WebElement croissants;
    @FindBy(xpath = "(//img[@class='object-contain'])[11]")
    WebElement feeterPies;
    @FindBy(xpath = "(//img[@class='object-contain'])[12]")
    WebElement toastLoaf;
    @FindBy(xpath = "(//img[@class='object-contain'])[13]")
    WebElement softBread;











public void shopsPage() {
    shops.click();
}
public void groceryPage() {
    grocery.click();
}
public void bakeryPage() {
    bakery.click();
}
public void grocery1() {
    grocery1.click();
}
public void bakery1() {
    bakery1.click();
}
public void loadMore() {loadMore.click();}
public void coffeeTea1() {coffeeTea1.click();}
public void nescafeClasic() {nescafeClasic.click();}
public void addToCart() {addToCart.click();}
public void productCart() {productCart.isDisplayed();}
public void firstPrice() {firstPrice.isDisplayed();}
public void lastPrice() {lastPrice.isDisplayed();}
public void indirimOrn() {indirimOrn.isDisplayed();}





public void juice(){
    juice.isDisplayed();
}
public void coffeeTea(){
    coffeeTea.isDisplayed();
}
public void cookies(){
    cookies.isDisplayed();
}
public void roundCake(){
    roundCake.isDisplayed();
}
public void pitaBread(){
    pitaBread.isDisplayed();
}
public void slicedCake(){
    slicedCake.isDisplayed();
}
public void muffin(){
    muffin.isDisplayed();
}
public void danish(){
    danish.isDisplayed();
}
public void croissants(){
    croissants.isDisplayed();
}
public void feeterPies(){
    feeterPies.isDisplayed();
}
public void toastLoaf(){
    toastLoaf.isDisplayed();
}
public void softBread() {
    softBread.isDisplayed();
}
public void bakeryList() {
    List<WebElement> bakeryList = Driver.getDriver().findElements(By.name("juice,coffeeTea,cookies,roundCake,pitaBread," +
            "slicedCake,muffin,danish,croissants,feeterPies,toastLoaf,softBread"));


    }






}
