package Page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePagePickBazarPO extends BasePO{
    public HomePagePickBazarPO(){
    }
    @FindBy(linkText = "Become a Seller")
    WebElement lnk_becomeseller;

    public void clickonBecomeAseller(){
        tools.waitFor(lnk_becomeseller).click();
    }





    public void goToBecomesellerPage(){
        tools.openUrl("https://shop-pickbazar-rest.vercel.app/");
    }
}
