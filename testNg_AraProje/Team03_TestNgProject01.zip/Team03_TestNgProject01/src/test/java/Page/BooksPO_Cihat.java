package Page;

import Utilities.Driver;
import Utilities.WebElementTools;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

import static Utilities.Driver.getDriver;

public class BooksPO_Cihat extends BasePO{

    JavascriptExecutor js = (JavascriptExecutor) Driver.getDriver();
    WebElementTools tools = new WebElementTools(Driver.getDriver());

    public BooksPO_Cihat() {
        PageFactory.initElements(Driver.getDriver(), this);
    }


    //Webelementler

    //Açılır sayfaya git
    @FindBy(xpath = "(//button[@aria-expanded='false'])[1]")
    public WebElement firstPage;

    public void firstPage() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(firstPage);
    }

    //Books sayfasına git
    //Kullanıcı sayfaya scroll down yaparak sonuna gidip gelebilmeli ve doğrulamalı
    @FindBy(xpath = "//span[contains(text(),'Books')]")
    public WebElement btnBooksPage;

    public void btnBooksPage() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(btnBooksPage);
        js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
        Thread.sleep(2000);
    }

    @FindBy(xpath = "//img[@src='/payment/master.png']")
    public WebElement masterCardIsVisible;

    public void masterCardIsVisible() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(masterCardIsVisible.isDisplayed());
        js.executeScript("window.scrollTo(0,document.body.scrollTop)");
    }

    @FindBy(xpath = "//img[@alt='book banner']")
    public WebElement imgofTopofPage;

    public void imgofTopofPage() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(imgofTopofPage.isDisplayed());

    }

    //Kullanıcı ürünün üzerine tıklayarak ürün detayına gidebilmeli
    @FindBy(xpath = "(//a[@title='The children story'])[1]")
    public WebElement lnkBookPage;

    public void lnkBookPage() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(lnkBookPage);
    }

    @FindBy(xpath = "//p[@class='text-sm leading-relaxed text-body']")
    public WebElement detailsLinkBookPage;

    public void detailsLinkBookPage() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(detailsLinkBookPage);
    }

    //Kullanıcı ürünün başlığını doğrulamalı
    @FindBy(xpath = "//p[@class='text-sm text-body']")
    public WebElement titleLinkBookPage;

    public void titleLinkBookPage() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(titleLinkBookPage.isDisplayed());
        tools.waitFor(titleLinkBookPage).click();
    }

    //Kullanıcı ürünün önceki sayfadaki fiyatı ile detay sayfasındaki fiyatın aynı olduğunu doğrulamalı
    @FindBy(xpath = "//ins[@class='text-2xl font-bold text-heading no-underline md:text-3xl']")
    public WebElement priceLinkBookPage;

    public void priceLinkBookPage() throws InterruptedException {
        js.executeScript("window.scrollTo(0,document.body.scrollTop)");
        Thread.sleep(2000);
        priceLinkBookPage.isDisplayed();
        //Assert.assertEquals(detailsLinkBookPage,priceLinkBookPage);
    }

    //Kullanıcı See more See Less buttonlarının çalıştığını doğrulamalı
    @FindBy(xpath = "//button[@class='mt-1 inline-block font-bold text-accent '] ")
    public WebElement seeMorelink;

    public void seeMorelink() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(seeMorelink.isDisplayed());
    }

    //Kullanıcı + ve - tıklayarak spariş vereceği ürün sayısı seçebilmeli
    @FindBy(xpath = "//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:" +
            "bg-accent-hover focus:outline-0 border border-gray-300 px-5 hover:border-accent hover:" +
            "!bg-transparent hover:!text-accent ltr:rounded-r rtl:rounded-l']")
    public WebElement plusBtn;

    public void plusBtn() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(plusBtn);
    }


    @FindBy(xpath = "//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:" +
            "bg-accent-hover focus:outline-0 border border-gray-300 px-5 hover:border-accent hover:" +
            "!bg-transparent ltr:rounded-l rtl:rounded-r']")
    public WebElement minusBtn;

    public void minusBtn() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(minusBtn);
    }

    //Kullanıcı Add to Cart buttonunu kullanarak spariş işlemleri yapabilmeli
    @FindBy(xpath = "(//button[@data-variant='normal'])[2]")
    public WebElement addToCartButton;

    public void addToCartButton() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(addToCartButton);
    }

    //Kullanıcı kalp buttonunun select ve unselect olduğunu doğrulamalı
    @FindBy(xpath = "(//button[@type='button'])[2]")
    public WebElement heartbtn;

    public void heartbtn() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(heartbtn);
    }

    @FindBy(xpath = "(//*[contains(text(), 'Login')])[3]")
    public WebElement loginButton;

    public void loginButton() throws InterruptedException {
        Thread.sleep(2000);
        loginButton.click();
    }


    @FindBy(xpath = "(//button[@type='button'])[3]")
    public WebElement loginButton1;

    public void loginButton1() throws InterruptedException {
        Thread.sleep(2000);
        loginButton1.click();
    }


    //Kullanıcı scroll barın çalıştığınıdoğrulamalı ve scroll yaparak Details başlığını doğrulamalı
    //Kullanıcı scroll yaparak Recent drop downın çalıştığını doğrulamalı
    @FindBy(xpath = "(//div[@class=' css-1ek5eys-singleValue'])[1]")
    public WebElement recentbtn;

    public void recentbtn() throws InterruptedException {
        Thread.sleep(2000);
        js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
        Thread.sleep(2000);
        Assert.assertTrue(recentbtn.isDisplayed());
    }


    //Kullanıcı scroll yaparak All Star drop downın çalıştığını doğrulamalı
    @FindBy(xpath = "(//div[@class=' css-1ek5eys-singleValue'])[2]")
    public WebElement allStartbtn;

    public void allStartbtn() throws InterruptedException {
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);
        Assert.assertTrue(allStartbtn.isDisplayed());
    }

    //Kullanıcı scroll yaparak Ask seller a question butonun çalıştığını doğrulamalı
    @FindBy(xpath = "(//*[contains(text(), 'Ask seller a question')])[1]")
    public WebElement askSellerbtn;

    public void askSellerbtn() throws InterruptedException {
        js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
        Thread.sleep(2000);
        Assert.assertTrue(askSellerbtn.isDisplayed());
    }

    //Kullanıcı Top Authors başlığını doğrulamalı
    @FindBy(xpath = "(//*[contains(text(), 'Top Authors')])[1]")
    public WebElement topAuthorsbtn;

    public void topAuthorsbtn() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(topAuthorsbtn.isDisplayed());

    }

    //Kullanıcı ana ekranda 7 yazar gördüğünü doğrulamalı
    //Kullanıcı SVG (Scalable Vector Graphics) Slider ile yazarlar da swipe yapabilmeli

    @FindBy(xpath = "//div[@id='author-card-menu']/div[@class='swiper-wrapper']//a[contains(@href,'/authors/')]")
     List<WebElement> sliders;
     public void slider() throws InterruptedException {
         Thread.sleep(2000);
         int i=0;
         for (WebElement element : sliders) {
             if (element.isDisplayed()){
                 i++;

             }
             System.out.println(element.getText());
         }
         Assert.assertTrue(i>6,"ekranda 7 yazar görünmeli");

     }
     @FindBy(xpath = "(//span[@class='sr-only' and .='Next'])[2]")
     WebElement sliderNext;

     public void sliderNext() throws InterruptedException {
         Thread.sleep(2000);
         tools.clickOnJS(sliderNext);
     }


    //Kullanıcı See All linkinin çalıştığını dorulamalı ve bütün yazarları görebilmeli
    @FindBy(xpath = "(//div[@class='flex items-center justify-between mb-7 '])[5]//a")
    public WebElement seeAll;

    public void seeAll() throws InterruptedException {
        Thread.sleep(2000);
        js.executeScript("window.scrollTo(0,document.body.scroll)");
        seeAll.click();
    }

    //Kullanıcı Search input kısmında yazar arayabilmeli ve doğrulamalı
    @FindBy(id = "search")
    public WebElement input_searchBox;


    //Search box sendkeys
    public void sendKeyword(String key) throws InterruptedException {
        Thread.sleep(2000);
        tools.sendText(input_searchBox,key + Keys.ENTER);


    }

    @FindBy(xpath = "//div[@class='mx-auto w-full py-8 lg:py-14 xl:py-20']//span")
    WebElement kellyWhiteButton;

    public void kellyWhiteButton() throws InterruptedException {
        Thread.sleep(2000);
        kellyWhiteButton.click();
    }
    //Kullanıcı ilgli yazarın description kısmında Read More and Less butonunun çalıştığını doğrulamalıdır
    @FindBy(xpath = "(//*[contains(text(), 'Read more')])[1]")
    public WebElement readMore;

    public void readMore() throws InterruptedException {
        Thread.sleep(2000);
        readMore.click();
    }

    @FindBy(xpath = "(//*[contains(text(), 'Less')])[1]")
    public WebElement less;

    public void less() throws InterruptedException {
        Thread.sleep(2000);
        less.click();
    }

    //Kullanıcı scroll down yaparak Author Books başlığını ve yazarın kitaplarını doğrulamalıdır
    @FindBy(xpath = "(//*[contains(text(), 'Author Books')])[1]")
    public WebElement authorBooks;

    public void authorBooks() throws InterruptedException {
        Thread.sleep(2000);
        js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
        Thread.sleep(2000);
        Assert.assertTrue(authorBooks.isDisplayed());
    }


}











