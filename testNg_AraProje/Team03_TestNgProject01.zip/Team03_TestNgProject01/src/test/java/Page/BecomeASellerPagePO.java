package Page;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BecomeASellerPagePO extends BasePO {


   public BecomeASellerPagePO(){

   }

//Webelementler

   @FindBy(id="name")
    public WebElement tb_name;
   @FindBy(id="email")
     WebElement tb_mail;
   @FindBy(id="password")
    WebElement tb_pass;
   @FindBy(xpath = "//button[.='Register']")
    WebElement btn_becomeAsellerRegister;
    @FindBy(xpath="(//img)[2]")
    WebElement verifyBecomeSellerPage;


   //Methods..
    public void verifyBecomeSeller(){
        tools.isVisible(verifyBecomeSellerPage);
    }

    public void enterName(String name){
        tools.sendText(tb_name,name);
    }

    public void enterEmail(String email){
        tools.sendText(tb_mail,email);
    }
    public void enterPassword(String pass){
        tools.sendText(tb_pass,pass);
    }

    public void clickonRegister(){
        tools.waitFor(btn_becomeAsellerRegister).click();
    }
    public void goToBecomesellerPage(){
        tools.openUrl("https://shop-pickbazar-rest.vercel.app/");
    }











}
