package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TopPanelPO extends BasePO {
    @FindBy(xpath = "//a[@href='/']")
    WebElement PageLogo;
    @FindBy(xpath = "//a[.='Shops']")
    WebElement topPanelShopsLink;
    @FindBy(xpath = "//a[.='Offers']")
    WebElement topPanelOffersLink;
    @FindBy(xpath = "//a[.='FAQ']")
    WebElement topPanelFAQLink;
    @FindBy(xpath = "//a[.='Contact']")
    WebElement topPanelContactLink;
    @FindBy(xpath = "//a[.='Become a Seller']")
    WebElement topPanelBecomeLink;
    @FindBy(xpath = "//li/button[.='Join']")
    WebElement topPanelJoinLink;
    @FindBy(xpath = "//button[@id='headlessui-menu-button-:r2:']//img[@alt]")
    WebElement topPanelLoggedinButton;

    @FindBy(xpath = "//input[@id='grocery search at header']")
    WebElement topPanelSearchBox;
    @FindBy(xpath = "(//button[.='Search'])[0]")
    WebElement topPanelSearchButton;
    @FindBy(id = "headlessui-menu-button-:R3kkm:")
    WebElement topPanelCategoriesButton;
    @FindBy(id = "headlessui-menu-items-:r1p:")
    WebElement topPanelCategoriesPanel;

    public boolean isLoggedIn() {
        if (topPanelJoinLink!=null) {
            return !topPanelJoinLink.isDisplayed();
        }
        return true;
    }

    public void clickCategoryMenu(String catagory){
        tools.clickOn(topPanelCategoriesButton);
        switch (catagory.toLowerCase()) {
            case "grocery" :
                tools.clickOn(new By.ByXPath("//div[contains(@id,'headlessui-menu-item') and contains(.,'Grocery')]"));
                break;
            case "bakery" :
                tools.clickOn(new By.ByXPath("//div[contains(@id,'headlessui-menu-item') and contains(.,'Bakery')]"));
                break;
            case "makeup" :
                tools.clickOn(new By.ByXPath("//div[contains(@id,'headlessui-menu-item') and contains(.,'Makeup')]"));
                break;
            case "bags" :
                tools.clickOn(new By.ByXPath("//div[contains(@id,'headlessui-menu-item') and contains(.,'Bags')]"));
                break;
            case "clothing" :
                tools.clickOn(new By.ByXPath("//div[contains(@id,'headlessui-menu-item') and contains(.,'Clothing')]"));
                break;
            case "furniture" :
                tools.clickOn(new By.ByXPath("//div[contains(@id,'headlessui-menu-item') and contains(.,'Furniture')]"));
                break;
            case "daily needs" :
                tools.clickOn(new By.ByXPath("//div[contains(@id,'headlessui-menu-item') and contains(.,'Daily Needs')]"));
                break;
            case "books" :
                tools.clickOn(new By.ByXPath("//div[contains(@id,'headlessui-menu-item') and contains(.,'Books')]"));
                break;
        }
        //tools.clickOn(topPanelCategoriesButton);
    }

}
