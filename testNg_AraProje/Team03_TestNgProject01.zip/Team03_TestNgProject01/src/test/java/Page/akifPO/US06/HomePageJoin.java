package Page.akifPO.US06;

import Utilities.Driver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import java.time.Duration;

import static Utilities.JSUtils.driver;

public class HomePageJoin  {

    public HomePageJoin() {

        PageFactory.initElements(Driver.getDriver(),this);

    }

    @FindBy(xpath ="//input[@id='email']")
    WebElement email;

    @FindBy(xpath ="//input[@id='password']")
    WebElement password;


    @FindBy(xpath ="//button[text()='Login']")
    WebElement login;

    @FindBy(xpath ="//button[text()='Login with Google']")
    WebElement loginGoogle;

    @FindBy(xpath ="(//button[.='Login with Mobile number']")
    WebElement loginMobileNumber;

    @FindBy(xpath = "(//button[@data-variant='normal'])[5]")
    WebElement register;

    @FindBy(xpath ="//p[@class='mt-2 text-xs text-red-500']")
    WebElement errorMessage1;

    @FindBy(xpath ="//p[@class='text-sm']")
    WebElement errorMessage2;


    WebDriverWait wait=new WebDriverWait(Driver.getDriver(),Duration.ofSeconds(10));
     public void validEmail (){


         wait.until(ExpectedConditions.elementToBeClickable(email)).click();

      Actions action=new Actions(Driver.getDriver());
      action.click(email).doubleClick(email)
              .sendKeys(Keys.BACK_SPACE+"kerem@demo.com").perform();
      action.click(password).doubleClick(password).sendKeys(Keys.BACK_SPACE+"demodemo"+Keys.TAB+Keys.ENTER).perform();


       }


    public  void  isDisplayed (){

        Assert.assertTrue(login.isDisplayed());
        Assert.assertTrue(loginGoogle.isDisplayed());
        Assert.assertTrue(register.isDisplayed());

    }



}







