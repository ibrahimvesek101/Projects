package Page.akifPO.US_07;

import Utilities.Driver;
import com.github.javafaker.Faker;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import java.time.Duration;
import java.util.List;

public class ProfileUpdate {

    public ProfileUpdate(){
        PageFactory.initElements(Driver.getDriver(),this);
    }

    //Profile
    @FindBy(xpath = "//img[@alt='user name']")
    WebElement profileImage;
    @FindBy(xpath = "//button[text()='Profile']")
    WebElement profile;
    @FindBy(xpath = "//button[text()='Save']")
    WebElement save;

    //Change Password
    @FindBy(xpath = "//a[text()='Change Password']")
    WebElement password;
    @FindBy(id = "oldPassword")
    WebElement oldPass;
    @FindBy(id = "newPassword")
    WebElement newPass;
    @FindBy(id = "passwordConfirmation")
    WebElement confirmPass;
    @FindBy(xpath = "//button[text()='Submit']")
    WebElement submit;




    //Profile and Change Password
    public void profileUpdate(){
        profileImage.click();
        profile.click();
        save.click();
        String alertMessage= Driver.getDriver().switchTo().alert().getText();
        Driver.getDriver().switchTo().alert().accept();



    }

    public void passwordUpdate(){
        Faker rndm=new Faker();
        long newPassword=rndm.number().randomNumber();
        profileImage.click();
        profile.click();
        password.click();

        oldPass.sendKeys(rndm.number().randomNumber()+"");
        newPass.sendKeys(newPassword+"");
        confirmPass.sendKeys(newPassword+"");
        submit.click();
        String alertMessage= Driver.getDriver().switchTo().alert().getText();
        Driver.getDriver().switchTo().alert().accept();

    }


}
