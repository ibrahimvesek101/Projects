package Page.akifPO.US05;
import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import java.time.Duration;

public class wisiblePO {
    public wisiblePO(){
        PageFactory.initElements(Driver.getDriver(),this);

    }
    @FindBy(linkText = "Shops")
    public WebElement shops;
    @FindBy(xpath = "//span[.='Furniture Shop']")
    public WebElement FurnitureShop;

    @FindBy(xpath = "//span[.='Clothing Shop']")
    public WebElement ClothingShop;

    @FindBy(xpath = "//span[.='Bags Shop']")
    public WebElement BagsShop;

    @FindBy(xpath = "//span[.='Makeup Shop']")
    public WebElement MakeupShop;

    @FindBy(xpath = "//span[.='Bakery Shop']")
    public WebElement BakeryShop;

    @FindBy(xpath = "//span[.='Grocery Shop']")
    public WebElement GroceryShop;
    @FindBy(xpath ="//span[.='Books Shop']")
    public WebElement BooksShop;

    @FindBy(xpath ="//a[.='Visit This Site']")
    public WebElement VisitThisSite;

    @FindBy(xpath = "//span[@class='text-sm text-body']")
    public WebElement Address;

    @FindBy(xpath = "//span[.='Phone']")
    public WebElement Phone;






    public void shopWisible(){
        WebDriverWait bekle= new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));

      bekle.until(ExpectedConditions.elementToBeClickable(shops)).click();
      Assert.assertTrue(FurnitureShop.isDisplayed());
       Assert.assertTrue(BagsShop.isDisplayed());
        Assert.assertTrue(ClothingShop.isDisplayed());
        Assert.assertTrue(MakeupShop.isDisplayed());
        Assert.assertTrue(BakeryShop.isDisplayed());
        Assert.assertTrue(GroceryShop.isDisplayed());
        Assert.assertTrue(BooksShop.isDisplayed());
        BooksShop.click();




    }
    public void assertadressandPhone(){
        Assert.assertTrue(Address.isDisplayed());//adres görüntülemesi için
        Assert.assertTrue(Phone.isDisplayed());
        Driver.teardown();

    }

}



