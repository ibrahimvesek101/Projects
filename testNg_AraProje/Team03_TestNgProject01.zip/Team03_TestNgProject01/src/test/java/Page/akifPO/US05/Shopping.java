package Page.akifPO.US05;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import java.time.Duration;

public class Shopping {

    public Shopping() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    //test case 1
    @FindBy(linkText = "Shops")
    public WebElement shops;



    @FindBy(xpath = "//span[.='Clothing Shop']")
    public WebElement ClothingShop;


    @FindBy(xpath ="(//span[@class='h-full w-full rounded-full border border-border-200'])[3]")
    public WebElement womenDress;

    @FindBy(className ="h-full w-full rounded-full border border-border-200")
    public WebElement blueChose;

    @FindBy(xpath = "(//div[@role='button'])[9]")
    public WebElement small;

    @FindBy(xpath ="//span[text()='Add To Shopping Cart']" )
    public WebElement addShop;

    @FindBy(xpath ="//span[@class='flex ltr:ml-2 rtl:mr-2']")
    public WebElement CBoxes;

    @FindBy(xpath = "(//span[text()='$35.00'])[4]")
    public WebElement firstPrice;

    @FindBy(className = "md:w-4.5 h-3.5 w-3.5 stroke-2.5 md:h-4.5")
    public WebElement artirButton;

    @FindBy(xpath = "(//span[text()='$70.00'])[4]")
    public WebElement secondPrice;

    @FindBy(xpath = "//button[text()='Check Availability']")
    public WebElement CheckAvailabilityButton;

    @FindBy(xpath = "//button[text()='Place Order']")
    public WebElement PlaceOrder;

    @FindBy(xpath ="//button[text()='Pay']")
    public WebElement PayButton;



    public  void clothingshop(){
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));

        Actions action=new Actions(Driver.getDriver());
        shops.click();
        ClothingShop.click();
        wait.until(ExpectedConditions.elementToBeClickable(womenDress));
        action.moveToElement(womenDress).click().perform();
        action.moveToElement(blueChose).click().perform();
        wait.until(ExpectedConditions.elementToBeClickable(blueChose));
        small.click();
        action.moveToElement(addShop).doubleClick(addShop).perform();
        String firstProduce=firstPrice.getText();
        artirButton.click();
        String secondProduct=secondPrice.getText();
        Assert.assertNotEquals(firstPrice,secondPrice);
        CBoxes.click();
        CheckAvailabilityButton.click();
        wait.until(ExpectedConditions.elementToBeClickable(PayButton));
        PayButton.click();
        Driver.teardown();

    }

}

