package Page;

import Utilities.Driver;
import Utilities.WebElementTools;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class LoginPO_Ali {
    WebElementTools tools = new WebElementTools(Driver.getDriver());

    public LoginPO_Ali() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = "*//button[text()=\"Join\"]")
    WebElement join;
    @FindBy(xpath = "*//button[text()=\"Register\"]")
    WebElement register;
    @FindBy(id = "name")
    WebElement name;
    @FindBy(id = "email")
    WebElement email;
    @FindBy(id = "password")
    WebElement password;
    @FindBy(xpath = "*//button[text()=\"Login\"]")
    WebElement login;

    public void joinClick() {
        tools.clickOn(join);
    }

    public void registerClick() {
        tools.clickOn(register);
    }

    public void name() {
        name.sendKeys("ali");
    }

    public void email() {
        email.clear();
        email.sendKeys("ali123@gmail.com");
    }

    public void password() {
        password.clear();
        password.sendKeys("123456");
    }

    public void loginClick() {
        tools.clickOn(login);
    }


}
