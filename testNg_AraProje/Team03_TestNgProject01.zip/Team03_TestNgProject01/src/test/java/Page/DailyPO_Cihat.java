package Page;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import static Utilities.Driver.getDriver;

public class DailyPO_Cihat extends BasePO{
    JavascriptExecutor js = (JavascriptExecutor) getDriver();



    @FindBy(xpath = "//span[contains(.,'Daily')]")
    WebElement dailyNeedslnk;

    public void dailyNeedslnk( ){
        dailyNeedslnk.click();
    }


    //Kullanıcı seçeceği ürünün fiyatını, indirmli fiyatını ve indirim oranı görebilmelidir
    @FindBy(xpath = "(//*[contains(text(), 'View More')])[1]")
    WebElement vegetablesLnk;

    public void vegetablesLnk(){
        vegetablesLnk.click();
    }

    @FindBy(xpath = "(//div[@class='relative z-10 flex h-full flex-1 flex-col'])[3]")
    WebElement edibleLnk;

    public void edibleLnk() throws InterruptedException {
        Thread.sleep(2000);
        edibleLnk.click();
    }

    @FindBy(xpath = "(//del[@class='text-xs text-muted ltr:ml-2 rtl:mr-2 md:text-sm'])[1]")
    WebElement priceEdible;

    public void priceEdible() throws InterruptedException {
        Thread.sleep(2000);
        priceEdible.isDisplayed();
    }


    @FindBy(xpath = "(//*[contains(text(), '$3.29')])[1]")
    WebElement onsaleEdible;

    public void onsaleEdible() throws InterruptedException {
        Thread.sleep(2000);
        onsaleEdible.isDisplayed();
    }

    @FindBy(xpath = "(//*[contains(text(), '15%')])[1]")
    WebElement discountRateEdible;

    public void discountRateEdible() throws InterruptedException {
        Thread.sleep(2000);
        discountRateEdible.isDisplayed();
    }

    //Kullanıcı ürün birimini görebilmelidir
    @FindBy(xpath = "(//*[contains(text(), '2lbs')])[1]")
    WebElement titleProduct;

    public void titleProduct() throws InterruptedException {
        Thread.sleep(2000);
        titleProduct.isDisplayed();
    }



    //İlglii ürün açıklaması ve title ı olmalıdır.
    @FindBy(xpath = "//div[@class='mt-3 text-sm leading-7 text-body md:mt-4']")
    WebElement descriptionProduct;

    public void descriptionProduct() throws InterruptedException {
        Thread.sleep(2000);
        descriptionProduct.isDisplayed();
    }

    @FindBy(xpath = "//*[contains(text(), 'Small asparagus 2lbs')]")
    WebElement smallAsparagusLbs;

    public void smallAsparagusLbs(){
        smallAsparagusLbs.isDisplayed();
        tools.waitFor(smallAsparagusLbs).click();
    }

    //Ürünün sayfasını açabilmeli
    //Açılan sayfada ürünün başlık ve fiyatının önceki sayfadaki ile aynı olduğunu doğrulayabilmeli
    @FindBy(xpath = "//img[@alt='Garden asparagus 2lbs']")
    WebElement pageProduct;
    public void pageProduct() throws InterruptedException {
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);
        pageProduct.isDisplayed();
        //Assert.assertEquals(smallAsparagusLbs,pageProduct);

    }

    //Kullanıcı sayfada Read More ve Less buttonlarının çalıştığını doğrulamalıdır
    @FindBy(xpath = "(//*[contains(text(), 'Read more')])[2]")
    WebElement readMoreText;

    public void readMoreText() throws InterruptedException {
        Thread.sleep(2000);
        readMoreText.click();
    }


    @FindBy(xpath = "(//*[contains(text(), 'Less')])[2]")
    WebElement lessText;

    public void lessText() throws InterruptedException {
        Thread.sleep(2000);
        lessText.click();
    }

    //Kullanıcı açılan sayfasa scroll barın çalıştığını, Categories, Sellers başlıklarını doğrulamalı
    @FindBy(xpath = "(//span[@class='py-1 text-sm font-semibold capitalize text-heading ltr:mr-6 rtl:ml-6'])[1]")
    WebElement categoriesLnk;

    public void categoriesLnk() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(categoriesLnk.isDisplayed());

    }

    @FindBy(xpath = "(//span[@class='py-1 text-sm font-semibold capitalize text-heading ltr:mr-6 rtl:ml-6'])[2]")
    WebElement sellersLnk;

    public void sellersLnk() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(sellersLnk.isDisplayed());
    }

    //Kullanıcı açılan sayfada root ve vegetables buttonlarının çalışıyor olduğunu doğrulamalı
    @FindBy(xpath = "(//div[@class='relative z-10 flex h-full flex-1 flex-col'])[6]")
    WebElement rootButton;

    public void rootButton() throws InterruptedException {
        Thread.sleep(2000);
        rootButton.click();
    }
    @FindBy(xpath = "(//div[@class='relative flex h-48 w-auto cursor-pointer items-center justify-center sm:h-64'])[1]")
    WebElement carrotButton;

    public void carrotButton() throws InterruptedException {
        Thread.sleep(2000);
        carrotButton.click();
    }

    @FindBy(xpath = "(//div[@class='relative z-10 flex h-full flex-1 flex-col'])[1]")
    WebElement vegetablesLnks;

    public void vegetablesLnks(){
        Assert.assertTrue(vegetablesLnks.isDisplayed());
    }


    //Kullanıcı açılan sayfada scroll yaparak Details kısmını ve yazılı olduğunu doğrulamalı
    @FindBy(xpath = "//h2[@class='mb-4 text-lg font-semibold tracking-tight text-heading md:mb-6']")
    WebElement details;

    public void details() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) getDriver();
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);
        Assert.assertTrue(details.isDisplayed());
        tools.waitFor(details).click();
    }


    @FindBy(xpath = "//p[@class='text-sm text-body']")
    WebElement textDetails;

    public void textDetails() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(textDetails.isDisplayed());
    }

    //Kullanıcı açılan sayfada scroll yaparak Related Products başlığını doğrulamalı
    @FindBy(xpath = "(//*[contains(text(), 'Related Products')])[2]")
    WebElement relatedProducts;

    public void relatedProducts() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) getDriver();
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(5000);
        Assert.assertTrue(relatedProducts.isDisplayed());
        tools.waitFor(relatedProducts).click();
    }


    //Kullanıcı Add To Shopping Cart seçeneğine tıklayabilmeli
    @FindBy(xpath = "(//button[@class='group flex h-7 w-full items-center justify-between rounded bg-gray-100 text-xs text-body-dark transition-colors hover:border-accent hover:bg-accent hover:text-light focus:border-accent focus:bg-accent focus:text-light focus:" +
            "outline-0 md:h-9 md:text-sm'])[1]")
    WebElement addToCartBtn;

    public void addToCartBtn() throws InterruptedException {
        Thread.sleep(2000);
        addToCartBtn.click();
    }



    //Kullanıcı sepete ürün ekleyebilmeli
    @FindBy(xpath = "(//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0'])[2]")
    WebElement plusProduct;

    public void plusProduct() throws InterruptedException {
        Thread.sleep(2000);
        plusProduct.click();

    }

    //Kullanıcı sepetten ürün çıkartabilmeli
    @FindBy(xpath = "(//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0'])[1]")
    WebElement minusProduct;

    public void minusProduct() throws InterruptedException {
        Thread.sleep(2000);
        minusProduct.click();
    }


    //Kullanıcı sepette fiyatı görmeli
    @FindBy(xpath = "//button[@class='hidden product-cart lg:flex relative']")
    WebElement shoppingBasket;

    public void shoppingBasket() throws InterruptedException {
        Thread.sleep(2000);
        shoppingBasket.click();
    }


    @FindBy(xpath = "(//*[contains(text(), '$3.29')])[4]")
    WebElement totalPrice;

    public void totalPrice() throws InterruptedException {
        Thread.sleep(2000);
        totalPrice.isDisplayed();
    }



}
