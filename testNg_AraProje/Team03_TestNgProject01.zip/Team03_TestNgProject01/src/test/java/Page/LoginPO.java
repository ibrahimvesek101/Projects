package Page;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPO {
    public LoginPO() {
        PageFactory.initElements(Driver.getDriver(), this);

    }


    @FindBy(xpath = "//button[text()='Join']")
    WebElement join;
    @FindBy(xpath = "//button[text()='Login']")
    WebElement login;
    @FindBy(linkText = "Shops")
    public WebElement shops;




    public void customerLogin() {
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
        join.click();
        login.click();



    }
}