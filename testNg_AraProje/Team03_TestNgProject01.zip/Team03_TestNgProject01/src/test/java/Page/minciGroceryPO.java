package Page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class minciGroceryPO extends BasePO {

    public minciGroceryPO() {
        super();
    }

    /* Web Elements */
    @FindBy(xpath = "//h1[.='Groceries Delivered in 90 Minute']")
    WebElement hdr_GroceryMainHeader;
    @FindBy(xpath = "//input[@id='search']")
    WebElement tb_SearchBox;
    @FindBy(xpath = "//input[@id='search']//following-sibling::button[.='Search']")
    WebElement btnSearchMiddle; // search  button next to main search box (NOT the top one)
    @FindBy(xpath = "//div[@id='offer']/div[@class='swiper-wrapper']/div[contains(@class,'swiper-slide')]")
    List<WebElement> divSliderItems;
    @FindBy(xpath = "//div[@role='button' and .='Previous']")
    WebElement btnSliderPrevious;
    @FindBy(xpath = "//div[@role='button' and .='Next']")
    WebElement btnSliderNext;
    @FindBy(xpath = "//div[@class='px-5']/ul/li[@class='rounded-md py-1']")
    List<WebElement> divCatagoriesPanelItems;
    @FindBy(xpath = "//article[contains(@class,'product-card')]")
    List<WebElement> divProductCards;
    @FindBy(xpath = "//button[.='Load More']")
    WebElement btn_LoadMore;
    @FindBy(xpath = "//article[contains(@class,'rounded-lg')]")
    WebElement pnlProductDetailContainer;
    @FindBy(xpath = "//article[contains(@class,'rounded-lg')]//h1")
    WebElement txtProductDetailHeader;
    @FindBy(xpath = "//article[contains(@class,'rounded-lg')]//div[@class='mt-3 text-sm leading-7 text-body md:mt-4']")
    WebElement txtProductDetailDescription;
    @FindBy(xpath = "(//article[contains(@class,'rounded-lg')]//button)[2]")
    WebElement btnProductDetailMoreLess;

    @FindBy(xpath = "//article[contains(@class,'rounded-lg')]//div[@class='swiper-wrapper']//img")
    List<WebElement> productDetailPics;

    @FindBy(xpath = "//div[contains(@class,'product-gallery-prev')]")
    WebElement btnProductSlidePrev;
    @FindBy(xpath = "//div[contains(@class,'product-gallery-next')]")
    WebElement btnProductSlideNext;

    @FindBy(xpath = "//div[@name='details']/h2")
    WebElement txtProductDetailsHeader;

    @FindBy(xpath = "//div/h2[contains(.,'Related Products')]")
    WebElement txtRelatedProductsHeader;

    @FindBy(xpath = "//div[@class='w-full']//ins[starts-with(.,'$')]")
    WebElement txtProductFirstPrice;

    @FindBy(xpath = "//div[@class='w-full']//del[starts-with(.,'$')]")
    WebElement txtProductDiscountedPrice;

    @FindBy(xpath = "//div[contains(@class,'rounded-full') and contains(.,'%')]")
    WebElement txtProductDiscountPercent;

    @FindBy(xpath = "(//span[@class='flex-1' and text()='Add']//following-sibling::span)[1]")
    WebElement btnProductAdd;

    @FindBy(xpath = "//button/span/span[contains(.,'Item')]")
    WebElement txtBasketItemCount;
    @FindBy(xpath = "//button/span[starts-with(.,'$')]")
    WebElement txtBasketTotal;


    /* getters */
    public WebElement getHdr_GroceryMainHeader() {
        return hdr_GroceryMainHeader;
    }

    public WebElement getTb_SearchBox() {
        return tb_SearchBox;
    }

    public WebElement getBtnSearchMiddle() {
        return btnSearchMiddle;
    }

    public List<WebElement> getDivSliderItems() {
        return divSliderItems;
    }

    public WebElement getBtnSliderPrevious() {
        return btnSliderPrevious;
    }

    public WebElement getBtnSliderNext() {
        return btnSliderNext;
    }

    public List<WebElement> getDivCatagoriesPanelItems() {
        return divCatagoriesPanelItems;
    }

    public List<WebElement> getDivProductCards() {
        return divProductCards;
    }

    public WebElement getBtn_LoadMore() {
        return btn_LoadMore;
    }

    public WebElement getPnlProductDetailContainer() {
        return pnlProductDetailContainer;
    }

    public WebElement getTxtProductDetailHeader() {
        return txtProductDetailHeader;
    }

    public WebElement getTxtProductDetailDescription() {
        return txtProductDetailDescription;
    }

    public WebElement getBtnProductDetailMoreLess() {
        return btnProductDetailMoreLess;
    }

    public List<WebElement> getProductDetailPics() {
        return productDetailPics;
    }

    public WebElement getBtnProductSlidePrev() {
        return btnProductSlidePrev;
    }

    public WebElement getBtnProductSlideNext() {
        return btnProductSlideNext;
    }

    public WebElement getTxtProductDetailsHeader() {
        return txtProductDetailsHeader;
    }

    public WebElement getTxtRelatedProductsHeader() {
        return txtRelatedProductsHeader;
    }

    public WebElement getTxtProductFirstPrice() {
        return txtProductFirstPrice;
    }

    public WebElement getTxtProductDiscountedPrice() {
        return txtProductDiscountedPrice;
    }

    public WebElement getTxtProductDiscountPercent() {
        return txtProductDiscountPercent;
    }

    public WebElement getBtnProductAdd() {
        return btnProductAdd;
    }

    public WebElement getTxtBasketItemCount() {
        return txtBasketItemCount;
    }

    public WebElement getTxtBasketTotal() {
        return txtBasketTotal;
    }

    /* Methods begin */
    public void gotoGroceryHomePage() {
        tools.openUrl("https://shop-pickbazar-rest.vercel.app/");
    }

    public void searchInGrocery(String text) {
        tools.clear(tb_SearchBox);
        tools.sendText(tb_SearchBox,text);
        tools.clickOn(btnSearchMiddle);
    }

    public String getMainHeaderText() {
        return hdr_GroceryMainHeader.getText();
    }


}
