package Page;

import Utilities.Driver;
import Utilities.WebElementTools;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

public class BagsPO_Ali {
    JavascriptExecutor jsExecutor = (JavascriptExecutor) Driver.getDriver();
    WebElementTools tools = new WebElementTools(Driver.getDriver());

    public BagsPO_Ali() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(id = "headlessui-menu-button-:R3kkm:")
    WebElement searchButton;
    @FindBy(xpath = "//a[@href='/bags']")
    WebElement bags;
    @FindBy(id = "search")
    WebElement searchBox;
    @FindBy(xpath = "//article[@class='product-card cart-type-helium h-full overflow-hidden rounded border border-border-200 bg-light transition-shadow duration-200 hover:shadow-sm']")
    List<WebElement> productList;
    @FindBy(xpath = "//a[@href='/shops/bags-shop']")
    WebElement bagsShop;
    @FindBy(xpath = "//a[@href='/shops']")
    WebElement shop;
    @FindBy(xpath = "//article[@class='product-card cart-type-helium h-full overflow-hidden rounded border border-border-200 bg-light transition-shadow duration-200 hover:shadow-sm']")
    List<WebElement> productList1;
    @FindBy(xpath = "//button[@class='mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-gray-300 transition-colors mr-1']")
    WebElement favorite;
    @FindBy(xpath = "(//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 px-5'])[4]")
    WebElement plus; // +
    @FindBy(xpath = "*//button[text()=\"Purse\"]")
    WebElement categories;
    @FindBy(xpath = "//div[@class='px-5']")
    WebElement categoriesIsdisplayed;
    @FindBy(xpath = "//span[text()=\"50\"]")
    WebElement pieceAvailable; // 50 pieces available
    @FindBy(xpath = "*//h2[text()='Related Products']")
    WebElement relatedProductCheck;
    @FindBy(xpath = "//del[@class='text-sm font-normal text-muted ltr:ml-2 rtl:mr-2 md:text-base']")
    WebElement firstPrice;
    @FindBy(xpath = "//ins[@class='text-2xl font-semibold text-accent no-underline md:text-3xl']")
    WebElement lastPrice;
    @FindBy(xpath = "//div[@class='rounded-full bg-yellow-500 px-3 text-xs font-semibold leading-6 text-light ltr:ml-auto rtl:mr-auto']")
    WebElement discountRate;
    @FindBy(xpath = "//article[@class='product-card cart-type-helium h-full overflow-hidden rounded border border-border-200 bg-light transition-shadow duration-200 hover:shadow-sm']")
    List<WebElement> productBagList;
    @FindBy(xpath = "(*//span[text()='Cart'])[1]")
    WebElement cart;
    @FindBy(xpath = "(//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 px-3 py-3 sm:px-2'])[2]")
    WebElement plusPlus;
    @FindBy(xpath = "(//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 px-3 py-3 sm:px-2'])[1]")
    WebElement minus;

    @FindBy(xpath = "//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 hover:!bg-gray-100'][2]")
    WebElement plus1;
    @FindBy(xpath = "//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 hover:!bg-gray-100'][1]")
    WebElement minus1;
    @FindBy(xpath = "(*//span[text()=\"Add To Shopping Cart\"])[2]")
    WebElement addToCartButton;
    @FindBy(xpath = "(//button[@class='cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 px-5'])[4]")
    WebElement plusLast;

    public void addToCartButtonClick() throws InterruptedException {
        Thread.sleep(2000);
        addToCartButton.click();
    }

    public void searchButtonClick() {
        tools.clickOn(searchButton);
    }

    public void bagsClick() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(bags);
    }

    public void bagsShopClick() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(bagsShop);
        Thread.sleep(2000);
        JavascriptExecutor jse = (JavascriptExecutor) Driver.getDriver();
        jse.executeScript("window.scrollBy(0,400);"); // sayfamizda 800 piksel asagiya scroll yaptik
    }

    public void shopClick() throws InterruptedException {
        Thread.sleep(3000);
        tools.clickOn(shop);
    }

    public void searchBox(String key) throws InterruptedException {
        Thread.sleep(2000);
        searchBox.sendKeys(key, Keys.ENTER);
    }

    public void productListContains(String key) {
        productList.contains(key);
    }

    public void firstPrice() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(firstPrice.isDisplayed());
    }

    public void lastPrice() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(lastPrice.isDisplayed());
    }

    public void discountRate() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(discountRate.isDisplayed());
    }

    public void pruductPictures() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(relatedProductCheck.isDisplayed());
    }

    public void categoriesClick() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(categories);
    }

    public void categoriesIsdisplayed() throws InterruptedException {
        Thread.sleep(1000);
        Assert.assertTrue(categoriesIsdisplayed.isDisplayed());
    }

    @FindBy(xpath = "(//div[@class='flex flex-1 items-center justify-center px-3 text-sm font-semibold'])[3]")
    WebElement stokSonSayi;
    @FindBy(xpath = "//span[@class='whitespace-nowrap text-base text-body ltr:lg:ml-7 rtl:lg:mr-7']")
    WebElement howManyPieces;


    public void pieceAvailable() {

        jsExecutor.executeScript("arguments[0].scrollIntoView(true);", plusLast);
        boolean stokDogru = true;
        int adet = 1;
        String pieces = howManyPieces.getText().substring(0, howManyPieces.getText().indexOf(" "));
        System.out.println(howManyPieces.getText());
        System.out.println("pieces = " + pieces);
        while (plusLast.isEnabled()) {
            plusLast.click();
            adet++;
            if (adet > Integer.parseInt(pieces)+5) {
                stokDogru = false;
                break;
            }
        }
        String a = (stokSonSayi.getText());
        System.out.println("a = " + a);
        String pieces1 = howManyPieces.getText().substring(0, howManyPieces.getText().indexOf(" "));
        System.out.println(howManyPieces.getText());
        System.out.println("pieces = " + pieces1);
        Assert.assertTrue(stokDogru = true);
        Assert.assertTrue(a.equals(pieces1));

    }

    public void chooseProduct(int index) {
        productList.get(index).click();
    }

    public void chooseProductBag(int index) throws InterruptedException {
        Thread.sleep(2000);
        productBagList.get(index).click();
    }
    @FindBy(xpath = "//div[@class='mt-3 text-sm leading-7 text-body md:mt-4']")
    WebElement productDescription;
    public void chooseProductBagScroll(int index) throws InterruptedException {

        Thread.sleep(2000);
        productBagList.get(index).click();
      //  JavascriptExecutor jse = (JavascriptExecutor) Driver.getDriver();
      //  jse.executeScript("window.scrollBy(0,1000);"); // sayfamizda 400 piksel asagiya scroll yaptik
        JavascriptExecutor jsexecutor = ((JavascriptExecutor) Driver.getDriver());
        jsexecutor.executeScript("window.scrollTo(0,document.body.scrollHeight)");

        Assert.assertTrue(productDescription.isDisplayed());
    }

    public void favoriteClick() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(favorite.isEnabled());
        tools.clickOn(favorite);
        Thread.sleep(3000);

        //Assert.assertTrue(favorite.isEnabled());
    }

    public void cartClick() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(cart);
    }

    @FindBy(xpath = "//div[@class='flex flex-1 items-center justify-center px-3 text-sm font-semibold']")
    WebElement quantityCart;
    public void plusClick() throws InterruptedException {
        String ilkDeger = quantityCart.getText();
        tools.clickOn(plusPlus);
        Thread.sleep(2000);
        tools.clickOn(plusPlus);
        tools.clickOn(minus);
        String sonDeger = quantityCart.getText();
        Assert.assertFalse(ilkDeger.equals(sonDeger));
    }

    public void minusClick() throws InterruptedException {
        Thread.sleep(2000);
        tools.clickOn(minus);

    }
    @FindBy(xpath = "//div[@class='flex flex-1 items-center justify-center px-3 text-sm font-semibold !px-0 text-heading']")
    WebElement sepetIlkMiktar;
    public void clickGoToCart() throws InterruptedException {

        tools.clickOn(plus1);
        int a = Integer.parseInt(sepetIlkMiktar.getText());
        System.out.println("a = " + a);
        Thread.sleep(1000);
        tools.clickOn(plus1);
        tools.clickOn(plus1);
        tools.clickOn(minus1);
        tools.clickOn(minus1);
        tools.clickOn(minus1);
        int b = Integer.parseInt(sepetIlkMiktar.getText());
        System.out.println("b = " + b);
        Assert.assertFalse(a==b);
    }

    public void minusClickGoToCart() throws InterruptedException {
        Thread.sleep(1000);


    }

    public void cartTest() throws InterruptedException {

    }
}
// jse.executeScript("window.scrollTo(0,document.body.scrollHeight");//Sayfanin en altina scroll yaptik
//        for (int i = 0; i < 50; i++) {
//            jse.executeScript("window.scrollBy(0,30);");
//            Thread.sleep(200);
//        }
// jse.executeScript("arguments[0].scrollIntoView()", Driver.getDriver().findElement((By) otherPruductPicture));
//        Actions actions = new Actions(Driver.getDriver());
//        actions.moveToElement(otherPruductPicture).perform();