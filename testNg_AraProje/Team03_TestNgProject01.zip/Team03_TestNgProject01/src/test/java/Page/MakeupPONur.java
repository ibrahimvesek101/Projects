package Page;

import Utilities.Driver;
import com.github.javafaker.Faker;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

public class MakeupPONur extends BasePO{

    private Faker faker=new Faker();
    Actions actions = new Actions(Driver.getDriver());




    @FindBy(xpath = "//button[.='Join']")
    WebElement JoinButton;
    @FindBy(id="email")
    WebElement SigninEmail;
    @FindBy(id="password")
    WebElement SigninPassword;
    @FindBy(xpath= "//button[.='Login']")
    WebElement SigninJoinButtonClick;
    @FindBy(xpath = "//span[@class='whitespace-nowrap']")
    WebElement btn_makeupMenu;
    @FindBy(xpath = "//span[text()='Makeup']")
    WebElement btn_makeup;
    @FindBy(id = "search")
    WebElement input_searchBox;
    @FindBy( xpath = "//*[contains(@class, 'product-card')]")
    private List<WebElement> productCategories;
    @FindBy(xpath = "//h3[contains(text(), 'Sorry')]")
    WebElement txt_NotFound;
    @FindBy(xpath = "(//div[contains(@class, 'relative flex h-48')])[1]")
    WebElement locate_firstProduct;
    @FindBy (xpath = "//div[contains(text(), 'contour')]")
    WebElement txt_productDetails;
    @FindBy(xpath = "(//ins[contains(@class, 'text-2xl')])[2]")
    WebElement txt_productPrice;
    @FindBy(xpath = " //span[@class='text-base whitespace-nowrap text-body ltr:lg:ml-7 rtl:lg:mr-7']")
    WebElement txt_amountStock;
    @FindBy(xpath = "(//button[@type='button'])[7]")
    WebElement btn_favoriteIcon;
    @FindBy(css = "div.inline-flex.items-center")
    WebElement product_reviewIcon;
    @FindBy(xpath = "(//span[text()='Add To Shopping Cart'])[2]")
    WebElement btn_addShoppingCart;
    @FindBy(xpath = "//button[contains(@class, 'text-sm tracking')]")
    WebElement btn_seller;
    @FindBy(xpath = "//button[@id='headlessui-menu-button-:rf:']")
    WebElement btn_account;
    @FindBy(xpath = "//div[contains(@class, 'mt-3')]")
    WebElement makeupFirstElementDetails;
    @FindBy(xpath = "(//button[contains(@class, 'order-5 flex')])[1]")
    WebElement btnCart;
    @FindBy(xpath = "(//button[contains(@class, 'order-5 flex')])")
    List<WebElement>btn_CartList;
    @FindBy(xpath = "(//button[contains(@class, 'order-5 flex')])[2]")
    WebElement btn_Cart2;
    @FindBy(xpath = "//button[contains(@class, 'product-cart')]/span")
    WebElement btn_sepetHomePage;
    @FindBy(xpath = "//span[text()='Checkout']")
    WebElement btn_checkout;
    @FindBy(xpath = "(//div[@class='flex flex-1 items-center justify-center px-3 text-sm font-semibold'])")
    WebElement txtCenterPieces;
    @FindBy(xpath = "//button[@data-variant='normal']")
    WebElement btn_checkAvailability;
    @FindBy(xpath = "//div[contains(@class, 'relative flex h-full w-full')]")
    WebElement locator_creditCard;
    @FindBy(xpath = "//div[@id='headlessui-radiogroup-option-:r4b:']")
    WebElement btn_cash;
    @FindBy(css = "button[data-variant=\"normal\"]")
    WebElement btn_placeOrder;
    @FindBy(xpath = "//button[text()=\"Pay Later\"]")
    WebElement btn_payLater;
    @FindBy(xpath = "//button[@data-variant='normal'][text()='Pay']")
    WebElement btn_payCreditCard;
    @FindBy (xpath = "//span[contains(@class, 'flex ltr:ml-2 rtl:mr-2')]")
    WebElement quantitySepet;
    @FindBy(xpath = "//span[contains(@class, 'flex h-full shrink-0 ')]")
    WebElement totalAmountSepet;
    @FindBy(xpath = "(//button[@class= 'cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 px-3 py-3 sm:px-2'])[2]")
    WebElement btn_cartIncrease;
    @FindBy(xpath = "(//button[@class= 'cursor-pointer p-2 transition-colors duration-200 hover:bg-accent-hover focus:outline-0 px-3 py-3 sm:px-2'])[1]")
    WebElement btn_cartDecrease;
    @FindBy(xpath = "(//div[contains(@class, 'flex flex-1 items-center')])[2]")
    WebElement txt_sepetProductNumberCenter;
    @FindBy(xpath = "(//button[contains(@class, 'cursor-pointer') and contains(@class, 'hover:bg-accent-hover') and contains(@class, 'hover:!bg-gray-100')])[2]")
    WebElement btn_increaseInBasket;
    @FindBy(xpath = "(//button[contains(@class, 'cursor-pointer')])[3]")
    WebElement btn_decreaseInBasket;
    @FindBy(xpath = "//h4[text()='No products found']")
    WebElement txt_noProductInBasket;
    @FindBy(xpath = "(//button[@title=''])[3]")
    WebElement btn_productIncrease;
    @FindBy (xpath = "(//div[contains(@class, 'flex flex-1 items-center')])[2]")
    WebElement txt_centerNumberProduct;
    @FindBy(xpath = "//ul[@class='text-xs xl:py-8']")
    WebElement makeupCategoryDropdowns;
    @FindBy(xpath = "//button[contains(@class, 'flex w-full items-center')]")
    List<WebElement>makeupCategoryNames;
    @FindBy(xpath = "//button[contains(@class, 'flex w-full items-center')]")
    List<WebElement> btn_generalDropdown;
    @FindBy(xpath = "(//button[contains(@class, 'flex w-full items-center')])[1]")
    WebElement btn_faceCategory;
    @FindBy(xpath = "//button[contains(@class, 'order-5 flex')]")
    List<WebElement> btn_generalCart;
    @FindBy(xpath = "//span[@class= 'flex ltr:ml-2 rtl:mr-2']")
    WebElement txt_itemSepet;
    @FindBy(xpath = "(//button[contains(@class, 'flex h-7 w-7')])[2]")
    WebElement btn_xUrunInBasket;
    @FindBy(xpath = "//div[contains(@class, 'flex justify-between')]/div")
    List<WebElement> itemNumberInCheckout;
    @FindBy(xpath = "//div[contains(@class,'swiper-slide !flex cursor-pointer' )]")
    WebElement img_productDetails;
    @FindBy(xpath = "(//p[@class='text-sm text-body-dark'])[3]")
    WebElement txt_orderTotalAmount;



    //Methods

    public void joinButtonHomePage(){
        tools.waitFor(JoinButton).click();
    }

    public void sendEmail(){
        SigninEmail.clear();
        tools.sendText(SigninEmail,faker.internet().emailAddress());
    }
    public void sendPassword(){
        SigninPassword.clear();
        tools.sendText(SigninPassword,faker.internet().password());
    }

    public void assertionFavorites(){
        tools.isVisible(btn_account);
        Assert.assertEquals(btn_account.getText(),"My Favorites");

    }

    public void loginClick(){
        tools.waitFor(SigninJoinButtonClick).click();
    }


    public void joinMethod(){
        joinButtonHomePage();
        windowHandle();
        sendEmail();
        sendPassword();
        loginClick();
    }


    public void sendKeyword(String key){tools.sendText(input_searchBox,key + Keys.ENTER);}

    public void productsisDisplayed(){
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
        By productCardLocator = By.xpath("//*[contains(@class, 'product-card')]");
        List<WebElement> productList = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(productCardLocator));
        wait.until(ExpectedConditions.visibilityOfAllElements(productList));
        System.out.println("Search results for 'lipstick', 'mascara', 'foundation' are displayed.");

        for (WebElement product : productList) {
            System.out.println(product.getText());
        }
    }

    public void dropDownDisplay(){ tools.isVisible(btn_makeupMenu);}
    public void clickMenu(){tools.waitFor(btn_makeupMenu).click();}
    public void goToMakeupURL(){
        Assert.assertEquals( Driver.getDriver().getCurrentUrl(), "https://pickbazar-react-rest.vercel.app/makeup");
    }

    public void goToHomePage(){tools.openUrl("https://pickbazar-react-rest.vercel.app/");setup();}

    public void clickMakeUp(){tools.waitFor(btn_makeup).click();
        Assert.assertTrue(btn_makeup.isDisplayed());

    }

    public void windowHandle(){

        String currentWindowHandle = Driver.getDriver().getWindowHandle();
        for (String windowHandle : Driver.getDriver().getWindowHandles()) {
            if (!windowHandle.equals(currentWindowHandle)) {
                Driver.getDriver().switchTo().window(windowHandle);
                break;
            }
        }
    }

    public void assertionNotFoundTxtMethod(){
    tools.scrollIntoJS(txt_NotFound);
    Assert.assertTrue(txt_NotFound.getText().contains("Sorry"));}

    public void testProductCategories() {
        Assert.assertFalse(productCategories.isEmpty(), "Ürün kategorileri listelenmedi.");
    }

    public void testOtherProducts(){
        Assert.assertFalse(productCategories.isEmpty(), " Diğer ürünler listelenmedi.");
    }

    public void assertMakeupCategories() {

        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElements(productCategories));
            for (WebElement product : productCategories) {
                System.out.println(product.getText());
        }
            Assert.assertFalse(productCategories.isEmpty());
    }

    public void clickFirstProduct() {

            int maxRetryCount = 3;
            int retryCount = 0;
            boolean isClicked = false;

            while (retryCount < maxRetryCount && !isClicked) {
                try {
                    tools.scrollIntoJS(locate_firstProduct);
                    Thread.sleep(5000);
                    tools.clickOn(locate_firstProduct);
                    isClicked = true;
                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element hatası alındı. Tekrar deneme: " + (retryCount + 1));
                    retryCount++;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }}

    public void visibleProductDetails(){tools.isVisible(txt_productDetails);}

    public void assertionTotalAmountOrderPage() throws InterruptedException {
        Thread.sleep(3000);
        Assert.assertEquals(tools.waitFor(txt_orderTotalAmount).getText(), "$104.80");
    }

    public void visibleProductPrice(){tools.isVisible(txt_productPrice);
        Assert.assertTrue(txt_productPrice.isDisplayed());
    }
    public void isDisplayStock(){tools.isVisible(txt_amountStock);}

    public void clickFavoriteIcon(){tools.waitFor(btn_favoriteIcon).click();}

    public void visibleProductReview(){tools.waitFor(product_reviewIcon).isDisplayed();}

    public void clickAddShoppingCard(){tools.waitFor(btn_addShoppingCart).click();}

    public void clickSellerLink(){tools.waitFor(btn_seller).click();}
    public void clickAccount(){
        tools.waitFor(btn_account).click();
    }

    public void goToSellerURL()  {
        tools.waitFor(btn_seller).click();
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
       wait.until(ExpectedConditions.urlContains("/shops"));
        Assert.assertEquals(Driver.getDriver().getCurrentUrl(), "https://pickbazar-react-rest.vercel.app/shops/makeup-shop" );
    }

    public void falseProductDetailsAssertion(){
        Assert.assertFalse(makeupFirstElementDetails.getText().contains("Blusher") );
    }

    public void isDisplayedImages(){tools.waitFor(img_productDetails).isDisplayed();}

    public void clickButonCart() throws InterruptedException {
        Thread.sleep(5000);
        tools.waitFor(btnCart).click();

    }

    public void clickButonCart2() throws InterruptedException {
        Thread.sleep(3000);
        tools.waitFor(btn_Cart2).click();
    }

    public void visibleCartButton() {
        tools.waitFor(btnCart).isDisplayed();
    }


    public void clickButtonCartMoreThanOne() throws InterruptedException {
        actions.moveToElement(btn_CartList.get(0)).click();
        int numberOfClicks = 3;

        for (int i = 0; i < numberOfClicks; i++) {
            tools.waitFor(btn_cartIncrease).click();
            Thread.sleep(1000);
        }

    }

    public void clickBtnCartList(){
        tools.waitFor(btn_CartList.get(0)).click();
    }

    public void assertionIcreaseAfterDecreaseTotalAmount() {
       tools.waitFor(btn_decreaseInBasket).click();
       Assert.assertEquals(tools.waitFor(totalAmountSepet).getText(), "$24.00");
    }

    public void clickSepet(){tools.waitFor(btn_sepetHomePage).click();}

    public void refreshMethod() throws InterruptedException {
        Thread.sleep(2000);
        Driver.getDriver().navigate().refresh();
    }


    public void clickCheckout(){tools.waitFor(btn_checkout).click();}


    public void clickCheckAvailability() throws InterruptedException {
        Thread.sleep(3000);
        tools.waitFor(btn_checkAvailability).click();
    }


    public void clickPayButon(){
        tools.waitFor(btn_payCreditCard).click();
    }

    //Odeme sayfasındaki place order butonuna tıklıyor gorunmesi için sayfayı aşağıya scrolll yapıyor
    public void clickPlaceOrder() throws InterruptedException {

        tools.scrollIntoJS(btn_placeOrder);
        Thread.sleep(1000);
        tools.waitFor(btn_placeOrder).click();
    }

    public void clickPayLater(){tools.waitFor(btn_payLater).click();}

    public void assertionQuantitySepet(){Assert.assertEquals(tools.waitFor(txt_centerNumberProduct).getText(),"4");
    }

    public void assertionTotalAmountSepet1(){
       Assert.assertEquals(tools.waitFor(totalAmountSepet).getText(), "$32.00");
    }

    public void totalAmountSepet2(){
        Assert.assertEquals(tools.waitFor(totalAmountSepet).getText(), "$128.00");
    }

    public void clickDecreaseCartButton(){tools.waitFor(btn_cartDecrease).click();
    }

    public void cartQuantityAssertion(){
        Assert.assertEquals(tools.waitFor(txt_sepetProductNumberCenter).getText(), "3", "Cart quantity is not updated correctly");
    }

    public void clickIncreaseButtonInBasket() throws InterruptedException {
        int numberOfClicks = 3;

        for (int i = 0; i < numberOfClicks; i++) {
            tools.waitFor(btn_increaseInBasket).click();
            Thread.sleep(1000);
        }

    }

    public void assertionAmountSepet(){
        Assert.assertEquals(tools.waitFor(totalAmountSepet).getText(), "$128.00");
    }


    public void clickDecreaseButtonInBasket(){tools.waitFor(btn_decreaseInBasket).click();}

    public void assertionDecreaseButtonInBasket() throws InterruptedException {

        int numberOfClicks = 2;

        for (int i = 0; i < numberOfClicks; i++) {
            tools.waitFor(btn_decreaseInBasket).click();
            Thread.sleep(1000);
        }

        Assert.assertEquals(tools.waitFor(totalAmountSepet).getText(), "$16.00");
    }

    public void clickdecreaseButtonToZeroInBasket() throws InterruptedException {

        int numberOfClicks = 4;

        for (int i = 0; i < numberOfClicks; i++) {
            tools.waitFor(btn_decreaseInBasket).click();
            Thread.sleep(1000);
        }

        System.out.println("All items have been removed from the basket.");


        Assert.assertTrue(txt_noProductInBasket.isDisplayed());
    }

    public void increaseMoreThanStock() {

        String stockText = "40 pieces available";
        String stockCountStr = stockText.substring(0, stockText.indexOf(" ")); // İlk boşluğa kadar olan kısmı al
        int stockCount = Integer.parseInt(stockCountStr);
        int desiredQuantity = stockCount + 1;
        int currentQuantity = 1;

        while (currentQuantity <= desiredQuantity) {
            tools.waitFor(btn_productIncrease).click();
            currentQuantity++;

            if (currentQuantity >= stockCount) {
                break;
            }
        }

        String actualQuantity = txtCenterPieces.getText();
        Assert.assertEquals(Integer.parseInt(actualQuantity), stockCount);
    }

        public void visibilityDropdownMakeupCategories(){
        tools.scrollIntoJS(makeupCategoryDropdowns);

       Assert.assertTrue( tools.waitFor(makeupCategoryDropdowns).isDisplayed());
        }

        public void assertionCategoriesIncluding(){

            List<String> expectedCategories = List.of("Face", "Eyes", "Lips", "Accessories", "Shaving Needs", "Oral Care", "Facial Care", "Deodorant", "Bath & Oil");


            for (String category : expectedCategories) {
                boolean categoryDisplayed = false;
                for (WebElement element : makeupCategoryNames) {
                    if (element.getText().equals(category)) {
                        categoryDisplayed = true;
                        break;
                    }
                }

                Assert.assertEquals(true, categoryDisplayed, category + " kategorisi görüntülenemedi.");

            }

            System.out.println("Tüm kategoriler görüntülendi.");
        }

    public void addingToCartDropdownCatgories() {

        for (WebElement element : btn_generalDropdown) {
            actions.moveToElement(element).click().perform();

            try {
                Thread.sleep(1000); // 1 saniye uyku

             if(btn_generalCart.size()==0) continue;
                actions.moveToElement(btn_generalCart.get(0)).click().perform();


            } catch (NoSuchElementException e) {

            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

        }
}


        public void assertionItemInBasket(){Assert.assertEquals(txt_itemSepet.getText(), "8 Items");
}


        public void assertionPaymentURL() throws InterruptedException {

     WebDriverWait wait = new WebDriverWait(Driver.getDriver(), Duration.ofSeconds(10));
     wait.until(ExpectedConditions.urlContains("orders"));
    Assert.assertEquals(Driver.getDriver().getCurrentUrl(), "https://pickbazar-react-rest.vercel.app/orders/334983046149/payment" );

        Thread.sleep(1000);
    }

        public void clickCategoryFace(){
        tools.waitFor(btn_faceCategory).click();
}

        public void clickXButtonInBasket(){tools.waitFor(btn_xUrunInBasket).click();}

        public void assertionItemNumberInCheckout() throws InterruptedException {
        Thread.sleep(3000);
    System.out.println("itemNumberInCheckout.size() = " + itemNumberInCheckout.size());
   Assert.assertEquals(itemNumberInCheckout.size(), 1, "Sepette 1 ürün bulunmalı.");
}




}

















