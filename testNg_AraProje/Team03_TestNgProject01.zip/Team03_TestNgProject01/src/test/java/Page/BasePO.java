package Page;

import Utilities.Driver;
import Utilities.WebElementTools;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import java.time.Duration;

public class BasePO {

    public WebElementTools tools;
    public Actions actions;
    public BasePO(){
        Driver.getDriver().manage().window().maximize();
        Driver.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        PageFactory.initElements(Driver.getDriver(),this);
        tools=new WebElementTools(Driver.getDriver());
        actions=new Actions(Driver.getDriver());
    }

    @BeforeSuite
    public void setup() {
        Driver.getDriver().manage().window().maximize();
        Driver.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }

    @AfterSuite
    public void cleanup() {
        //Thread.sleep(1000);
        Driver.teardown();
    }

    /*  Common Methods */

    public void gotoPickBazar() {
        Driver.getDriver().get("https://shop-pickbazar-rest.vercel.app/");
    }




}
