package ForLoop;

public class Task13_Nested {

    public static void main(String[] args) {
         /*
        A
        B B
        C C C
        D D D D
        E E E E E
        F F F F F F
        şekli yazdırınız
        */
        int harf=65;//A ascii değeri





    }
}
