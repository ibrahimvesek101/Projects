package MethodCreation.Part2;

import java.util.Scanner;

public class Task08 {
    static Scanner sc=new Scanner(System.in);
    public static void main(String[] args) {
    /*
        task 24
       task-> girilen sayıya kadar olan Fİbonacci dizisi
       elemalarını print eden METHOD create ediniz.
       Fibonacci dizisi :1, 1, 2, 3, 5, 8, 13, 21, 34
    */

        Scanner scan = new Scanner(System.in);

    }

}
